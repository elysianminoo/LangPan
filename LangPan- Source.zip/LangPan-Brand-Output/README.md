# LangPan — خروجی برند (طبق بورد طراحی)

استخراج مستقیم (برش پیکسلی بدون بازسازی) از دو بورد اصلی طراحی.
پاندا واقعیِ سه‌بعدیِ داخل بورد — همان که در طراحی هست.

## ساختار فایل‌ها (دقیقاً مثل ساختار بورد)

**App Icon** — از ردیف App Icon بورد برند (آیکون بزرگ 1024):
- `app-icon-1024.png` — High Res
- `app-icon-512.png` — Play Store
- `app-icon-192.png` — Launcher
- `app-icon-96.png` — Notifications
- `app-icon-xl-native.png` — برش اصلی (رزولوشن بومی بورد)

**Logo Variations** — از ردیف Logo Variations:
- `logo-primary-light.png` — Primary Logo (Light)
- `logo-dark.png` — Dark Version
- `logo-compact.png` — Compact Logo
- `logo-mark.png` — Mark Only
- `logo-lockup-hero.png` — ترکیب کامل پاندا + LangPan + تگ‌لاین (بالا-چپ بورد)

**پاندای واقعی** (همان رندر سه‌بعدی بورد):
- `panda-hero-main.png` — نمای نزدیک اصلی (بورد کاراکتر، بزرگ‌ترین)
- `panda-hero-brand.png` — پاندای تنها (بورد برند)
- `panda-action-paw.png` — پنجه بالا (کارت Brand in Action)
- `promo-brand-in-action.png` — کارت کامل Brand in Action

**۱۶ حالت (Expressions & Emotions)** — `mood-happy … mood-hello-goodbye`

**Turnaround تمام‌قد** — `body-front / body-three-quarter / body-side / body-back`

**Accessories & Situations** — `acc-learning / acc-travel / acc-culture / acc-study / acc-achievement / acc-support`

**Panda Mark** — `panda-mark-simplified.png` (نسخه خطی تک‌رنگ)

## نکته صادقانه درباره رزولوشن
- برش‌های بومی از بورد ۱۲۵۴px آمده‌اند (آیکون ~۱۹۰px، مودها ~۱۴۰px، هیرو ~۴۶۰px).
  برای استفاده وب و موکاپ عالی‌اند؛ برای چاپ/استور نهایی، سورس وکتور لازم است.
- سری `app-icon-*` با کیفیت بالا به مربع وسط‌چین و resize شده‌اند.
- `src/brand/langpan_icon.png` (۱۰۲۴ وکتوری سورس فلاتر) و `src/brand/langpan_logo.png` هم سر جایشان هستند.
