# LangPan 🐼
Persian-first language learning platform.

**Method:** Experience → Understand → Notice → Practice → Retrieve → Produce → Use → Review.

The curriculum map spans Pre-A1 through C2. A1 Chapter 1 is the first complete authored vertical content slice with 12 lessons, assessment, Panda conversation and recovery.

The remaining curriculum is intentionally marked planned until authored and QA-reviewed; it is not falsely presented as complete.

## Release gate
A release requires complete content, schema validation, runtime tests, assessment mapping and CI success.
