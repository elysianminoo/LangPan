import 'package:flutter/material.dart';
void main()=>runApp(const LangPan());
class LangPan extends StatelessWidget{const LangPan({super.key});@override Widget build(BuildContext c)=>MaterialApp(theme:ThemeData(useMaterial3:true,colorSchemeSeed:const Color(0xFF3B82F6)),home:Scaffold(appBar:AppBar(title:const Text('LangPan • Test Mode')),body:const Center(child:Text('Content Engine + A1 Chapter 1 ready'))));}
