# LangPan

LangPan is a Persian-first language-learning product built around the sequence **Experience → Understand → Notice → Practice → Retrieve → Speak/Write → Use → Review**.

Current source release: **0.5.0+7**.

This source contains the redesigned LangPan visual system, approved Panda direction, brand assets, graphical navigation, personalised learner profile, an integrated A1 Chapter 1 lesson runtime and speech interaction.

The first authored vertical slice is A1 Chapter 1 (12 lessons). Other CEFR levels remain represented in the curriculum map and are not falsely marked as complete.

## Source of truth

GitHub is the source of truth. The repository build workflow validates content, Dart formatting, static analysis, tests and the Android release artifact.
