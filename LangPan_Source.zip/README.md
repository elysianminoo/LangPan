# LangPan v0.4.0

LangPan is a Persian-first language-learning product built around communicative learning, CEFR-aligned progression, retrieval practice, speaking, listening and an animated Panda companion.

## v0.4 focus

This iteration moves the installed app from a visual shell toward a real learning runtime:

- personalized learner profile instead of a hard-coded learner name
- optional آقا / خانم / undisclosed profile title
- 2.5D card and menu depth system
- stronger LangPan brand identity and launcher icon asset
- premium Panda painter with brown eyes, blue hoodie, backpack and expressive states
- real TTS playback for vocabulary and listening scripts
- real microphone capture for Speaking Lab
- device speech recognition with live transcript and confidence
- first-pass response similarity, intelligibility and fluency signals
- Panda feedback driven by speaking evidence
- explicit Speech Runtime contract for later professional phoneme analysis

## Architecture direction

The app remains offline-first at the UI/content layer. Speech providers are behind a service boundary so native recognition can later be replaced or augmented by a professional on-device or cloud speech engine without redesigning lesson UX.

## Important quality rule

No CI step hides failures. Formatting is normalized, then verified. Analyzer, tests, content validation and Android build remain blocking checks.

## Current scope note

The runtime is now substantially more interactive, but full Pre-A1–C2 authored curriculum, production Rive Panda, professional phoneme alignment, AI conversation gateway and backend learner model are still separate delivery streams. They must not be represented as complete merely because the shell can navigate to their future locations.
