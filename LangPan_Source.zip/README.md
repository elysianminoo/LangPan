# LangPan 🐼 — Source Package

Persian-first language-learning platform. Brand: **LangPan**.

## Current source state
- Flutter application source at repository root.
- Curriculum map spans Pre-A1 through C2.
- A1 Chapter 1 contains 12 authored lessons as the first complete vertical content slice.
- The remaining levels/chapters are represented in the curriculum map but are not falsely marked complete.
- This package is the source input for the GitHub Actions workflow `LangPan_Build.yml`.

## Pedagogy
Experience → Understand → Notice → Practice → Retrieve → Produce → Use → Review.

The curriculum is designed around CEFR-aligned objectives, communicative use, retrieval, spaced review, integrated skills, evidence-based assessment, recovery, and mastery.

## Important release gate
Do not call this production-complete until all curriculum content is authored and QA-reviewed, content validation passes, runtime tests pass, assessment mapping is complete, and the Android release workflow succeeds.

## Build
The companion workflow is intentionally separate from this source ZIP. Place `LangPan_Source.zip` and `LangPan_Build.yml` in the GitHub repository root and run the workflow manually, or push to `main` according to the workflow triggers.
