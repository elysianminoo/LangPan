# Panda assets (official Character Sheet)

## Required exports (from Brand Character Sheet)

Place transparent PNG (or WebP) frames here:

| File | Mood | Notes |
|------|------|-------|
| `happy.png` | happy | default companion |
| `excited.png` | excited | wave / celebrate |
| `thinking.png` | thinking | hand on chin |
| `listening.png` | listening | headphones optional |
| `speaking.png` | speaking | mic / talking |
| `proud.png` | proud | thumbs up |
| `encouraging.png` | encouraging | supportive |
| `confused.png` | confused | question |
| `calm.png` | calm | neutral soft smile |

Recommended size: **512×512** transparent, centered character.

Until files exist, `PandaCompanion` falls back to the **brand-aligned hoodie painter**.

## Rive (next)
`panda.riv` with state machine input `mood` (string) matching the table above.
