# LangPan — Official Brand Identity (LOCKED)

## Priority status
**Current focus: Panda + Visual Identity only.**  
No installable build is released until design is approved.

## Source of truth (only these)
1. Brand Guidelines board — logo, palette, IRANSans, UI kit, icon sizes  
2. Character Sheet — soft 3D panda, blue hoodie, expressions, turnaround  
3. Product UI Mockups — screens (splash → home → lesson → speak → progress)

## Panda implementation plan
| Stage | What | Status |
|-------|------|--------|
| A | Mood contract + brand colors in code | Done (`PandaMood`, `PandaCompanion`) |
| B | Hoodie painter stand-in (official blues, leaf mark, backpack) | Done (fallback) |
| C | Export 512px transparent PNGs per mood from Character Sheet | **Blocked — need designer exports** |
| D | Wire `assets/panda/{mood}.png` (auto via `Image.asset`) | Code ready; assets empty |
| E | Rive state machine same mood names | Later |

### How to supply mood assets
Put files in `assets/panda/`:
- `happy.png`, `excited.png`, `thinking.png`, `listening.png`
- `speaking.png`, `proud.png`, `encouraging.png`, `confused.png`, `calm.png`

Then register folder in `pubspec.yaml` under `flutter: assets:`.

## Color lock
Primary `#3B82F6` · Light `#60A5FA` · Dark `#1D4ED8` · Secondary `#8B5CF6` · Accent `#06B6D4`

## Logo files present
- `assets/brand/langpan_logo.png`
- `assets/brand/langpan_icon.png`

## Tagline
Learn • Speak • Explore — *Small steps · Big dreams*
