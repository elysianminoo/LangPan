# LangPan build contract

The canonical external build workflow is `LangPan_Build.yml`, supplied separately from this source ZIP.

The source package must remain installable without the workflow. The workflow generates the Android platform folder in CI, validates content, runs formatting/analyze/tests, builds a release APK and publishes the APK plus SHA-256 as an artifact.

The application ID is fixed as `com.langpan.app` for update continuity.
