# LangPan Design System — v0.4

## Product feeling

Premium, calm, friendly and adult-first. LangPan should feel like a real learning product, not a game shell.

## Visual language

- Blue/indigo is the learning identity.
- Cyan/mint communicate progress and speaking success.
- Cards use subtle 2.5D depth: soft shadow, highlight edge, rounded geometry.
- Primary actions are visually obvious and limited to one dominant action per screen.
- Panda is part of the product identity and learning interaction, not decorative clip-art.
- The brand mark is built around the panda + LangPan wordmark direction.

## Personalized UX

The learner profile controls:

- preferred name
- optional title: آقا / خانم / undisclosed
- target language
- accent target
- daily goal

Lesson content replaces the sample learner name at runtime. Character names such as Anna, David, Sarah and Amir remain varied so the learner does not repeatedly see one identity.

## Lesson UX

Every lesson answers:

1. Why am I learning this?
2. What does it mean?
3. How does it work?
4. Can I hear it?
5. Can I say it?
6. Can I use it with Panda?
7. Can I retrieve it without help?
8. What evidence do we have that I learned it?

Sequence:

Context → Notice → Explanation → Guided Practice → Listening → Production → Conversation → Retrieval → Assessment → Review.

## Accessibility

Minimum tap target: 48dp. Do not use color as the only feedback channel. Keep text contrast strong. Reduced-motion support remains a production requirement for the final animation layer.
