# LangPan Design System — v0.5.1

Aligned with the approved Brand Guidelines and UI mockups.

## Brand promise
**Learn • Speak • Explore**  
Tagline: *Small steps · Big dreams*

## Color tokens

| Token | Hex | Usage |
|-------|-----|--------|
| Primary | `#3B82F6` | Main actions, links, active nav |
| Primary Light | `#60A5FA` | Hover / soft highlights |
| Primary Dark | `#1D4ED8` | Pressed states |
| Secondary | `#8B5CF6` | Accent gradients, emphasis |
| Accent | `#06B6D4` | Info / exploration |
| Success | `#10B981` | Mastery, correct |
| Warning | `#F59E0B` | Attention |
| Error | `#EF4444` | Errors |
| Info | `#0EA5E9` | Neutral info |
| Neutral | `#64748B` | Secondary text |
| Ink | `#0F172A` | Primary text |
| Background | `#F5F8FF` | Scaffold |
| Surface | `#FFFFFF` | Cards |
| Border | `#E2E8F0` | Dividers / card edges |

Runtime source of truth: `lib/src/theme.dart` (`AppColors`, `AppRadii`, `AppShadows`, `buildAppTheme()`).

## Typography
- Persian + English: IRANSans when bundled; system fallback until font assets ship.
- Headings: weight 800–900, tight letter-spacing.
- Body: readable 1.5–1.55 line height, muted secondary color.

## Components
- **AppCard** — soft white gradient, light border, layered shadow.
- **GradientCard** — Primary → Secondary brand gradient for heroes.
- **GraphicMenuCard** — 2.5D navigation tiles with orbs and badges.
- **Pill** — compact status chips.
- **Floating bottom nav** — rounded white bar with soft blue active state.
- **Panda** — companion moods via `PandaCompanion` / runtime painter (Rive-ready).

## Layout principles
1. One clear primary action per screen.
2. Rounded geometry (12 / 16 / 22 / 28).
3. Adult-friendly, not childish.
4. Panda supports learning; Teacher/explanation blocks own formal grammar.
5. Min tap target 48dp; color never the only feedback.

## Assets
- `assets/brand/langpan_logo.png` — wordmark
- `assets/brand/langpan_icon.png` — app icon / mark

## Non-negotiable
Do not drift from the approved blue/violet learning identity or replace Panda with generic clip-art. Expand via Rive states, not a second character system.
