# LangPan Design System — v1.0 Brand Lock

See **`docs/BRAND_IDENTITY.md`** for the locked visual identity.

## Implementation map
| Brand element | Code / asset |
|---------------|----------------|
| Colors | `lib/src/theme.dart` → `AppColors` |
| Radii / shadows / buttons | `lib/src/theme.dart` → `AppRadii`, `AppShadows`, `buildAppTheme()` |
| Cards / logo / pills | `lib/src/widgets.dart` |
| Panda (hoodie + moods) | `lib/src/panda.dart` → `PandaCompanion` |
| Logo / icon | `assets/brand/langpan_logo.png`, `langpan_icon.png` |
| Home structure | `lib/src/shell.dart` → `HomePage` |
| Onboarding | `lib/src/onboarding.dart` |

## Home structure (official mockup)
1. Logo header  
2. Greeting + Panda  
3. Today's path card + primary button  
4. Review + Panda challenge  
5. Overall progress  
6. Secondary destinations  
7. Bottom nav  

## Next visual upgrades (assets)
- Bundle IRANSans  
- Drop Rive panda using Character Sheet expressions  
- Export multi-size app icons from brand board (1024→96)  
