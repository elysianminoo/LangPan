# LangPan Design System — v0.5

## Non-negotiable visual direction

LangPan uses the previously approved premium cute + smart adventure direction:
- premium 2.5D, not flat utility UI;
- rounded geometry, layered depth, soft highlight edges and grounding shadows;
- adult-first, friendly and calm rather than childish;
- blue/indigo learning identity with cyan/mint success accents;
- one clear primary action per screen;
- graphical navigation cards instead of a list of plain Material tiles.

## Brand

The brand is the approved LangPan identity. The app uses `assets/brand/langpan_logo.png` and `assets/brand/langpan_icon.png` as the single source of truth for the visible wordmark and app icon.

## Panda

The Panda is the product symbol and companion. The core character is a soft rounded black-and-white panda with warm brown expressive eyes. It has no permanent clothing; travel accessories such as a backpack are contextual. The runtime painter provides breathing/bobbing, expressive eyes, brows and paws and exposes stable mood states for a future Rive rig.

## Menus and cards

Home navigation uses graphical 2.5D cards with:
- gradient surfaces;
- layered translucent orbs;
- large icon/illustration focal point;
- soft shadow and border highlight;
- compact descriptive copy;
- a single tap target.

Lesson navigation uses visual chapter/lesson cards and a bottom-sheet lesson map.

## Personalised UX

The learner profile controls preferred name, optional title (آقا / خانم / undisclosed), target language, accent target and daily goal. Authored example names rotate among several characters instead of hard-coding one learner name. The learner's own name is injected only where the task is asking for the learner.

## Lesson UX

Every lesson answers:
1. Why am I learning this?
2. What does it mean?
3. How does it work?
4. Can I hear it?
5. Can I say it?
6. Can I use it with Panda?
7. Can I retrieve it without help?
8. Can I produce it in a new context?
9. What evidence do we have that I learned it?

Sequence:

Context → Notice → Explanation → Guided Practice → Listening → Production → Conversation → Retrieval → Assessment → Review.

## Accessibility

Minimum tap target: 48dp. Never use color as the only feedback channel. Maintain readable contrast and support reduced-motion behavior in the final animation layer.
