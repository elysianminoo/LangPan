# LangPan Design System — v0.3

## Product feeling
Premium, calm, friendly and adult-first. LangPan should feel like a real learning product, not a game shell.

## Visual hierarchy
1. One primary action per screen.
2. Large meaningful typography.
3. Rounded cards with restrained borders and shadows.
4. Blue/indigo brand gradient reserved for important learning moments.
5. Panda is a companion, not decoration.

## Lesson UX
Every lesson screen answers three questions:
- Why am I learning this?
- What does it mean and how does it work?
- Can I use it without help?

The learning sequence is context → explanation → guided practice → production → retrieval → assessment.

## Accessibility
Minimum tap target: 48dp. Avoid color-only feedback. Keep contrast strong. Reduced-motion support is planned for the production animation layer.
