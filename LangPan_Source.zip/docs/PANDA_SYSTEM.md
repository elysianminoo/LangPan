# LangPan Panda Character System — v0.3

The current app uses a custom Flutter-painted panda as the first runtime-safe character implementation. It is animated with a small state-driven loop rather than a static image.

## Runtime states
- happy
- thinking
- listening
- proud
- excited
- encouraging

## Interaction principles
- Panda speaks only when it adds learning value.
- Panda never shames missed practice.
- Panda can change mood based on learner state.
- Conversation feedback is constructive and specific.
- The final production layer can replace the painter with a Rive rig without changing the learning API.

## Future production layer
PandaController → PandaStateMachine → AnimationMapper → Voice/LipSync → AI Response Plan.
