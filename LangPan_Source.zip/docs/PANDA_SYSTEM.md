# LangPan Panda Character System — v0.6

Panda is the visual symbol and learning companion of LangPan.

## Visual contract

- Premium 2.5D panda
- white/black fur with warm brown expressive eyes
- blue LangPan hoodie
- backpack/travel identity when appropriate
- soft highlights and grounding shadow
- adult-friendly, cute without looking childish
- expressive face and purposeful gestures

## Runtime states

happy, thinking, listening, speaking, proud, excited, encouraging, confused, calm.

## Interaction

Panda changes state according to learning context:

- listening → listens while the learner speaks
- thinking → processes an answer
- encouraging → a developing response needs another attempt
- proud → strong evidence was produced
- excited → lesson achievement or successful task
- confused → the answer needs clarification
- calm → ambient/home state

## Architecture

```text
PandaController
→ PandaStateMachine
→ AnimationMapper
→ Expression/Gesture Layer
→ Voice/LipSync Layer
→ AI Response Plan
```

The current Flutter painter is the safe runtime implementation. The same state API is intentionally compatible with a future Rive rig and real lip-sync system.

## Safety and pedagogy

Panda never shames the learner, never fakes pronunciation certainty, and never replaces the teacher. Panda is the conversational companion; the teacher layer owns precise grammar explanation.
