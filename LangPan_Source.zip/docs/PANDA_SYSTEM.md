# Panda System — Complete Design Spec

## Character (official)
Soft premium companion: black/white fur, **warm brown eyes**, **blue hoodie** (`#3B82F6`), white LangPan leaf mark, optional backpack, soft bob animation.

## Widget
`PandaCompanion(mood:, compact:, showBackpack:, onTap:)`

1. Loads `assets/panda/{mood}.png` if present  
2. Else draws `BrandPandaPainter` (full brand stand-in)

## Moods & visual behavior
| Mood | Face / body |
|------|-------------|
| happy | soft smile, light blink, sparkles |
| excited | open smile, raised paw, sparkles |
| encouraging | raised paw, sparkles |
| proud | smile, sparkles |
| thinking | angled brows, “…” |
| confused | angled brows, “?” |
| listening | headphones |
| speaking | headphones |
| calm | softer eyes |

## Brand details painted
- Gradient hoodie (light → primary → dark)
- Chest leaf mark
- Pocket, legs, feet
- Backpack + strap when `showBackpack: true`
- Ear inner fur, blush, eye glints
- Ground shadow + idle bob

## Asset upgrade path
Drop 512×512 transparent PNGs into `assets/panda/` named by mood; no call-site changes.
