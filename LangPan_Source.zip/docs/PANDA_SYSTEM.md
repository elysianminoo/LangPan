# LangPan Panda Character System — v0.5

The Panda visual follows the previously selected LangPan direction and is not reinterpreted per screen.

## Visual contract

- Premium 2.5D panda.
- Soft rounded black-and-white body.
- Warm brown expressive eyes.
- Friendly, intelligent face.
- No permanent hoodie or costume.
- Contextual backpack/travel accessory only when the scene calls for it.
- Soft grounding shadow and highlights.
- Adult-friendly and emotionally expressive.

## Runtime states

happy, thinking, listening, speaking, proud, excited, encouraging, confused, calm.

## Interaction

Panda changes state from learning context. It listens during speaking, thinks while evaluating, encourages a developing answer, celebrates strong evidence and stays calm in ambient/home contexts.

## Architecture

```text
PandaController
→ PandaStateMachine
→ AnimationMapper
→ Expression/Gesture Layer
→ Voice/LipSync Layer
→ AI Response Plan
```

The current painter is a functional runtime representation of the approved character. Its state API is deliberately stable so it can be replaced by a Rive rig without changing lesson contracts.

## Safety and pedagogy

Panda never shames the learner, never fakes pronunciation certainty and never replaces the teacher. Precise grammar explanations belong to the teacher layer; Panda is the companion and conversation partner.
