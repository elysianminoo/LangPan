# LangPan Lesson Runtime — v0.3

The lesson player is intentionally no longer a list of information cards.

## Learning cycle
Context → Notice → Explain → Guided Practice → Listening → Production → Conversation → Retrieval → Assessment.

## Why this matters
A learner should first understand the communicative purpose, then notice the language, then receive a precise explanation, and finally produce it. Completion is not mastery.

## Recovery
A weak answer should identify the likely weakness, provide a micro-explanation, give a few guided items, require independent production, and recheck later.

## Assessment
The runtime keeps evidence separate from gamification. XP is not mastery. Mastery requires evidence across separated review opportunities.
