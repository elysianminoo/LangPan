# LangPan Pedagogy Runtime — v0.5

The runtime is a learning system, not a sequence of information cards.

## Lesson loop

Context → Notice → Explanation → Guided Practice → Listening → Speaking → Conversation → Retrieval → Production → Assessment → Review.

## Evidence

Finishing a screen is not mastery. Mastery evidence combines correct recognition, retrieval, production, different context and delayed review.

## Recovery

Weakness → Identify cause → Micro lesson → Guided practice → Production → Recheck.

## Personalisation

Learner names, titles and preferences are runtime data. Content is authored independently from one learner so examples remain varied and natural.

## Speech

The first runtime layer uses device speech recognition, confidence where available, accepted-variant matching, similarity, speaking-rate feedback and learner-facing guidance. The architecture keeps phoneme-level alignment as a separate Speech Engine so a specialist pronunciation service can be added later without rewriting lesson UI.
