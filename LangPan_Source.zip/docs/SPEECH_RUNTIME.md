# LangPan Speech Runtime — v0.4

## Runtime contract

`Speaking Lab` now has a real microphone path instead of a placeholder button.

Flow:

```text
Prompt
→ optional native TTS example
→ microphone permission
→ audio capture
→ device speech recognition
→ live transcript + sound level
→ accepted-variant scoring
→ confidence + intelligibility estimate
→ targeted feedback
→ Panda response
```

## Current mobile implementation

- `record` captures an M4A recording to the app temporary directory.
- `speech_to_text` provides live recognition, partial text and confidence when the platform exposes it.
- `flutter_tts` provides immediate example playback for lesson vocabulary, listening scripts and speaking prompts.
- Android build injects microphone/internet permissions and the speech-recognition service query.

## Evaluation layers

1. **Task meaning** — did the recognized response match an accepted communicative answer?
2. **Language form** — token similarity against authored accepted variants.
3. **Recognition confidence** — platform speech-recognition confidence when available.
4. **Intelligibility proxy** — weighted combination of confidence and task similarity.
5. **Fluency signal** — duration and approximate words per minute.

This is an initial mobile baseline, not a claim of phoneme-perfect pronunciation scoring.

## Production Speech Engine boundary

The current UI and domain contract are deliberately independent from the recognition provider. A later professional backend can add:

- phoneme alignment
- word-level timing
- stress/rhythm analysis
- vowel/consonant diagnostics
- accent/intelligibility scoring
- waveform/voice-quality metrics
- cloud or on-device ASR selection

The app should never convert a weak ASR result into a false claim that a specific phoneme was wrong.
