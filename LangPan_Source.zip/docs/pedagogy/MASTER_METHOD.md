# LangPan Master Method
CEFR descriptor → Can-Do outcome → real-world task → guided practice → evidence → assessment → review.

Completion is not mastery. Mastery requires evidence across time and contexts.
AI supports conversation/explanation but does not independently decide curriculum scope or mastery.
