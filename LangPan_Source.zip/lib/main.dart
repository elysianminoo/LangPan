import 'package:flutter/material.dart';

import 'src/onboarding.dart';
import 'src/profile_store.dart';
import 'src/shell.dart';
import 'src/theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const LangPanApp());
}

class LangPanApp extends StatefulWidget {
  const LangPanApp({super.key});

  @override
  State<LangPanApp> createState() => _LangPanAppState();
}

class _LangPanAppState extends State<LangPanApp> {
  final ProfileStore _profileStore = ProfileStore();
  int _shellKey = 0;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LangPan',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: SplashGate(
        loadProfile: _profileStore.load,
        onboarding: (seed, onDone) => OnboardingFlow(
          onFinished: (profile) async {
            await _profileStore.save(profile);
            await onDone(profile);
            if (mounted) setState(() => _shellKey++);
          },
        ),
        child: LangPanShell(key: ValueKey(_shellKey)),
      ),
    );
  }
}
