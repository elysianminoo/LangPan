import 'package:flutter/material.dart';

import 'src/shell.dart';
import 'src/theme.dart';

void main() {
  runApp(const LangPanApp());
}

class LangPanApp extends StatelessWidget {
  const LangPanApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LangPan',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const LangPanShell(),
    );
  }
}
