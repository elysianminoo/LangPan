import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;

const _blue = Color(0xFF3B82F6);
const _indigo = Color(0xFF6366F1);
const _cyan = Color(0xFF22D3EE);
const _green = Color(0xFF10B981);
const _ink = Color(0xFF172033);
const _muted = Color(0xFF64748B);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const LangPanApp());
}

class LangPanApp extends StatelessWidget {
  const LangPanApp({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(seedColor: _blue);
    return MaterialApp(
      title: 'LangPan',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        scaffoldBackgroundColor: const Color(0xFFF7F9FC),
        fontFamily: 'sans',
        cardTheme: const CardThemeData(
          elevation: 0,
          margin: EdgeInsets.zero,
          surfaceTintColor: Colors.transparent,
        ),
      ),
      home: const LangPanShell(),
    );
  }
}

class LangPanShell extends StatefulWidget {
  const LangPanShell({super.key});

  @override
  State<LangPanShell> createState() => _LangPanShellState();
}

class _LangPanShellState extends State<LangPanShell> {
  int index = 0;
  Map<String, dynamic>? curriculum;
  String? error;

  @override
  void initState() {
    super.initState();
    _loadCurriculum();
  }

  Future<void> _loadCurriculum() async {
    try {
      final raw = await rootBundle.loadString('content/en/curriculum_map.json');
      final value = jsonDecode(raw) as Map<String, dynamic>;
      if (!mounted) return;
      setState(() => curriculum = value);
    } catch (e) {
      if (!mounted) return;
      setState(() => error = '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      HomePage(curriculum: curriculum, onLearn: () => setState(() => index = 1)),
      LearnPage(curriculum: curriculum),
      const ReviewPage(),
      const ProgressPage(),
      const ProfilePage(),
    ];

    return Scaffold(
      body: SafeArea(
        child: error == null
            ? pages[index]
            : ErrorView(message: error!, onRetry: _loadCurriculum),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.school_outlined), selectedIcon: Icon(Icons.school), label: 'یادگیری'),
          NavigationDestination(icon: Icon(Icons.replay_outlined), selectedIcon: Icon(Icons.replay), label: 'مرور'),
          NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'پیشرفت'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'پروفایل'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({required this.curriculum, required this.onLearn, super.key});
  final Map<String, dynamic>? curriculum;
  final VoidCallback onLearn;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
      children: [
        Row(
          children: [
            const LangPanMark(size: 48),
            const SizedBox(width: 12),
            const Expanded(child: Text('LangPan', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: _ink))),
            IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
          ],
        ),
        const SizedBox(height: 20),
        const PandaHero(),
        const SizedBox(height: 18),
        _SectionTitle(title: 'امروز با هم چه کار کنیم؟', action: 'یادگیری', onTap: onLearn),
        const SizedBox(height: 10),
        _TodayCard(onTap: onLearn),
        const SizedBox(height: 18),
        const _SectionTitle(title: 'ادامه مسیر'),
        const SizedBox(height: 10),
        _ProgressCard(onTap: onLearn),
        const SizedBox(height: 18),
        const _SectionTitle(title: 'دسترسی سریع'),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: _QuickCard(icon: Icons.replay, label: 'مرور', onTap: () {})),
          const SizedBox(width: 10),
          Expanded(child: _QuickCard(icon: Icons.record_voice_over, label: 'مکالمه', onTap: onLearn)),
          const SizedBox(width: 10),
          Expanded(child: _QuickCard(icon: Icons.emoji_events_outlined, label: 'دستاوردها', onTap: () {})),
        ]),
      ],
    );
  }
}

class LearnPage extends StatelessWidget {
  const LearnPage({required this.curriculum, super.key});
  final Map<String, dynamic>? curriculum;

  @override
  Widget build(BuildContext context) {
    final levels = (curriculum?['levels'] as List<dynamic>?) ?? const <dynamic>[];
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
      children: [
        const Text('مسیر یادگیری', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: _ink)),
        const SizedBox(height: 6),
        const Text('هر سطح را باز کن و مستقیم وارد فصل‌ها و درس‌ها شو.', style: TextStyle(color: _muted)),
        const SizedBox(height: 18),
        ...levels.map((item) {
          final level = item as Map<String, dynamic>;
          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: LevelCard(level: level),
          );
        }),
      ],
    );
  }
}

class LevelCard extends StatelessWidget {
  const LevelCard({required this.level, super.key});
  final Map<String, dynamic> level;

  @override
  Widget build(BuildContext context) {
    final cefr = '${level['cefr'] ?? ''}'.toUpperCase();
    final title = '${level['title'] ?? cefr}';
    final chapters = (level['chapters'] as List<dynamic>?) ?? const <dynamic>[];
    final authored = chapters.where((c) => (c as Map<String, dynamic>)['status'] == 'authored').length;
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => LevelPage(level: level))),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [_blue, _indigo]),
                  borderRadius: BorderRadius.circular(18),
                ),
                alignment: Alignment.center,
                child: Text(cefr.replaceAll('_', '-'), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13)),
              ),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: _ink)),
                const SizedBox(height: 4),
                Text('${chapters.length} فصل  •  $authored فصل آماده تست', style: const TextStyle(color: _muted)),
              ])),
              const Icon(Icons.chevron_right),
            ],
          ),
        ),
      ),
    );
  }
}

class LevelPage extends StatelessWidget {
  const LevelPage({required this.level, super.key});
  final Map<String, dynamic> level;

  @override
  Widget build(BuildContext context) {
    final chapters = (level['chapters'] as List<dynamic>?) ?? const <dynamic>[];
    final title = '${level['title'] ?? ''}';
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('$title • فصل‌ها', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: _ink)),
          const SizedBox(height: 16),
          ...chapters.asMap().entries.map((entry) {
            final chapter = entry.value as Map<String, dynamic>;
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: ChapterCard(level: level, chapter: chapter, number: entry.key + 1),
            );
          }),
        ],
      ),
    );
  }
}

class ChapterCard extends StatelessWidget {
  const ChapterCard({required this.level, required this.chapter, required this.number, super.key});
  final Map<String, dynamic> level;
  final Map<String, dynamic> chapter;
  final int number;

  @override
  Widget build(BuildContext context) {
    final authored = chapter['status'] == 'authored';
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(backgroundColor: authored ? _blue.withValues(alpha: .12) : Colors.black12, child: Text('$number', style: TextStyle(color: authored ? _blue : _muted, fontWeight: FontWeight.w700))),
        title: Text('${chapter['title']}', style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(authored ? '۱۲ درس • آماده تست' : 'محتوای این فصل در حال توسعه است'),
        trailing: const Icon(Icons.chevron_right),
        onTap: authored
            ? () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => LessonListPage(level: level, chapter: chapter)))
            : null,
      ),
    );
  }
}

class LessonListPage extends StatelessWidget {
  const LessonListPage({required this.level, required this.chapter, super.key});
  final Map<String, dynamic> level;
  final Map<String, dynamic> chapter;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${level['title']} • ${chapter['title']}')),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _loadLessons(),
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return ErrorView(message: '${snapshot.error}', onRetry: () {});
          final lessons = snapshot.data ?? const <Map<String, dynamic>>[];
          return ListView.separated(
            padding: const EdgeInsets.all(20),
            itemCount: lessons.length,
            separatorBuilder: (_, _) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final lesson = lessons[index];
              return Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  leading: CircleAvatar(backgroundColor: _blue.withValues(alpha: .1), child: Text('${index + 1}', style: const TextStyle(color: _blue, fontWeight: FontWeight.w800))),
                  title: Text('${lesson['title']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text('${lesson['communicative_goal']}'),
                  trailing: const Icon(Icons.play_arrow_rounded),
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => LessonPlayer(lesson: lesson))),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Future<List<Map<String, dynamic>>> _loadLessons() async {
    final assets = <String>[];
    for (var i = 1; i <= 12; i++) assets.add('content/en/a1/chapter_01/lesson_l$i.json');
    final result = <Map<String, dynamic>>[];
    for (final asset in assets) {
      final raw = await rootBundle.loadString(asset);
      result.add(jsonDecode(raw) as Map<String, dynamic>);
    }
    return result;
  }
}

class LessonPlayer extends StatefulWidget {
  const LessonPlayer({required this.lesson, super.key});
  final Map<String, dynamic> lesson;

  @override
  State<LessonPlayer> createState() => _LessonPlayerState();
}

class _LessonPlayerState extends State<LessonPlayer> {
  int step = 0;
  bool completed = false;

  List<_LessonStep> get steps => [
        _LessonStep('هدف امروز', _ObjectiveBlock(lesson: widget.lesson)),
        _LessonStep('واژگان', _VocabularyBlock(words: (widget.lesson['vocabulary'] as List<dynamic>? ?? const []).cast<Map<String, dynamic>>())),
        _LessonStep('گرامر', _GrammarBlock(grammar: widget.lesson['grammar'] as Map<String, dynamic>)),
        _LessonStep('شنیداری', _ListeningBlock(data: widget.lesson['listening'] as Map<String, dynamic>)),
        _LessonStep('مکالمه', _SpeakingBlock(data: widget.lesson['speaking'] as Map<String, dynamic>)),
        _LessonStep('گفت‌وگو با پاندا', _PandaConversationBlock(lesson: widget.lesson)),
        _LessonStep('بازیابی', _RetrievalBlock(items: (widget.lesson['retrieval'] as List<dynamic>? ?? const []).cast<String>())),
        _LessonStep('ارزیابی', _AssessmentBlock(data: widget.lesson['assessment'] as Map<String, dynamic>)),
      ];

  @override
  Widget build(BuildContext context) {
    final current = steps[step];
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.lesson['title']}'),
        actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.bookmark_border))],
      ),
      body: Column(
        children: [
          LinearProgressIndicator(value: (step + 1) / steps.length, minHeight: 5),
          Expanded(child: ListView(padding: const EdgeInsets.all(20), children: [
            const PandaMini(),
            const SizedBox(height: 12),
            Text(current.title, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: _ink)),
            const SizedBox(height: 16),
            current.body,
          ])),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 18),
            child: SizedBox(
              width: double.infinity,
              height: 54,
              child: FilledButton(
                onPressed: () {
                  if (step < steps.length - 1) {
                    setState(() => step++);
                  } else {
                    setState(() => completed = true);
                    showDialog<void>(context: context, builder: (_) => AlertDialog(title: const Text('آفرین! 🎉'), content: const Text('درس را کامل کردی. حالا می‌توانی مرور یا درس بعدی را انتخاب کنی.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('باشه'))]));
                  }
                },
                child: Text(step == steps.length - 1 ? 'پایان درس' : 'ادامه'),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: completed ? FloatingActionButton.extended(onPressed: () {}, icon: const Icon(Icons.check), label: const Text('تکمیل شد')) : null,
    );
  }
}

class _LessonStep {
  const _LessonStep(this.title, this.body);
  final String title;
  final Widget body;
}

class _ObjectiveBlock extends StatelessWidget {
  const _ObjectiveBlock({required this.lesson});
  final Map<String, dynamic> lesson;
  @override
  Widget build(BuildContext context) => Card(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${lesson['scenario']}', style: const TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 12), ...(lesson['can_do'] as List<dynamic>).map((x) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Row(children: [const Icon(Icons.check_circle, color: _green, size: 20), const SizedBox(width: 8), Expanded(child: Text('$x'))])))]));
}

class _VocabularyBlock extends StatelessWidget {
  const _VocabularyBlock({required this.words});
  final List<Map<String, dynamic>> words;
  @override
  Widget build(BuildContext context) => Column(children: words.map((word) => Card(margin: const EdgeInsets.only(bottom: 10), child: ListTile(title: Text('${word['word']}', style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text('${word['meaning']}\n${word['example']}'), trailing: IconButton(onPressed: () {}, icon: const Icon(Icons.volume_up_outlined)))).toList());
}

class _GrammarBlock extends StatelessWidget {
  const _GrammarBlock({required this.grammar});
  final Map<String, dynamic> grammar;
  @override
  Widget build(BuildContext context) => Card(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${grammar['focus']}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), const SizedBox(height: 12), Text('${grammar['explanation']}'), const SizedBox(height: 18), const Text('Context → Notice → Explain → Practice', style: TextStyle(color: _blue, fontWeight: FontWeight.w700))]));
}

class _ListeningBlock extends StatefulWidget {
  const _ListeningBlock({required this.data});
  final Map<String, dynamic> data;
  @override
  State<_ListeningBlock> createState() => _ListeningBlockState();
}
class _ListeningBlockState extends State<_ListeningBlock> {
  bool show = false;
  @override
  Widget build(BuildContext context) => Card(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [IconButton.filled(onPressed: () => setState(() => show = true), icon: const Icon(Icons.play_arrow)), const SizedBox(width: 10), const Text('گوش بده و نکته اصلی را پیدا کن', style: TextStyle(fontWeight: FontWeight.w700))]), const SizedBox(height: 18), if (show) Text('${widget.data['script']}', style: const TextStyle(fontSize: 18, height: 1.5)), if (!show) const Text('پخش صدا در نسخه صوتی به Speech Engine متصل می‌شود.', style: TextStyle(color: _muted))]));
}

class _SpeakingBlock extends StatelessWidget {
  const _SpeakingBlock({required this.data});
  final Map<String, dynamic> data;
  @override
  Widget build(BuildContext context) => Card(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${data['prompt']}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)), const SizedBox(height: 18), Center(child: IconButton.filled(onPressed: () {}, icon: const Icon(Icons.mic, size: 34))), const SizedBox(height: 12), const Center(child: Text('برای ضبط پاسخ لمس کن'))]));
}

class _PandaConversationBlock extends StatelessWidget {
  const _PandaConversationBlock({required this.lesson});
  final Map<String, dynamic> lesson;
  @override
  Widget build(BuildContext context) => Card(padding: const EdgeInsets.all(20), child: Column(children: [(lesson['panda_conversation']['turns'] as List<dynamic>).map((turn) => Align(alignment: turn.toString().startsWith('Panda') ? Alignment.centerLeft : Alignment.centerRight, child: Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: turn.toString().startsWith('Panda') ? _blue.withValues(alpha: .08) : _green.withValues(alpha: .08), borderRadius: BorderRadius.circular(16)), child: Text('$turn')))).toList(), const SizedBox(height: 10), FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.chat_bubble_outline), label: const Text('شروع گفت‌وگو'))]));
}

class _RetrievalBlock extends StatelessWidget {
  const _RetrievalBlock({required this.items});
  final List<String> items;
  @override
  Widget build(BuildContext context) => Column(children: items.asMap().entries.map((e) => Card(margin: const EdgeInsets.only(bottom: 10), child: ListTile(leading: CircleAvatar(child: Text('${e.key + 1}')), title: Text(e.value), trailing: const Icon(Icons.psychology_outlined))).toList());
}

class _AssessmentBlock extends StatelessWidget {
  const _AssessmentBlock({required this.data});
  final Map<String, dynamic> data;
  @override
  Widget build(BuildContext context) { final items = data['items'] as List<dynamic>; return Column(children: [Card(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('معیار قبولی', style: TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 8), Text('${data['pass_rule']}')])), const SizedBox(height: 10), ...items.map((item) => Card(child: ListTile(title: Text('${item['type']}'), subtitle: Text('${item['pass_rule']}'))))]); }
}

class ReviewPage extends StatelessWidget { const ReviewPage({super.key}); @override Widget build(BuildContext context) => const Center(child: _EmptyFeature(icon: Icons.replay, title: 'مرور هوشمند', text: 'مرورهای فاصله‌دار اینجا قرار می‌گیرند.')); }
class ProgressPage extends StatelessWidget { const ProgressPage({super.key}); @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: const [Text('پیشرفت من', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: _ink)), SizedBox(height: 16), _ProgressCard(), SizedBox(height: 16), Card(padding: EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('مهارت‌ها', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)), SizedBox(height: 16), _SkillBar(label: 'واژگان', value: .28), _SkillBar(label: 'گرامر', value: .22), _SkillBar(label: 'شنیداری', value: .16), _SkillBar(label: 'گفتاری', value: .12)]))]); }
class ProfilePage extends StatelessWidget { const ProfilePage({super.key}); @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: const [Text('پروفایل', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800, color: _ink)), SizedBox(height: 20), Card(padding: EdgeInsets.all(20), child: Row(children: [LangPanMark(size: 64), SizedBox(width: 14), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('یادگیرنده LangPan', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)), SizedBox(height: 4), Text('English • American pronunciation', style: TextStyle(color: _muted))]))), SizedBox(height: 12), Card(child: ListTile(leading: Icon(Icons.settings_outlined), title: Text('تنظیمات'), trailing: Icon(Icons.chevron_right))) ]); }

class PandaHero extends StatelessWidget { const PandaHero({super.key}); @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(colors: [_blue, _indigo]), borderRadius: BorderRadius.circular(28)), child: Row(children: [const PandaAvatar(size: 110), const SizedBox(width: 16), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('سلام! من پاندا هستم 🐼', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w800)), SizedBox(height: 8), Text('امروز یک قدم کوچک برداریم و انگلیسی را در موقعیت واقعی تمرین کنیم.', style: TextStyle(color: Colors.white70, height: 1.4))]))])); }
class PandaMini extends StatelessWidget { const PandaMini({super.key}); @override Widget build(BuildContext context) => const Align(alignment: Alignment.centerRight, child: PandaAvatar(size: 72)); }
class PandaAvatar extends StatelessWidget { const PandaAvatar({required this.size, super.key}); final double size; @override Widget build(BuildContext context) => SizedBox(width: size, height: size, child: CustomPaint(painter: _PandaPainter())); }
class _PandaPainter extends CustomPainter { @override void paint(Canvas canvas, Size size) { final p=Paint()..isAntiAlias=true; final c=Offset(size.width/2,size.height/2); p.color=Colors.black; canvas.drawCircle(c.translate(-size.width*.28,-size.height*.28),size.width*.18,p); canvas.drawCircle(c.translate(size.width*.28,-size.height*.28),size.width*.18,p); p.color=Colors.white; canvas.drawCircle(c,size.width*.42,p); p.color=Colors.black; canvas.drawOval(Rect.fromCenter(center:c.translate(-size.width*.15,-size.height*.06),width:size.width*.16,height:size.height*.25),p); canvas.drawOval(Rect.fromCenter(center:c.translate(size.width*.15,-size.height*.06),width:size.width*.16,height:size.height*.25),p); p.color=Colors.white; canvas.drawCircle(c.translate(-size.width*.13,-size.height*.08),size.width*.045,p); canvas.drawCircle(c.translate(size.width*.17,-size.height*.08),size.width*.045,p); p.color=Colors.black; canvas.drawOval(Rect.fromCenter(center:c.translate(0,size.height*.12),width:size.width*.16,height:size.height*.1),p); p.color=_blue; canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center:Offset(c.dx,c.dy+size.height*.38),width:size.width*.62,height:size.height*.22),Radius.circular(size.width*.12)),p); } @override bool shouldRepaint(covariant CustomPainter oldDelegate)=>false; }
class LangPanMark extends StatelessWidget { const LangPanMark({required this.size, super.key}); final double size; @override Widget build(BuildContext context)=>Container(width:size,height:size,decoration:BoxDecoration(color:_blue,borderRadius:BorderRadius.circular(size*.28)),alignment:Alignment.center,child:Text('LP',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w900,fontSize:size*.32))); }

class _TodayCard extends StatelessWidget { const _TodayCard({required this.onTap}); final VoidCallback onTap; @override Widget build(BuildContext context)=>Card(child:InkWell(borderRadius:BorderRadius.circular(22),onTap:onTap,child:const Padding(padding:EdgeInsets.all(18),child:Row(children:[CircleAvatar(radius:27,backgroundColor:Color(0xFFEAF2FF),child:Icon(Icons.play_arrow_rounded,color:_blue)),SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('A1 • Hello!',style:TextStyle(fontSize:18,fontWeight:FontWeight.w800,color:_ink)),SizedBox(height:4),Text('سلام کردن و معرفی خودت',style:TextStyle(color:_muted)),SizedBox(height:10),LinearProgressIndicator(value:.12,minHeight:6)])]),Icon(Icons.chevron_right)])))); }
class _ProgressCard extends StatelessWidget { const _ProgressCard({this.onTap}); final VoidCallback? onTap; @override Widget build(BuildContext context)=>Card(child:InkWell(onTap:onTap,borderRadius:BorderRadius.circular(22),child:const Padding(padding:EdgeInsets.all(18),child:Row(children:[Icon(Icons.local_fire_department_rounded,color:Colors.orange,size:32),SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('هدف امروز',style:TextStyle(fontWeight:FontWeight.w800)),SizedBox(height:5),Text('۱۰ دقیقه • ۱ درس',style:TextStyle(color:_muted))])),Text('0%',style:TextStyle(fontWeight:FontWeight.w800,color:_blue))])))); }
class _QuickCard extends StatelessWidget { const _QuickCard({required this.icon,required this.label,required this.onTap}); final IconData icon; final String label; final VoidCallback onTap; @override Widget build(BuildContext context)=>Card(child:InkWell(onTap:onTap,borderRadius:BorderRadius.circular(18),child:Padding(padding:const EdgeInsets.symmetric(vertical:18),child:Column(children:[Icon(icon,color:_blue),const SizedBox(height:8),Text(label,style:const TextStyle(fontWeight:FontWeight.w700))])))); }
class _SectionTitle extends StatelessWidget { const _SectionTitle({required this.title,this.action,this.onTap}); final String title; final String? action; final VoidCallback? onTap; @override Widget build(BuildContext context)=>Row(children:[Expanded(child:Text(title,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w800,color:_ink))),if(action!=null)TextButton(onPressed:onTap,child:Text(action!))]); }
class _SkillBar extends StatelessWidget { const _SkillBar({required this.label,required this.value}); final String label; final double value; @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.only(bottom:14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Expanded(child:Text(label)),Text('${(value*100).round()}%')]),const SizedBox(height:6),LinearProgressIndicator(value:value,minHeight:7,borderRadius:BorderRadius.circular(7))])); }
class _EmptyFeature extends StatelessWidget { const _EmptyFeature({required this.icon,required this.title,required this.text}); final IconData icon; final String title; final String text; @override Widget build(BuildContext context)=>Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(icon,size:64,color:_blue),const SizedBox(height:16),Text(title,style:const TextStyle(fontSize:24,fontWeight:FontWeight.w800)),const SizedBox(height:8),Text(text,style:const TextStyle(color:_muted))]); }
class ErrorView extends StatelessWidget { const ErrorView({required this.message,required this.onRetry,super.key}); final String message; final VoidCallback onRetry; @override Widget build(BuildContext context)=>Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.error_outline,size:56,color:Colors.red),const SizedBox(height:12),const Text('خطا در بارگذاری محتوا',style:TextStyle(fontSize:20,fontWeight:FontWeight.w800)),const SizedBox(height:8),Text(message,textAlign:TextAlign.center),const SizedBox(height:16),FilledButton(onPressed:onRetry,child:const Text('تلاش دوباره'))]))); }
