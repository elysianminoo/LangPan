import 'dart:convert';

import 'package:flutter/services.dart' show rootBundle;

/// Safe accessors for decoded JSON. Content files are authored by hand, so the
/// UI must never crash because a field has an unexpected shape.
Map<String, dynamic> asMap(Object? value) {
  if (value is Map<String, dynamic>) {
    return value;
  }
  if (value is Map) {
    return value.map((key, item) => MapEntry('$key', item));
  }
  return const <String, dynamic>{};
}

List<dynamic> asList(Object? value) {
  if (value is List<dynamic>) {
    return value;
  }
  return const <dynamic>[];
}

String asText(Object? value, [String fallback = '']) {
  if (value == null) {
    return fallback;
  }
  return '$value';
}

class ContentRepository {
  /// [loadString] reads a text asset by path. It defaults to the Flutter asset
  /// bundle and can be replaced (for example in tests) with another reader.
  const ContentRepository({this.loadString});

  final Future<String> Function(String path)? loadString;

  static const String curriculumAsset = 'content/en/curriculum_map.json';

  Future<String> _read(String path) {
    final reader = loadString;
    if (reader != null) {
      return reader(path);
    }
    return rootBundle.loadString(path);
  }

  Future<Map<String, dynamic>> loadCurriculum() async {
    final raw = await _read(curriculumAsset);
    final decoded = jsonDecode(raw);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('curriculum_map.json must be a JSON object');
    }
    return decoded;
  }

  /// Chapter ids look like `a1.c1` or `pre_a1.c3`. They map to the asset folder
  /// `content/en/<level>/chapter_<NN>/lesson_l<N>.json`.
  String lessonAssetPath(String chapterId, int lessonNumber) {
    final parts = chapterId.split('.');
    if (parts.length != 2 || !parts[1].startsWith('c')) {
      throw FormatException('Unexpected chapter id: $chapterId');
    }
    final chapterNumber = int.tryParse(parts[1].substring(1));
    if (chapterNumber == null) {
      throw FormatException('Unexpected chapter id: $chapterId');
    }
    final folder = 'chapter_${chapterNumber.toString().padLeft(2, '0')}';
    return 'content/en/${parts[0]}/$folder/lesson_l$lessonNumber.json';
  }

  Future<List<Map<String, dynamic>>> loadLessons({
    required String chapterId,
    required int lessonCount,
  }) async {
    final lessons = <Map<String, dynamic>>[];
    for (var i = 1; i <= lessonCount; i++) {
      final raw = await _read(lessonAssetPath(chapterId, i));
      final decoded = jsonDecode(raw);
      if (decoded is! Map<String, dynamic>) {
        throw FormatException('Lesson $i of $chapterId is not a JSON object');
      }
      lessons.add(decoded);
    }
    return lessons;
  }
}

/// Name used inside English example sentences ("My name is ___").
///
/// Lesson content is authored with the example name `Masoud`. A learner's own
/// name replaces it only when it can be spoken as English text (contains Latin
/// letters); otherwise the authored example name is kept, because speech
/// recognition is English and would never match a Persian name.
String exampleName(String profileName) {
  final name = profileName.trim();
  if (RegExp(r'[A-Za-z]').hasMatch(name)) {
    return name;
  }
  return 'Masoud';
}

/// Returns a copy of [value] with the authored example name replaced.
/// Maps keep `String` keys so the result stays compatible with [asMap].
Object? personalizeContent(Object? value, String learnerName) {
  final name = exampleName(learnerName);
  if (name == 'Masoud') {
    return value;
  }
  return _replaceName(value, name);
}

Object? _replaceName(Object? value, String name) {
  if (value is String) {
    return value.replaceAll('Masoud', name);
  }
  if (value is List) {
    return value.map((item) => _replaceName(item, name)).toList();
  }
  if (value is Map) {
    return <String, dynamic>{
      for (final entry in value.entries)
        '${entry.key}': _replaceName(entry.value, name),
    };
  }
  return value;
}
