import 'dart:convert';

import 'package:flutter/services.dart' show rootBundle;

/// Safe accessors for decoded JSON. Content files are authored by hand, so the
/// UI must never crash because a field has an unexpected shape.
Map<String, dynamic> asMap(Object? value) {
  if (value is Map<String, dynamic>) {
    return value;
  }
  return const <String, dynamic>{};
}

List<dynamic> asList(Object? value) {
  if (value is List<dynamic>) {
    return value;
  }
  return const <dynamic>[];
}

String asText(Object? value, [String fallback = '']) {
  if (value == null) {
    return fallback;
  }
  return '$value';
}

class ContentRepository {
  const ContentRepository();

  static const String curriculumAsset = 'content/en/curriculum_map.json';

  Future<Map<String, dynamic>> loadCurriculum() async {
    final raw = await rootBundle.loadString(curriculumAsset);
    final decoded = jsonDecode(raw);
    if (decoded is! Map<String, dynamic>) {
      throw const FormatException('curriculum_map.json must be a JSON object');
    }
    return decoded;
  }

  /// Chapter ids look like `a1.c1` or `pre_a1.c3`. They map to the asset folder
  /// `content/en/<level>/chapter_<NN>/lesson_l<N>.json`.
  String lessonAssetPath(String chapterId, int lessonNumber) {
    final parts = chapterId.split('.');
    if (parts.length != 2 || !parts[1].startsWith('c')) {
      throw FormatException('Unexpected chapter id: $chapterId');
    }
    final chapterNumber = int.tryParse(parts[1].substring(1));
    if (chapterNumber == null) {
      throw FormatException('Unexpected chapter id: $chapterId');
    }
    final folder = 'chapter_${chapterNumber.toString().padLeft(2, '0')}';
    return 'content/en/${parts[0]}/$folder/lesson_l$lessonNumber.json';
  }

  Future<List<Map<String, dynamic>>> loadLessons({
    required String chapterId,
    required int lessonCount,
  }) async {
    final lessons = <Map<String, dynamic>>[];
    for (var i = 1; i <= lessonCount; i++) {
      final raw = await rootBundle.loadString(lessonAssetPath(chapterId, i));
      final decoded = jsonDecode(raw);
      if (decoded is! Map<String, dynamic>) {
        throw FormatException('Lesson $i of $chapterId is not a JSON object');
      }
      lessons.add(decoded);
    }
    return lessons;
  }
}
