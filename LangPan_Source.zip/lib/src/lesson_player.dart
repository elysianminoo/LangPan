import 'package:flutter/material.dart';

import 'content_repository.dart';
import 'panda.dart';
import 'profile_store.dart';
import 'speech_practice.dart';
import 'theme.dart';
import 'widgets.dart';

class LessonPlayer extends StatefulWidget {
  const LessonPlayer({required this.lesson, super.key});
  final Map<String, dynamic> lesson;
  @override
  State<LessonPlayer> createState() => _LessonPlayerState();
}

class _LessonPlayerState extends State<LessonPlayer> {
  final PageController _controller = PageController();
  final ProfileStore _profileStore = ProfileStore();
  LearnerProfile _profile = const LearnerProfile();
  int _step = 0;
  bool _listeningRevealed = false;

  @override
  void initState() { super.initState(); _loadProfile(); }

  Future<void> _loadProfile() async {
    try {
      final p = await _profileStore.load();
      if (mounted) setState(() => _profile = p);
    } catch (_) {}
  }

  List<_LessonStep> get _steps {
    final l = widget.lesson;
    return [
      _LessonStep('اول موقعیت را بفهم', 'Context', _ContextStep(lesson: l)),
      _LessonStep('کلمات را با معنا و صدا یاد بگیر', 'Vocabulary', _VocabularyStep(words: asList(l['vocabulary']))),
      _LessonStep('ببین زبان چطور کار می‌کند', 'Notice → Explain', _GrammarStep(grammar: asMap(l['grammar']))),
      _LessonStep('گوش بده و معنی را استخراج کن', 'Listening', _ListeningStep(data: asMap(l['listening']), revealed: _listeningRevealed, onReveal: () => setState(() => _listeningRevealed = true))),
      _LessonStep('صدای خودت را وارد یادگیری کن', 'Speaking', _SpeakingStep(data: asMap(l['speaking']), name: _profile.name)),
      _LessonStep('با پاندا از دانسته‌ات استفاده کن', 'Conversation', _ConversationStep(data: asMap(l['panda_conversation']), name: _profile.name)),
      _LessonStep('بدون کمک از حافظه بیرون بکش', 'Retrieval', _RetrievalStep(items: asList(l['retrieval']))),
      _LessonStep('دانسته را در یک کار کوچک تولید کن', 'Production', _ProductionStep(lesson: l, name: _profile.name)),
      _LessonStep('شواهد یادگیری را بررسی کن', 'Assessment', _AssessmentStep(data: asMap(l['assessment']))),
    ];
  }

  void _go(int target) {
    setState(() { _step = target; _listeningRevealed = false; });
    _controller.animateToPage(target, duration: const Duration(milliseconds: 280), curve: Curves.easeOutCubic);
  }

  Future<void> _next() async {
    if (_step < _steps.length - 1) { _go(_step + 1); return; }
    await showDialog<void>(context: context, builder: (dialogContext) => AlertDialog(
      title: const Text('درس ثبت شد 🎉'),
      content: const Text('این پایان یادگیری نیست؛ نتیجه این درس باید در مرورهای بعدی دوباره سنجیده شود.'),
      actions: [TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: const Text('باشه'))],
    ));
    if (mounted) Navigator.of(context).pop();
  }

  @override
  void dispose() { _controller.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final steps = _steps;
    final progress = (_step + 1) / steps.length;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        leading: IconButton(onPressed: () => Navigator.of(context).pop(), icon: const Icon(Icons.close_rounded)),
        title: Text(asText(widget.lesson['title'], 'Lesson'), style: const TextStyle(fontWeight: FontWeight.w900)),
        actions: [Pill(asText(widget.lesson['cefr'], 'A1').toUpperCase()), const SizedBox(width: 10)],
      ),
      body: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(18, 2, 18, 12), child: Column(children: [
          Row(children: [Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: progress, minHeight: 9))), const SizedBox(width: 10), Text('${_step + 1}/${steps.length}', style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.muted))]),
          const SizedBox(height: 9),
          Row(children: [for (var i = 0; i < steps.length; i++) Expanded(child: Container(margin: EdgeInsets.only(left: i == steps.length - 1 ? 0 : 3), height: 4, decoration: BoxDecoration(color: i <= _step ? AppColors.blue : AppColors.border, borderRadius: BorderRadius.circular(99))))]),
        ])),
        Expanded(child: PageView.builder(controller: _controller, physics: const NeverScrollableScrollPhysics(), itemCount: steps.length, itemBuilder: (_, i) {
          final step = steps[i];
          return ListView(padding: const EdgeInsets.fromLTRB(18, 0, 18, 24), children: [
            Row(children: [Pill(step.label, color: AppColors.softBlue, foreground: AppColors.blue), const SizedBox(width: 8), Expanded(child: Text(step.title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: AppColors.ink)))]),
            const SizedBox(height: 5),
            Text(_stepHint(i), style: const TextStyle(color: AppColors.muted, height: 1.45)),
            const SizedBox(height: 15),
            step.body,
          ];
        })),
        Container(padding: const EdgeInsets.fromLTRB(18, 10, 18, 16), decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: AppColors.border))), child: Row(children: [
          if (_step > 0) ...[SizedBox(width: 88, height: 50, child: OutlinedButton(onPressed: () => _go(_step - 1), child: const Text('قبلی'))), const SizedBox(width: 10)],
          Expanded(child: SizedBox(height: 50, child: FilledButton.icon(onPressed: _next, icon: Icon(_step == steps.length - 1 ? Icons.verified_rounded : Icons.arrow_back_rounded), label: Text(_step == steps.length - 1 ? 'ثبت یادگیری' : 'ادامه')))),
        ])),
      ]),
    );
  }

  String _stepHint(int index) => const [
        'قبل از حفظ کردن، باید بدانی این زبان را کجا و برای چه کاری استفاده می‌کنی.',
        'واژه وقتی ماندگار می‌شود که معنی، صدا و کاربردش را با هم ببینی.',
        'اول الگو را در مثال ببین؛ بعد معلم توضیح می‌دهد چرا این ساختار درست است.',
        'یک بار بدون متن گوش بده، بعد با متن بررسی کن و دوباره گوش بده.',
        'اینجا نوبت تولید توست؛ اشتباه بخشی از داده یادگیری است.',
        'پاندا سؤال را در چارچوب درس جلو می‌برد و تو باید پاسخ واقعی بدهی.',
        'حالا کمک‌ها را کم می‌کنیم تا ببینیم چه چیزی واقعاً در حافظه مانده است.',
        'یادگیری وقتی کامل‌تر می‌شود که بتوانی هدف را در یک خروجی کوتاه به کار ببری.',
        'پایان صفحه با Mastery یکی نیست؛ شواهد را برای مرورهای بعدی نگه می‌داریم.',
      ][index];
}

class _LessonStep {
  const _LessonStep(this.title, this.label, this.body);
  final String title; final String label; final Widget body;
}

class _ContextStep extends StatelessWidget {
  const _ContextStep({required this.lesson});
  final Map<String, dynamic> lesson;
  @override
  Widget build(BuildContext context) => Column(children: [
    GradientCard(padding: const EdgeInsets.all(20), child: Stack(children: [
      Positioned(right: -5, bottom: -15, child: PandaCompanion(mood: PandaMood.happy, compact: true)),
      Padding(padding: const EdgeInsets.only(right: 100), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Pill('REAL-LIFE SCENE', icon: Icons.public_rounded, color: Color(0x33FFFFFF), foreground: Colors.white),
        const SizedBox(height: 14),
        Text(asText(lesson['scenario'], 'Meeting someone new'), style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900, height: 1.35)),
        const SizedBox(height: 8),
        Text(asText(lesson['communicative_goal']), style: const TextStyle(color: Colors.white70, height: 1.55)),
      ])),
    ])),
    const SizedBox(height: 14),
    PandaSpeechBubble(text: 'فعلاً حفظ نکن. اول موقعیت را در ذهنت بساز. هدف این درس این است که بتوانی همین کار را بیرون از برنامه انجام بدهی.'),
    const SizedBox(height: 8),
    AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('بعد از این درس باید بتوانی…', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
      const SizedBox(height: 10),
      for (final item in asList(lesson['can_do'])) Padding(padding: const EdgeInsets.only(bottom: 8), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.check_circle_rounded, size: 19, color: AppColors.mint), const SizedBox(width: 8), Expanded(child: Text('$item', style: const TextStyle(height: 1.45)))])),
    ])),
  ]);
}

class _VocabularyStep extends StatefulWidget {
  const _VocabularyStep({required this.words});
  final List<dynamic> words;
  @override State<_VocabularyStep> createState() => _VocabularyStepState();
}
class _VocabularyStepState extends State<_VocabularyStep> {
  int index = 0; bool meaning = false;
  @override
  Widget build(BuildContext context) {
    if (widget.words.isEmpty) return const AppCard(child: Text('واژه‌ای برای این درس ثبت نشده است.'));
    final word = asMap(widget.words[index % widget.words.length]);
    return Column(children: [
      AppCard(padding: const EdgeInsets.all(18), child: Column(children: [
        Row(children: [Pill('WORD ${index + 1}/${widget.words.length}', icon: Icons.translate_rounded, color: AppColors.softPurple, foreground: AppColors.indigo), const Spacer(), AudioPlayButton(text: asText(word['word']))]),
        const SizedBox(height: 24),
        Text(asText(word['word']), style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: AppColors.ink)),
        const SizedBox(height: 8),
        if (meaning) ...[Text(asText(word['meaning']), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.indigo)), const SizedBox(height: 14), Container(width: double.infinity, padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColors.softBlue, borderRadius: BorderRadius.circular(17)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('در جمله', style: TextStyle(fontSize: 11, color: AppColors.muted)), const SizedBox(height: 4), Text(asText(word['example']), style: const TextStyle(fontWeight: FontWeight.w800, height: 1.5))]), const SizedBox(height: 10), if (asText(word['note']).isNotEmpty) Text(asText(word['note']), style: const TextStyle(color: AppColors.muted, height: 1.5))],
        const SizedBox(height: 20),
        SizedBox(width: double.infinity, height: 48, child: FilledButton.icon(onPressed: () => setState(() => meaning = true), icon: const Icon(Icons.visibility_rounded), label: Text(meaning ? 'معنی را دیدی' : 'نمایش معنی'))),
      ])),
      const SizedBox(height: 12),
      Row(children: [Expanded(child: OutlinedButton(onPressed: index == 0 ? null : () => setState(() { index--; meaning = false; }), child: const Text('قبلی'))), const SizedBox(width: 10), Expanded(child: FilledButton(onPressed: index == widget.words.length - 1 ? null : () => setState(() { index++; meaning = false; }), child: const Text('واژه بعدی')))]),
      const SizedBox(height: 12),
      const PandaSpeechBubble(mood: PandaMood.thinking, text: 'صدای واژه را بشنو، معنی را حدس بزن، بعد مثال را ببین. این سه مرحله از حفظ کردنِ ترجمه قوی‌تر است.'),
    ]);
  }
}

class _GrammarStep extends StatelessWidget {
  const _GrammarStep({required this.grammar});
  final Map<String, dynamic> grammar;
  @override
  Widget build(BuildContext context) => Column(children: [
    AppCard(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [const Icon(Icons.school_rounded, color: AppColors.blue), const SizedBox(width: 8), Expanded(child: Text(asText(grammar['focus'], 'Grammar focus'), style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900))), const Pill('Teacher', icon: Icons.record_voice_over_rounded)]),
      const SizedBox(height: 14),
      _ExplainBlock(title: 'معنی', text: asText(grammar['meaning'], asText(grammar['explanation']))),
      _ExplainBlock(title: 'ساختار', text: asList(grammar['form']).join('\n')),
      _ExplainBlock(title: 'کاربرد', text: asText(grammar['use'], 'در موقعیت‌هایی استفاده می‌شود که هدف درس مشخص کرده است.')),
      if (asText(grammar['why']).isNotEmpty) _ExplainBlock(title: 'چرا؟', text: asText(grammar['why'])),
    ])),
    const SizedBox(height: 12),
    AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('مثال‌ها را مقایسه کن', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)), const SizedBox(height: 10), for (final ex in asList(grammar['examples'])) Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: AppColors.softBlue, borderRadius: BorderRadius.circular(15)), child: Text('$ex', style: const TextStyle(fontWeight: FontWeight.w700, height: 1.45))), const SizedBox(height: 5), if (asList(grammar['common_errors']).isNotEmpty) ...[const Text('خطاهای رایج', style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.error)), const SizedBox(height: 7), for (final e in asList(grammar['common_errors'])) Padding(padding: const EdgeInsets.only(bottom: 5), child: Text('$e', style: const TextStyle(height: 1.4)))] ])),
    const SizedBox(height: 10),
    const PandaSpeechBubble(mood: PandaMood.proud, text: 'من قرار نیست جای معلم را بگیرم. توضیح دقیق گرامر اینجاست؛ من فقط کمک می‌کنم آن را در موقعیت واقعی به کار ببری.'),
  ]);
}
class _ExplainBlock extends StatelessWidget {
  const _ExplainBlock({required this.title, required this.text});
  final String title; final String text;
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.indigo)), const SizedBox(height: 4), Text(text.isEmpty ? 'برای این درس توضیح تکمیلی ثبت نشده است.' : text, style: const TextStyle(height: 1.65))]));
}

class _ListeningStep extends StatelessWidget {
  const _ListeningStep({required this.data, required this.revealed, required this.onReveal});
  final Map<String, dynamic> data; final bool revealed; final VoidCallback onReveal;
  @override
  Widget build(BuildContext context) => Column(children: [
    GradientCard(padding: const EdgeInsets.all(18), child: Row(children: [const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('گوش بده', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w900)), SizedBox(height: 5), Text('یک بار برای معنی کلی، بار دوم برای جزئیات.', style: TextStyle(color: Colors.white70, height: 1.4))])), AudioPlayButton(text: asText(data['script']))])),
    const SizedBox(height: 12),
    AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('بعد از شنیدن، جواب را در ذهن بده', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)), const SizedBox(height: 10), for (final task in asList(data['tasks'])) Padding(padding: const EdgeInsets.only(bottom: 8), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.help_outline_rounded, size: 18, color: AppColors.indigo), const SizedBox(width: 7), Expanded(child: Text('$task', style: const TextStyle(height: 1.45)))])), const SizedBox(height: 6), OutlinedButton.icon(onPressed: onReveal, icon: const Icon(Icons.visibility_rounded), label: Text(revealed ? 'متن نمایش داده شده' : 'نمایش متن مکالمه')), if (revealed) ...[const SizedBox(height: 12), Container(width: double.infinity, padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColors.softBlue, borderRadius: BorderRadius.circular(16)), child: Text(asText(data['script']), style: const TextStyle(height: 1.7, fontWeight: FontWeight.w700)))] ])),
    const SizedBox(height: 10), const PandaSpeechBubble(mood: PandaMood.listening, text: 'اگر یک کلمه را نگرفتی، اول معنی کلی را بگیر. بعد با متن مقایسه کن و دوباره گوش بده.'),
  ]);
}

class _SpeakingStep extends StatelessWidget {
  const _SpeakingStep({required this.data, required this.name});
  final Map<String, dynamic> data; final String name;
  @override
  Widget build(BuildContext context) {
    final variants = asList(data['accepted_variants']).map((item) => '$item').toList();
    return SpeechPracticeCard(prompt: asText(data['prompt'], 'Answer naturally.'), name: name, expectedVariants: variants.isEmpty ? ['My name is ${exampleName(name)}.', "I'm ${exampleName(name)}.", 'I am ${exampleName(name)}.'] : variants);
  }
}

class _ConversationStep extends StatelessWidget {
  const _ConversationStep({required this.data, required this.name});
  final Map<String, dynamic> data; final String name;
  @override
  Widget build(BuildContext context) => Column(children: [
    PandaSpeechBubble(mood: PandaMood.speaking, text: 'حالا وارد گفت‌وگوی کوتاه می‌شویم. پاسخ تو باید از زبان خودت بیاید؛ اگر لازم باشد دوباره تلاش می‌کنیم.'),
    AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('سناریو', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)), const SizedBox(height: 10), for (final t in asList(data['turns'])) Padding(padding: const EdgeInsets.only(bottom: 7), child: Text('$t'.replaceAll('Alex', exampleName(name)), style: const TextStyle(height: 1.5)))])),
    const SizedBox(height: 12),
    SpeechPracticeCard(prompt: _conversationPrompt(data), name: name, expectedVariants: _conversationVariants(data, name)),
  ]);
  String _conversationPrompt(Map<String, dynamic> data) => asList(data['turns']).isEmpty ? 'Answer Panda naturally.' : asText(asList(data['turns']).first).replaceFirst('Panda:', '').trim();
  List<String> _conversationVariants(Map<String, dynamic> data, String name) { final raw = asList(data['accepted_variants']); if (raw.isNotEmpty) return raw.map((item) => '$item').map((x) => x.replaceAll('Alex', exampleName(name))).toList(); return ['My name is ${exampleName(name)}.', "I'm ${exampleName(name)}.", 'I am ${exampleName(name)}.']; }
}

class _RetrievalStep extends StatefulWidget {
  const _RetrievalStep({required this.items});
  final List<dynamic> items;
  @override State<_RetrievalStep> createState() => _RetrievalStepState();
}
class _RetrievalStepState extends State<_RetrievalStep> {
  final Set<int> done = {};
  @override
  Widget build(BuildContext context) => Column(children: [const PandaSpeechBubble(mood: PandaMood.thinking, text: 'کتاب را نبین. اول پاسخ را از حافظه بساز؛ بعد تیک بزن. همین تلاشِ بازیابی بخشی از یادگیری است.'), AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('چالش بازیابی', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)), const SizedBox(height: 5), const Text('هر مورد را واقعاً انجام بده، نه اینکه فقط آن را بخوانی.', style: TextStyle(color: AppColors.muted)), const SizedBox(height: 10), for (var i = 0; i < widget.items.length; i++) CheckboxListTile(contentPadding: EdgeInsets.zero, value: done.contains(i), onChanged: (v) => setState(() { if (v == true) done.add(i); else done.remove(i); }), title: Text('${widget.items[i]}', style: const TextStyle(height: 1.45)), activeColor: AppColors.blue)]))]);
}

class _ProductionStep extends StatefulWidget {
  const _ProductionStep({required this.lesson, required this.name});
  final Map<String, dynamic> lesson; final String name;
  @override State<_ProductionStep> createState() => _ProductionStepState();
}
class _ProductionStepState extends State<_ProductionStep> {
  final controller = TextEditingController();
  @override void dispose() { controller.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Column(children: [AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('یک خروجی کوتاه بساز', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)), const SizedBox(height: 5), Text(asText(asMap(widget.lesson['writing'])['prompt'], 'Write a short response.'), style: const TextStyle(color: AppColors.muted, height: 1.5)), const SizedBox(height: 12), TextField(controller: controller, minLines: 4, maxLines: 6, textDirection: TextDirection.ltr, onChanged: (_) => setState(() {}), decoration: const InputDecoration(hintText: 'Write here…')), const SizedBox(height: 10), SizedBox(width: double.infinity, height: 48, child: FilledButton.icon(onPressed: controller.text.isEmpty ? null : () => setState(() {}), icon: const Icon(Icons.check_rounded), label: const Text('ثبت تولید')))])), const SizedBox(height: 12), const PandaSpeechBubble(mood: PandaMood.encouraging, text: 'در تولید، کامل بودن از اولین تلاش مهم نیست. هدف این است که زبان هدف را برای یک کار واقعی به کار ببری.')]);
}

class _AssessmentStep extends StatelessWidget {
  const _AssessmentStep({required this.data});
  final Map<String, dynamic> data;
  @override Widget build(BuildContext context) => Column(children: [GradientCard(padding: const EdgeInsets.all(20), child: Row(children: [const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Evidence of learning', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w800)), SizedBox(height: 5), Text('یادگیری را با عملکرد می‌سنجیم', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w900)), SizedBox(height: 6), Text('پایان درس فقط یک نقطه داده است؛ مرورهای بعدی مهم‌اند.', style: TextStyle(color: Colors.white70, height: 1.4))])), PandaCompanion(compact: true, mood: PandaMood.proud)])), const SizedBox(height: 12), AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('معیارهای این درس', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)), const SizedBox(height: 8), for (final item in asList(data['items'])) ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.verified_rounded, color: AppColors.mint), title: Text(asText(asMap(item)['type']), style: const TextStyle(fontWeight: FontWeight.w800)), subtitle: Text(asText(asMap(item)['pass_rule'])))])), const SizedBox(height: 10), const PandaSpeechBubble(mood: PandaMood.proud, text: 'اگر یک مهارت ضعیف باشد، مسیر باید همان ضعف را پیدا کند و برایش Recovery بسازد؛ نه اینکه فقط درس بعدی را باز کند.')]);
}
