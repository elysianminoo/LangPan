import 'package:flutter/material.dart';

import 'content_repository.dart';
import 'theme.dart';
import 'widgets.dart';

class LessonPlayer extends StatefulWidget {
  const LessonPlayer({required this.lesson, super.key});

  final Map<String, dynamic> lesson;

  @override
  State<LessonPlayer> createState() => _LessonPlayerState();
}

class _LessonPlayerState extends State<LessonPlayer> {
  int _step = 0;

  List<_LessonStep> get _steps {
    final lesson = widget.lesson;
    return [
      _LessonStep('هدف امروز', _ObjectiveBlock(lesson: lesson)),
      _LessonStep(
        'واژگان',
        _VocabularyBlock(words: asList(lesson['vocabulary'])),
      ),
      _LessonStep('گرامر', _GrammarBlock(grammar: asMap(lesson['grammar']))),
      _LessonStep(
        'شنیداری',
        _ListeningBlock(data: asMap(lesson['listening'])),
      ),
      _LessonStep('مکالمه', _SpeakingBlock(data: asMap(lesson['speaking']))),
      _LessonStep(
        'گفت‌وگو با پاندا',
        _PandaConversationBlock(data: asMap(lesson['panda_conversation'])),
      ),
      _LessonStep(
        'بازیابی',
        _RetrievalBlock(items: asList(lesson['retrieval'])),
      ),
      _LessonStep(
        'ارزیابی',
        _AssessmentBlock(data: asMap(lesson['assessment'])),
      ),
    ];
  }

  Future<void> _next(int total) async {
    if (_step < total - 1) {
      setState(() => _step++);
      return;
    }
    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('آفرین! 🎉'),
          content: const Text(
            'درس را کامل کردی. حالا می‌توانی درس بعدی را انتخاب کنی.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('باشه'),
            ),
          ],
        );
      },
    );
    if (!mounted) {
      return;
    }
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final steps = _steps;
    final current = steps[_step];
    final isLast = _step == steps.length - 1;

    return Scaffold(
      appBar: AppBar(
        title: Text(asText(widget.lesson['title'])),
        actions: [
          IconButton(
            onPressed: () => showComingSoon(context),
            icon: const Icon(Icons.bookmark_border),
          ),
        ],
      ),
      body: Column(
        children: [
          LinearProgressIndicator(
            value: (_step + 1) / steps.length,
            minHeight: 5,
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: PandaAvatar(size: 72),
                ),
                const SizedBox(height: 12),
                Text(
                  current.title,
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                    color: AppColors.ink,
                  ),
                ),
                const SizedBox(height: 16),
                current.body,
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 18),
            child: Row(
              children: [
                if (_step > 0) ...[
                  SizedBox(
                    height: 54,
                    child: OutlinedButton(
                      onPressed: () => setState(() => _step--),
                      child: const Text('قبلی'),
                    ),
                  ),
                  const SizedBox(width: 12),
                ],
                Expanded(
                  child: SizedBox(
                    height: 54,
                    child: FilledButton(
                      onPressed: () => _next(steps.length),
                      child: Text(isLast ? 'پایان درس' : 'ادامه'),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _LessonStep {
  const _LessonStep(this.title, this.body);

  final String title;
  final Widget body;
}

class _ObjectiveBlock extends StatelessWidget {
  const _ObjectiveBlock({required this.lesson});

  final Map<String, dynamic> lesson;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            asText(lesson['scenario']),
            style: const TextStyle(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 12),
          for (final item in asList(lesson['can_do']))
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(
                    Icons.check_circle,
                    color: AppColors.green,
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Expanded(child: Text('$item')),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _VocabularyBlock extends StatelessWidget {
  const _VocabularyBlock({required this.words});

  final List<dynamic> words;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        for (final item in words)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Card(
              child: ListTile(
                title: Text(
                  asText(asMap(item)['word']),
                  textAlign: TextAlign.start,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                subtitle: Text(
                  '${asText(asMap(item)['meaning'])}\n'
                  '${asText(asMap(item)['example'])}',
                ),
                trailing: IconButton(
                  onPressed: () => showComingSoon(context),
                  icon: const Icon(Icons.volume_up_outlined),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class _GrammarBlock extends StatelessWidget {
  const _GrammarBlock({required this.grammar});

  final Map<String, dynamic> grammar;

  @override
  Widget build(BuildContext context) {
    final examples = asList(grammar['examples']);
    final errors = asList(grammar['common_errors']);
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            asText(grammar['focus']),
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 12),
          Text(asText(grammar['explanation'])),
          if (examples.isNotEmpty) ...[
            const SizedBox(height: 16),
            const Text('مثال‌ها', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            for (final example in examples) Text('• $example'),
          ],
          if (errors.isNotEmpty) ...[
            const SizedBox(height: 16),
            const Text(
              'خطاهای رایج',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 6),
            for (final error in errors) Text('• $error'),
          ],
        ],
      ),
    );
  }
}

class _ListeningBlock extends StatefulWidget {
  const _ListeningBlock({required this.data});

  final Map<String, dynamic> data;

  @override
  State<_ListeningBlock> createState() => _ListeningBlockState();
}

class _ListeningBlockState extends State<_ListeningBlock> {
  bool _showScript = false;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'گوش بده و نکته اصلی را پیدا کن',
            style: TextStyle(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 4),
          const Text(
            'پخش صدا در نسخه‌های بعدی فعال می‌شود؛ فعلاً می‌توانی متن را ببینی.',
            style: TextStyle(color: AppColors.muted),
          ),
          const SizedBox(height: 14),
          OutlinedButton.icon(
            onPressed: () => setState(() => _showScript = !_showScript),
            icon: Icon(_showScript ? Icons.visibility_off : Icons.visibility),
            label: Text(_showScript ? 'پنهان کردن متن' : 'نمایش متن'),
          ),
          if (_showScript) ...[
            const SizedBox(height: 14),
            Text(
              asText(widget.data['script']),
              style: const TextStyle(fontSize: 18, height: 1.5),
            ),
          ],
        ],
      ),
    );
  }
}

class _SpeakingBlock extends StatelessWidget {
  const _SpeakingBlock({required this.data});

  final Map<String, dynamic> data;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            asText(data['prompt']),
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 18),
          Center(
            child: IconButton.filled(
              onPressed: () => showComingSoon(context),
              icon: const Icon(Icons.mic, size: 34),
            ),
          ),
          const SizedBox(height: 12),
          const Center(child: Text('برای ضبط پاسخ لمس کن')),
        ],
      ),
    );
  }
}

class _PandaConversationBlock extends StatelessWidget {
  const _PandaConversationBlock({required this.data});

  final Map<String, dynamic> data;

  @override
  Widget build(BuildContext context) {
    final turns = asList(data['turns']);
    return AppCard(
      child: Column(
        children: [
          for (final turn in turns) _Bubble(text: '$turn'),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: () => showComingSoon(context),
            icon: const Icon(Icons.chat_bubble_outline),
            label: const Text('شروع گفت‌وگو'),
          ),
        ],
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final fromPanda = text.startsWith('Panda');
    final color = fromPanda ? AppColors.blue : AppColors.green;
    return Align(
      alignment: fromPanda ? Alignment.centerLeft : Alignment.centerRight,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withValues(alpha: .08),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Text(text, textDirection: TextDirection.ltr),
      ),
    );
  }
}

class _RetrievalBlock extends StatelessWidget {
  const _RetrievalBlock({required this.items});

  final List<dynamic> items;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        for (var i = 0; i < items.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Card(
              child: ListTile(
                leading: CircleAvatar(child: Text('${i + 1}')),
                title: Text('${items[i]}'),
                trailing: const Icon(Icons.psychology_outlined),
              ),
            ),
          ),
      ],
    );
  }
}

class _AssessmentBlock extends StatelessWidget {
  const _AssessmentBlock({required this.data});

  final Map<String, dynamic> data;

  @override
  Widget build(BuildContext context) {
    final items = asList(data['items']);
    return Column(
      children: [
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'معیار قبولی',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 8),
              Text(asText(data['pass_rule'])),
            ],
          ),
        ),
        const SizedBox(height: 10),
        for (final item in items)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Card(
              child: ListTile(
                title: Text(asText(asMap(item)['type'])),
                subtitle: Text(asText(asMap(item)['pass_rule'])),
              ),
            ),
          ),
      ],
    );
  }
}
