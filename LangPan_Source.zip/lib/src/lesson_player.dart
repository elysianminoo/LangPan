import 'package:flutter/material.dart';

import 'content_repository.dart';
import 'panda.dart';
import 'profile_store.dart';
import 'speech_practice.dart';
import 'theme.dart';
import 'widgets.dart';

class LessonPlayer extends StatefulWidget {
  const LessonPlayer({required this.lesson, super.key});

  final Map<String, dynamic> lesson;

  @override
  State<LessonPlayer> createState() => _LessonPlayerState();
}

class _LessonPlayerState extends State<LessonPlayer> {
  static const List<String> _hints = [
    'اول معنی را در موقعیت ببین.',
    'کلمه را با مثال و کاربردش نگه دار.',
    'اول مفهوم؛ بعد شکل جمله.',
    'گوش بده و از صدا معنی را استخراج کن.',
    'دانسته را به تولید واقعی تبدیل کن.',
    'پاندا نقش شریک مکالمه را دارد.',
    'بدون نگاه کردن اطلاعات را از حافظه بیرون بکش.',
    'حالا ببینیم واقعاً چه چیزی یاد گرفته‌ای.',
  ];

  final PageController _controller = PageController();
  final ProfileStore _profileStore = ProfileStore();
  LearnerProfile _profile = const LearnerProfile();
  int _step = 0;
  bool _revealed = false;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    try {
      final profile = await _profileStore.load();
      if (!mounted) return;
      setState(() => _profile = profile);
    } catch (_) {
      // Keep the lesson usable in widget tests where platform plugins are absent.
    }
  }


  List<_LessonStep> get _steps {
    final l = widget.lesson;
    return [
      _LessonStep('شروع از یک موقعیت واقعی', _ContextStep(lesson: l)),
      _LessonStep(
        'کلمات را در جمله یاد بگیر',
        _VocabularyStep(words: asList(l['vocabulary'])),
      ),
      _LessonStep(
        'گرامر را بفهم، نه حفظ کن',
        _GrammarStep(grammar: asMap(l['grammar'])),
      ),
      _LessonStep(
        'شنیدن قبل از حدس زدن',
        _ListeningStep(
          data: asMap(l['listening']),
          revealed: _revealed,
          onReveal: () => setState(() => _revealed = true),
        ),
      ),
      _LessonStep(
        'حالا خودت تولید کن',
        _SpeakingStep(
          data: asMap(l['speaking']),
          name: _profile.name,
        ),
      ),
      _LessonStep(
        'مکالمه با پاندا',
        _ConversationStep(
          data: asMap(l['panda_conversation']),
          name: _profile.name,
        ),
      ),
      _LessonStep(
        'بازیابی بدون کمک',
        _RetrievalStep(items: asList(l['retrieval'])),
      ),
      _LessonStep(
        'بررسی یادگیری',
        _AssessmentStep(data: asMap(l['assessment'])),
      ),
    ];
  }

  void _goTo(int step) {
    setState(() {
      _step = step;
      _revealed = false;
    });
    _controller.animateToPage(
      step,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOutCubic,
    );
  }

  Future<void> _next(int total) async {
    if (_step < total - 1) {
      _goTo(_step + 1);
      return;
    }
    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('درس کامل شد 🎉'),
          content: const Text(
            'این فقط پایان یک صفحه نیست؛ شواهد یادگیری تو حالا وارد چرخه مرور می‌شود.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('باشه'),
            ),
          ],
        );
      },
    );
    if (!mounted) {
      return;
    }
    Navigator.of(context).pop();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final steps = _steps;
    final progress = (_step + 1) / steps.length;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Navigator.of(context).pop(),
          icon: const Icon(Icons.close_rounded),
        ),
        title: Text(
          'درس ${_step + 1} از ${steps.length}',
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        actions: [
          Pill(asText(widget.lesson['cefr'], 'A1').toUpperCase()),
          const SizedBox(width: 12),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 14),
            child: Row(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(99),
                    child: LinearProgressIndicator(value: progress, minHeight: 8),
                  ),
                ),
                const SizedBox(width: 12),
                Text(
                  '${(progress * 100).round()}%',
                  style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    color: AppColors.muted,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: PageView.builder(
              controller: _controller,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: steps.length,
              itemBuilder: (context, i) {
                final step = steps[i];
                return ListView(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                  children: [
                    Text(
                      step.title,
                      style: const TextStyle(
                        fontSize: 27,
                        fontWeight: FontWeight.w900,
                        color: AppColors.ink,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      _hints[i],
                      style: const TextStyle(
                        color: AppColors.muted,
                        height: 1.45,
                      ),
                    ),
                    const SizedBox(height: 18),
                    step.body,
                  ],
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 18),
            decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(top: BorderSide(color: AppColors.border)),
            ),
            child: Row(
              children: [
                if (_step > 0) ...[
                  OutlinedButton(
                    onPressed: () => _goTo(_step - 1),
                    child: const Text('قبلی'),
                  ),
                  const SizedBox(width: 10),
                ],
                Expanded(
                  child: SizedBox(
                    height: 52,
                    child: FilledButton(
                      onPressed: () => _next(steps.length),
                      child: Text(
                        _step == steps.length - 1 ? 'ثبت یادگیری' : 'ادامه',
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _LessonStep {
  const _LessonStep(this.title, this.body);

  final String title;
  final Widget body;
}

class _ContextStep extends StatelessWidget {
  const _ContextStep({required this.lesson});

  final Map<String, dynamic> lesson;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        GradientCard(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Pill(
                  'REAL-LIFE SCENE',
                  icon: Icons.place_rounded,
                  color: Color(0x33FFFFFF),
                  foreground: Colors.white,
                ),
                const SizedBox(height: 15),
                Text(
                  asText(lesson['scenario'], 'Meeting someone new'),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  asText(lesson['communicative_goal']),
                  style: const TextStyle(color: Colors.white70, height: 1.5),
                ),
                const SizedBox(height: 12),
                const Text(
                  'هدف: بعد از این درس باید بتوانی همین کار را در یک موقعیت واقعی انجام بدهی.',
                  style: TextStyle(color: Colors.white, height: 1.5),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        const PandaSpeechBubble(
          text:
              'اول فقط گوش کن و موقعیت را تصور کن. لازم نیست هنوز چیزی را حفظ کنی؛ قرار است معنی را از دل موقعیت بفهمیم.',
        ),
        const SizedBox(height: 10),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Can-Do',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17),
              ),
              const SizedBox(height: 10),
              for (final item in asList(lesson['can_do']))
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(
                        Icons.check_circle_rounded,
                        color: AppColors.mint,
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text('$item', style: const TextStyle(height: 1.4)),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

class _VocabularyStep extends StatefulWidget {
  const _VocabularyStep({required this.words});

  final List<dynamic> words;

  @override
  State<_VocabularyStep> createState() => _VocabularyStepState();
}

class _VocabularyStepState extends State<_VocabularyStep> {
  int _index = 0;
  bool _show = false;

  @override
  Widget build(BuildContext context) {
    final words = widget.words;
    if (words.isEmpty) {
      return const Text('واژگان این درس هنوز ثبت نشده است.');
    }
    final w = asMap(words[_index % words.length]);
    return Column(
      children: [
        AppCard(
          padding: const EdgeInsets.all(22),
          child: Column(
            children: [
              Row(
                children: [
                  Pill(
                    'واژه ${_index + 1}/${words.length}',
                    icon: Icons.translate_rounded,
                  ),
                  const Spacer(),
                  AudioPlayButton(
                    text: '${w['word']}. ${w['example']}',
                    tooltip: 'شنیدن واژه و مثال',
                  ),
                ],
              ),
              const SizedBox(height: 25),
              Text(
                asText(w['word']),
                style: const TextStyle(
                  fontSize: 35,
                  fontWeight: FontWeight.w900,
                  color: AppColors.ink,
                ),
              ),
              const SizedBox(height: 12),
              AnimatedCrossFade(
                firstChild: const Text(
                  'اول خودت حدس بزن…',
                  style: TextStyle(color: AppColors.muted),
                ),
                secondChild: Column(
                  children: [
                    Text(
                      asText(w['meaning']),
                      style: const TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      asText(w['example']),
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 16, height: 1.5),
                    ),
                  ],
                ),
                crossFadeState: _show
                    ? CrossFadeState.showSecond
                    : CrossFadeState.showFirst,
                duration: const Duration(milliseconds: 220),
              ),
              const SizedBox(height: 22),
              FilledButton.tonal(
                onPressed: () => setState(() => _show = !_show),
                child: Text(_show ? 'پنهان کن' : 'معنی و مثال را ببین'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: _index == 0
                    ? null
                    : () => setState(() {
                        _index--;
                        _show = false;
                      }),
                child: const Text('قبلی'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: FilledButton(
                onPressed: () => setState(() {
                  _index = (_index + 1) % words.length;
                  _show = false;
                }),
                child: const Text('واژه بعدی'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        const PandaSpeechBubble(
          text:
              'واژه را تنها حفظ نکن. جمله‌ای که کنارش دیدی همان چیزی است که بعداً در مکالمه می‌خواهیم از حافظه‌ات بیرون بکشیم.',
        ),
      ],
    );
  }
}

class _GrammarStep extends StatelessWidget {
  const _GrammarStep({required this.grammar});

  final Map<String, dynamic> grammar;

  @override
  Widget build(BuildContext context) {
    final forms = asList(grammar['form']);
    final examples = asList(grammar['examples']);
    final errors = asList(grammar['common_errors']);
    final why = asText(grammar['why']);

    return Column(
      children: [
        const PandaSpeechBubble(
          mood: PandaMood.thinking,
          text:
              'این قسمت را مثل کلاس واقعی می‌بینیم: معنی → شکل → کاربرد. اگر فقط فرمول را حفظ کنی، در مکالمه گیر می‌کنی.',
        ),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Pill(asText(grammar['focus'], 'Grammar')),
              const SizedBox(height: 16),
              Text(
                asText(grammar['explanation']),
                style: const TextStyle(fontSize: 16, height: 1.7),
              ),
              if (forms.isNotEmpty) ...[
                const SizedBox(height: 18),
                const Text(
                  'الگوی ساده',
                  style: TextStyle(fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 8),
                for (final f in forms) _ExampleLine('$f'),
              ],
              if (examples.isNotEmpty) ...[
                const SizedBox(height: 16),
                const Text(
                  'مثال در موقعیت',
                  style: TextStyle(fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 8),
                for (final e in examples) _ExampleLine('$e'),
              ],
              if (errors.isNotEmpty) ...[
                const SizedBox(height: 16),
                const Text(
                  'حواست به این اشتباه باشد',
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    color: AppColors.error,
                  ),
                ),
                const SizedBox(height: 7),
                for (final e in errors) Text('• $e'),
              ],
            ],
          ),
        ),
        if (why.isNotEmpty) ...[
          const SizedBox(height: 12),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'چرا؟',
                  style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17),
                ),
                const SizedBox(height: 7),
                Text(
                  why,
                  style: const TextStyle(height: 1.65, color: AppColors.muted),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}

class _ExampleLine extends StatelessWidget {
  const _ExampleLine(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 7),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.softBlue,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(text, style: const TextStyle(fontWeight: FontWeight.w700)),
    );
  }
}

class _ListeningStep extends StatelessWidget {
  const _ListeningStep({
    required this.data,
    required this.revealed,
    required this.onReveal,
  });

  final Map<String, dynamic> data;
  final bool revealed;
  final VoidCallback onReveal;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Pill(
                'LISTENING LAB',
                icon: Icons.headphones_rounded,
                color: AppColors.softPurple,
              ),
              const SizedBox(height: 15),
              const Text(
                'اول گوش بده؛ متن را هنوز نبین.',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 14),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                decoration: BoxDecoration(
                  color: AppColors.ink,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'پخش نمونه مکالمه',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    AudioPlayButton(text: asText(data['script'])),
                  ],
                ),
              ),
              const SizedBox(height: 15),
              if (revealed)
                Text(
                  asText(data['script']),
                  style: const TextStyle(
                    height: 1.7,
                    fontWeight: FontWeight.w600,
                  ),
                )
              else
                const Text(
                  'بعد از یک بار شنیدن، متن را باز کن و دوباره مقایسه کن.',
                  style: TextStyle(color: AppColors.muted),
                ),
              const SizedBox(height: 13),
              OutlinedButton.icon(
                onPressed: onReveal,
                icon: const Icon(Icons.visibility_outlined),
                label: Text(revealed ? 'متن باز شد' : 'نمایش متن'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        const PandaSpeechBubble(
          mood: PandaMood.listening,
          text:
              'اگر یک کلمه را نگرفتی، نگران نباش. اول معنی کلی را بگیر؛ بعد سراغ جزئیات برو.',
        ),
      ],
    );
  }
}

class _SpeakingStep extends StatelessWidget {
  const _SpeakingStep({required this.data, required this.name});

  final Map<String, dynamic> data;
  final String name;

  @override
  Widget build(BuildContext context) {
    final variants = asList(data['accepted_variants'])
        .map((item) => '$item')
        .toList();
    return SpeechPracticeCard(
      prompt: asText(data['prompt'], 'Answer Panda naturally.'),
      name: name,
      expectedVariants: variants.isEmpty
          ? [
              'My name is ${exampleName(name)}.',
              "I'm ${exampleName(name)}.",
              'I am ${exampleName(name)}.',
            ]
          : variants,
    );
  }
}

class _ConversationStep extends StatelessWidget {
  const _ConversationStep({required this.data, required this.name});

  final Map<String, dynamic> data;
  final String name;

  String _personalize(String value) =>
      value.replaceAll('Masoud', exampleName(name));

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        PandaSpeechBubble(
          mood: PandaMood.happy,
          text:
              'من فقط سؤال نمی‌پرسم؛ به پاسخ تو گوش می‌دهم و بر اساس همان درس بازخورد می‌دهم. از یک معرفی ساده شروع کنیم.',
        ),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'سناریوی مکالمه',
                style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 12),
              for (final t in asList(data['turns']))
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(
                    _personalize('$t'),
                    style: const TextStyle(height: 1.5),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        SpeechPracticeCard(
          prompt: "Panda: Hi! What's your name?",
          name: name,
          expectedVariants: [
            'My name is ${exampleName(name)}.',
            "I'm ${exampleName(name)}.",
            'I am ${exampleName(name)}.',
            exampleName(name),
          ],
        ),
      ],
    );
  }
}

class _RetrievalStep extends StatefulWidget {
  const _RetrievalStep({required this.items});

  final List<dynamic> items;

  @override
  State<_RetrievalStep> createState() => _RetrievalStepState();
}

class _RetrievalStepState extends State<_RetrievalStep> {
  final Set<int> _done = <int>{};

  @override
  Widget build(BuildContext context) {
    final items = widget.items;
    return Column(
      children: [
        const PandaSpeechBubble(
          mood: PandaMood.thinking,
          text:
              'حالا کتاب را ببند. اگر بتوانی بدون دیدن پاسخ را تولید کنی، یادگیری از «آشنایی» به «بازیابی» نزدیک شده است.',
        ),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'چالش بازیابی',
                style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 6),
              const Text(
                'هر مورد را اول از حافظه جواب بده، بعد علامت بزن.',
                style: TextStyle(color: AppColors.muted, height: 1.5),
              ),
              const SizedBox(height: 10),
              if (items.isEmpty)
                const Text('خودت یک جمله با عبارت هدف بساز.')
              else
                for (var i = 0; i < items.length; i++)
                  CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    controlAffinity: ListTileControlAffinity.leading,
                    value: _done.contains(i),
                    onChanged: (checked) {
                      setState(() {
                        if (checked ?? false) {
                          _done.add(i);
                        } else {
                          _done.remove(i);
                        }
                      });
                    },
                    title: Text(
                      '${items[i]}',
                      textAlign: TextAlign.start,
                      style: const TextStyle(height: 1.5),
                    ),
                  ),
            ],
          ),
        ),
      ],
    );
  }
}

class _AssessmentStep extends StatelessWidget {
  const _AssessmentStep({required this.data});

  final Map<String, dynamic> data;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const GradientCard(
          child: Padding(
            padding: EdgeInsets.all(22),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.verified_rounded, color: Colors.white, size: 34),
                SizedBox(height: 12),
                Text(
                  'یادگیری را با شواهد می‌سنجیم',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  'تمام شدن صفحه به معنی Mastered شدن نیست. عملکرد تو در بازیابی، تولید و مرورهای بعدی معیار اصلی است.',
                  style: TextStyle(color: Colors.white, height: 1.55),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'معیارهای این درس',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 12),
              for (final item in asList(data['items']))
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(
                    Icons.check_circle_outline_rounded,
                    color: AppColors.mint,
                  ),
                  title: Text(asText(asMap(item)['type'])),
                  subtitle: Text(asText(asMap(item)['pass_rule'])),
                ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        const PandaSpeechBubble(
          mood: PandaMood.proud,
          text:
              'اگر هنوز یک بخش ضعیف باشد، به‌جای جلو رفتن کورکورانه، یک Recovery کوتاه برای همان ضعف می‌سازیم.',
        ),
      ],
    );
  }
}
