import 'package:flutter/material.dart';

import 'panda.dart';
import 'profile_store.dart';
import 'theme.dart';
import 'widgets.dart';

/// Splash → 3 onboarding pages → optional name → enter app
class OnboardingFlow extends StatefulWidget {
  const OnboardingFlow({required this.onFinished, super.key});

  final Future<void> Function(LearnerProfile profile) onFinished;

  @override
  State<OnboardingFlow> createState() => _OnboardingFlowState();
}

class _OnboardingFlowState extends State<OnboardingFlow> {
  final PageController _controller = PageController();
  final TextEditingController _name = TextEditingController();
  int _page = 0;
  bool _busy = false;

  static const _pages = <_OnboardPage>[
    _OnboardPage(
      title: 'سلام به LangPan',
      subtitle: 'با پاندا، یادگیری زبان ساده‌تر، لذت‌بخش‌تر و واقعی‌تر می‌شود.',
      mood: PandaMood.happy,
      badge: 'Learn · Speak · Explore',
    ),
    _OnboardPage(
      title: 'یادگیری مرحله‌به‌مرحله',
      subtitle: 'از Pre-A1 تا C2؛ با گرامر، واژگان، شنیدن، صحبت و مکالمه واقعی.',
      mood: PandaMood.proud,
      badge: 'Adaptive Learning',
    ),
    _OnboardPage(
      title: 'قدم‌های کوچک، رویاهای بزرگ',
      subtitle: 'هر روز کمی پیش برو. پاندا کنارت است — بدون سرزنش، با تشویق.',
      mood: PandaMood.encouraging,
      badge: 'Small steps · Big dreams',
    ),
  ];

  @override
  void dispose() {
    _controller.dispose();
    _name.dispose();
    super.dispose();
  }

  Future<void> _finish() async {
    if (_busy) return;
    setState(() => _busy = true);
    final name = _name.text.trim();
    final profile = LearnerProfile(
      name: name.isEmpty ? 'دوست من' : name,
      onboardingComplete: true,
    );
    await widget.onFinished(profile);
    if (mounted) setState(() => _busy = false);
  }

  void _next() {
    if (_page < _pages.length) {
      _controller.nextPage(duration: const Duration(milliseconds: 320), curve: Curves.easeOutCubic);
    } else {
      _finish();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isNamePage = _page >= _pages.length;
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
              child: Row(
                children: [
                  const BrandLogo(compact: true),
                  const Spacer(),
                  if (!isNamePage)
                    TextButton(
                      onPressed: _finish,
                      child: const Text('رد شدن'),
                    ),
                ],
              ),
            ),
            Expanded(
              child: PageView(
                controller: _controller,
                onPageChanged: (i) => setState(() => _page = i),
                children: [
                  for (final page in _pages) _OnboardContent(page: page),
                  _NamePage(controller: _name),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      for (var i = 0; i < _pages.length + 1; i++)
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          margin: const EdgeInsets.symmetric(horizontal: 3),
                          width: _page == i ? 22 : 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: _page == i ? AppColors.primary : AppColors.border,
                            borderRadius: BorderRadius.circular(99),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: FilledButton(
                      onPressed: _busy ? null : (isNamePage ? _finish : _next),
                      child: Text(
                        isNamePage ? 'شروع کنیم' : (_page == _pages.length - 1 ? 'ادامه' : 'بعدی'),
                        style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OnboardPage {
  const _OnboardPage({
    required this.title,
    required this.subtitle,
    required this.mood,
    required this.badge,
  });
  final String title;
  final String subtitle;
  final String mood;
  final String badge;
}

class _OnboardContent extends StatelessWidget {
  const _OnboardContent({required this.page});
  final _OnboardPage page;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 12, 24, 8),
      child: Column(
        children: [
          const Spacer(flex: 1),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFEFF6FF), Color(0xFFF5F3FF)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(AppRadii.xl),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              children: [
                PandaCompanion(mood: page.mood, showBackpack: true),
                const SizedBox(height: 8),
                Pill(page.badge, color: AppColors.softBlue, foreground: AppColors.primary, icon: Icons.auto_awesome_rounded),
              ],
            ),
          ),
          const SizedBox(height: 28),
          Text(
            page.title,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: AppColors.ink, height: 1.25, letterSpacing: -0.4),
          ),
          const SizedBox(height: 12),
          Text(
            page.subtitle,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 15, color: AppColors.muted, height: 1.6, fontWeight: FontWeight.w500),
          ),
          const Spacer(flex: 2),
        ],
      ),
    );
  }
}

class _NamePage extends StatelessWidget {
  const _NamePage({required this.controller});
  final TextEditingController controller;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(24, 12, 24, 8),
      child: Column(
        children: [
          const Spacer(),
          const PandaCompanion(mood: PandaMood.curious, showBackpack: false),
          const SizedBox(height: 20),
          const Text(
            'چه صدایت کنیم؟',
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: AppColors.ink),
          ),
          const SizedBox(height: 8),
          const Text(
            'نامت را بنویس تا پاندا و درس‌ها شخصی‌تر شوند.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.muted, height: 1.5),
          ),
          const SizedBox(height: 22),
          TextField(
            controller: controller,
            textDirection: TextDirection.ltr,
            textAlign: TextAlign.center,
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 18),
            decoration: const InputDecoration(
              hintText: 'مثلاً Sara یا علی',
            ),
          ),
          const Spacer(flex: 2),
        ],
      ),
    );
  }
}

/// Lightweight splash while profile loads.
class SplashGate extends StatefulWidget {
  const SplashGate({
    required this.child,
    required this.onboarding,
    required this.loadProfile,
    super.key,
  });

  final Widget child;
  final Widget Function(LearnerProfile seed, Future<void> Function(LearnerProfile) onDone) onboarding;
  final Future<LearnerProfile> Function() loadProfile;

  @override
  State<SplashGate> createState() => _SplashGateState();
}

class _SplashGateState extends State<SplashGate> {
  LearnerProfile? _profile;
  bool _showOnboarding = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    try {
      await Future<void>.delayed(const Duration(milliseconds: 700));
      final profile = await widget.loadProfile();
      if (!mounted) return;
      setState(() {
        _profile = profile;
        _showOnboarding = !profile.onboardingComplete;
      });
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return Scaffold(
        body: Center(child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text('خطا در راه‌اندازی: $_error', textAlign: TextAlign.center),
        )),
      );
    }
    if (_profile == null) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              BrandLogo(compact: true),
              SizedBox(height: 28),
              PandaCompanion(mood: PandaMood.happy, compact: true),
              SizedBox(height: 20),
              SizedBox(width: 28, height: 28, child: CircularProgressIndicator(strokeWidth: 3)),
              SizedBox(height: 12),
              Text('LangPan', style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.muted)),
            ],
          ),
        ),
      );
    }
    if (_showOnboarding) {
      return widget.onboarding(_profile!, (p) async {
        setState(() {
          _profile = p;
          _showOnboarding = false;
        });
      });
    }
    return widget.child;
  }
}
