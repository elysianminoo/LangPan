import 'dart:math' as math;

import 'package:flutter/material.dart';

abstract final class PandaMood {
  static const happy = 'happy';
  static const thinking = 'thinking';
  static const listening = 'listening';
  static const speaking = 'speaking';
  static const proud = 'proud';
  static const excited = 'excited';
  static const encouraging = 'encouraging';
  static const confused = 'confused';
  static const calm = 'calm';
}

class PandaCompanion extends StatefulWidget {
  const PandaCompanion({
    this.mood = PandaMood.happy,
    this.compact = false,
    this.showBackpack = false,
    this.onTap,
    super.key,
  });

  final String mood;
  final bool compact;
  final bool showBackpack;
  final VoidCallback? onTap;

  @override
  State<PandaCompanion> createState() => _PandaCompanionState();
}

class _PandaCompanionState extends State<PandaCompanion>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 3600),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = widget.compact ? 112.0 : 190.0;
    return Semantics(
      label: 'LangPan Panda',
      button: widget.onTap != null,
      child: GestureDetector(
        onTap: widget.onTap,
        child: SizedBox(
          width: size,
          height: size + 30,
          child: AnimatedBuilder(
            animation: _controller,
            builder: (context, _) {
              final phase = _controller.value * math.pi * 2;
              final bob = math.sin(phase) * (widget.compact ? 1.2 : 2.8);
              return Transform.translate(
                offset: Offset(0, bob),
                child: CustomPaint(
                  painter: _PandaPainter(
                    mood: widget.mood,
                    phase: _controller.value,
                    showBackpack: widget.showBackpack,
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class _PandaPainter extends CustomPainter {
  const _PandaPainter({
    required this.mood,
    required this.phase,
    required this.showBackpack,
  });

  final String mood;
  final double phase;
  final bool showBackpack;

  @override
  void paint(Canvas canvas, Size size) {
    final scale = size.width / 190;
    canvas.save();
    canvas.scale(scale, scale);

    final shadow = Paint()..color = const Color(0x2215223A);
    canvas.drawOval(const Rect.fromLTWH(34, 176, 122, 15), shadow);

    final body = Paint()
      ..shader = const LinearGradient(
        colors: [Color(0xFFFFFFFF), Color(0xFFE8EEF7)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(const Rect.fromLTWH(34, 70, 122, 110));
    final face = Paint()
      ..shader = const LinearGradient(
        colors: [Color(0xFFFFFFFF), Color(0xFFF1F5FA)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(const Rect.fromLTWH(38, 18, 114, 116));
    final black = Paint()..color = const Color(0xFF172033);
    final blackSoft = Paint()..color = const Color(0xFF202A3C);
    final white = Paint()..color = Colors.white;
    final brown = Paint()..color = const Color(0xFF8A5A35);
    final blue = Paint()..color = const Color(0xFF4B7BFF);
    final blush = Paint()..color = const Color(0xFFFF9EB3).withValues(alpha: .24);

    if (showBackpack) {
      final pack = Paint()..color = const Color(0xFF416FEA);
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          const Rect.fromLTWH(22, 91, 31, 69),
          const Radius.circular(13),
        ),
        pack,
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          const Rect.fromLTWH(137, 91, 31, 69),
          const Radius.circular(13),
        ),
        pack,
      );
    }

    // Soft rounded body — no permanent clothing. Accessories are contextual.
    canvas.drawOval(const Rect.fromLTWH(43, 77, 104, 100), body);

    // Ears and head.
    canvas.drawCircle(const Offset(53, 48), 23, black);
    canvas.drawCircle(const Offset(137, 48), 23, black);
    canvas.drawOval(const Rect.fromLTWH(38, 18, 114, 112), face);

    // Eye patches.
    canvas.save();
    canvas.translate(67, 72);
    canvas.rotate(-.18);
    canvas.drawOval(const Rect.fromLTWH(-18, -28, 32, 52), blackSoft);
    canvas.restore();
    canvas.save();
    canvas.translate(113, 72);
    canvas.rotate(.18);
    canvas.drawOval(const Rect.fromLTWH(-14, -28, 32, 52), blackSoft);
    canvas.restore();

    final thinking = mood == PandaMood.thinking;
    final listening = mood == PandaMood.listening || mood == PandaMood.speaking;
    final lookX = thinking ? -3.0 : listening ? 2.0 : 0.0;
    final eyeY = thinking ? 64.0 : 67.0;

    for (final x in [65.0 + lookX, 115.0 + lookX]) {
      canvas.drawCircle(Offset(x, eyeY), 9.2, brown);
      canvas.drawCircle(Offset(x, eyeY), 5.1, black);
      canvas.drawCircle(Offset(x - 2.5, eyeY - 3), 2.2, white);
    }
    canvas.drawCircle(const Offset(57, 92), 8.5, blush);
    canvas.drawCircle(const Offset(123, 92), 8.5, blush);

    final brow = Paint()
      ..color = blackSoft.color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.8
      ..strokeCap = StrokeCap.round;
    if (mood == PandaMood.confused) {
      canvas.drawLine(const Offset(51, 46), const Offset(69, 42), brow);
      canvas.drawLine(const Offset(111, 42), const Offset(129, 47), brow);
    } else if (thinking) {
      canvas.drawLine(const Offset(51, 43), const Offset(69, 39), brow);
      canvas.drawLine(const Offset(111, 39), const Offset(129, 43), brow);
    } else {
      canvas.drawLine(const Offset(51, 44), const Offset(69, 47), brow);
      canvas.drawLine(const Offset(111, 47), const Offset(129, 44), brow);
    }

    // Muzzle.
    canvas.drawOval(const Rect.fromLTWH(73, 80, 44, 31), white);
    canvas.drawOval(const Rect.fromLTWH(85, 83, 20, 12), black);
    final mouth = Path()..moveTo(80, 96);
    if (mood == PandaMood.confused) {
      mouth.quadraticBezierTo(94, 90, 106, 98);
    } else if (thinking) {
      mouth.quadraticBezierTo(94, 101, 106, 96);
    } else {
      mouth.quadraticBezierTo(94, 110, 108, 96);
    }
    final mouthPaint = Paint()
      ..color = black.color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.8
      ..strokeCap = StrokeCap.round;
    canvas.drawPath(mouth, mouthPaint);

    // Paws react to state.
    final wave = math.sin(phase * math.pi * 2);
    final double pawY = (mood == PandaMood.excited || mood == PandaMood.encouraging)
        ? 122.0 + wave * 8.0
        : 132.0;
    for (final x in [35.0, 155.0]) {
      canvas.drawCircle(Offset(x, pawY), 14, white);
      canvas.drawCircle(
        Offset(x, pawY),
        14,
        Paint()
          ..color = const Color(0xFF172033)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5,
      );
    }

    // Small blue LangPan accent, not clothing.
    canvas.drawCircle(const Offset(142, 154), 8, blue);
    canvas.drawCircle(const Offset(142, 154), 3, white);

    if (mood == PandaMood.excited || mood == PandaMood.proud) {
      final star = Paint()..color = const Color(0xFF7C8CFF);
      for (final offset in [
        const Offset(28, 65),
        const Offset(160, 72),
        const Offset(28, 99),
      ]) {
        canvas.drawCircle(offset, 3.5, star);
      }
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _PandaPainter oldDelegate) =>
      oldDelegate.mood != mood ||
      oldDelegate.phase != phase ||
      oldDelegate.showBackpack != showBackpack;
}
