import 'dart:math' as math;

import 'package:flutter/material.dart';

abstract final class PandaMood {
  static const happy = 'happy';
  static const thinking = 'thinking';
  static const listening = 'listening';
  static const proud = 'proud';
  static const excited = 'excited';
  static const encouraging = 'encouraging';
  static const confused = 'confused';
  static const calm = 'calm';
  static const speaking = 'speaking';
}

/// Uses the user-approved LangPan panda artwork. Mood assets are cropped from
/// the approved character sheet; the app must not invent a different mascot.
class PandaCompanion extends StatefulWidget {
  const PandaCompanion({
    this.mood = PandaMood.happy,
    this.compact = false,
    this.showBackpack = true,
    this.onTap,
    super.key,
  });

  final String mood;
  final bool compact;
  final bool showBackpack;
  final VoidCallback? onTap;

  @override
  State<PandaCompanion> createState() => _PandaCompanionState();
}

class _PandaCompanionState extends State<PandaCompanion>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 3200),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  String get _asset {
    switch (widget.mood) {
      case PandaMood.thinking:
      case PandaMood.confused:
        return 'assets/brand/panda_thinking.png';
      case PandaMood.listening:
        return 'assets/brand/panda_listening.png';
      case PandaMood.proud:
        return 'assets/brand/panda_proud.png';
      case PandaMood.excited:
        return 'assets/brand/panda_excited.png';
      case PandaMood.encouraging:
        return 'assets/brand/panda_encouraging.png';
      case PandaMood.speaking:
        return 'assets/brand/panda_speaking.png';
      case PandaMood.calm:
        return 'assets/brand/panda_calm.png';
      default:
        return 'assets/brand/panda_happy.png';
    }
  }

  @override
  Widget build(BuildContext context) {
    final width = widget.compact ? 108.0 : 178.0;
    return Semantics(
      label: 'LangPan panda companion — ${widget.mood}',
      button: widget.onTap != null,
      child: GestureDetector(
        onTap: widget.onTap,
        child: SizedBox(
          width: width,
          height: width,
          child: AnimatedBuilder(
            animation: _controller,
            builder: (context, _) {
              final phase = _controller.value * math.pi * 2;
              final bob = math.sin(phase) * (widget.compact ? 1.2 : 2.2);
              return Transform.translate(
                offset: Offset(0, bob),
                child: Image.asset(
                  _asset,
                  fit: BoxFit.contain,
                  filterQuality: FilterQuality.high,
                  errorBuilder: (context, error, stackTrace) => Image.asset(
                    'assets/brand/panda_approved_hero.png',
                    fit: BoxFit.contain,
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
