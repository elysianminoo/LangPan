import 'dart:math' as math;

import 'package:flutter/material.dart';

abstract final class PandaMood {
  static const happy = 'happy';
  static const thinking = 'thinking';
  static const listening = 'listening';
  static const proud = 'proud';
  static const excited = 'excited';
  static const encouraging = 'encouraging';
  static const confused = 'confused';
  static const calm = 'calm';
  static const speaking = 'speaking';
}

class PandaCompanion extends StatefulWidget {
  const PandaCompanion({
    this.mood = PandaMood.happy,
    this.compact = false,
    this.showBackpack = true,
    this.onTap,
    super.key,
  });

  final String mood;
  final bool compact;
  final bool showBackpack;
  final VoidCallback? onTap;

  @override
  State<PandaCompanion> createState() => _PandaCompanionState();
}

class _PandaCompanionState extends State<PandaCompanion>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 3200),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = widget.compact ? 108.0 : 178.0;
    return Semantics(
      label: 'LangPan Panda companion',
      button: widget.onTap != null,
      child: GestureDetector(
        onTap: widget.onTap,
        child: SizedBox(
          width: size,
          height: size + 26,
          child: AnimatedBuilder(
            animation: _controller,
            builder: (context, _) {
              final phase = _controller.value * math.pi * 2;
              final bob = math.sin(phase) * (widget.compact ? 1.5 : 3.2);
              return Transform.translate(
                offset: Offset(0, bob),
                child: CustomPaint(
                  painter: _PandaPainter(
                    mood: widget.mood,
                    phase: _controller.value,
                    showBackpack: widget.showBackpack,
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class _PandaPainter extends CustomPainter {
  const _PandaPainter({
    required this.mood,
    required this.phase,
    required this.showBackpack,
  });

  final String mood;
  final double phase;
  final bool showBackpack;

  @override
  void paint(Canvas canvas, Size size) {
    final scale = size.width / 180;
    canvas.save();
    canvas.scale(scale, scale);

    final body = Paint()
      ..shader = const LinearGradient(
        colors: [Color(0xFFFFFFFF), Color(0xFFE9EEF6)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(const Rect.fromLTWH(0, 0, 180, 180));
    final white = Paint()..color = const Color(0xFFFDFEFF);
    final black = Paint()..color = const Color(0xFF151B29);
    final blackSoft = Paint()..color = const Color(0xFF222B3C);
    final blue = Paint()
      ..shader = const LinearGradient(
        colors: [Color(0xFF5C8BFF), Color(0xFF3158E8)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(const Rect.fromLTWH(30, 82, 120, 100));
    final blueDark = Paint()..color = const Color(0xFF2747B9);
    final eye = Paint()..color = const Color(0xFF7B5134);
    final blush = Paint()..color = const Color(0xFFFFA5B9).withValues(alpha: .30);
    final line = Paint()
      ..color = const Color(0xFF171D2A)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.8
      ..strokeCap = StrokeCap.round;

    // Grounding shadow gives the character a 2.5D presence.
    final shadow = Paint()..color = const Color(0x2216223A);
    canvas.drawOval(const Rect.fromLTWH(34, 166, 112, 14), shadow);

    // Backpack sits behind the body.
    if (showBackpack) {
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          const Rect.fromLTWH(23, 90, 34, 62),
          const Radius.circular(15),
        ),
        blueDark,
      );
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          const Rect.fromLTWH(123, 90, 34, 62),
          const Radius.circular(15),
        ),
        blueDark,
      );
      canvas.drawCircle(const Offset(39, 108), 4, Paint()..color = const Color(0xFFBFD2FF));
    }

    // Body and hoodie.
    canvas.drawOval(const Rect.fromLTWH(43, 76, 94, 92), body);
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        const Rect.fromLTWH(43, 91, 94, 80),
        const Radius.circular(39),
      ),
      blue,
    );
    canvas.drawOval(const Rect.fromLTWH(62, 92, 56, 68), white);

    // Ears + head.
    canvas.drawCircle(const Offset(48, 50), 22, black);
    canvas.drawCircle(const Offset(132, 50), 22, black);
    canvas.drawCircle(const Offset(90, 57), 51, body);

    // Face patches.
    canvas.save();
    canvas.rotate(-.14, 61, 65);
    canvas.drawOval(const Rect.fromLTWH(44, 43, 31, 42), blackSoft);
    canvas.restore();
    canvas.save();
    canvas.rotate(.14, 119, 65);
    canvas.drawOval(const Rect.fromLTWH(104, 43, 31, 42), blackSoft);
    canvas.restore();

    final isThinking = mood == PandaMood.thinking;
    final isListening = mood == PandaMood.listening || mood == PandaMood.speaking;
    final eyeY = isThinking ? 58.0 : 62.0;
    final look = isThinking ? -3.0 : isListening ? 1.5 : 0.0;

    // Warm brown eyes from the agreed premium panda direction.
    canvas.drawCircle(Offset(64 + look, eyeY), 8.5, eye);
    canvas.drawCircle(Offset(116 + look, eyeY), 8.5, eye);
    canvas.drawCircle(Offset(64 + look, eyeY), 4.8, black);
    canvas.drawCircle(Offset(116 + look, eyeY), 4.8, black);
    canvas.drawCircle(Offset(61.5 + look, eyeY - 2.4), 2.2, white);
    canvas.drawCircle(Offset(113.5 + look, eyeY - 2.4), 2.2, white);

    canvas.drawCircle(const Offset(57, 88), 8, blush);
    canvas.drawCircle(const Offset(123, 88), 8, blush);

    // Eyebrows communicate mood.
    final brow = Paint()
      ..color = blackSoft.color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    if (mood == PandaMood.confused) {
      canvas.drawLine(const Offset(52, 44), const Offset(70, 42), brow);
      canvas.drawLine(const Offset(109, 42), const Offset(127, 46), brow);
    } else if (isThinking) {
      canvas.drawLine(const Offset(51, 44), const Offset(69, 40), brow);
      canvas.drawLine(const Offset(111, 40), const Offset(129, 44), brow);
    } else {
      canvas.drawLine(const Offset(52, 43), const Offset(70, 46), brow);
      canvas.drawLine(const Offset(110, 46), const Offset(128, 43), brow);
    }

    // Muzzle + expressive mouth.
    canvas.drawOval(const Rect.fromLTWH(71, 76, 38, 29), white);
    canvas.drawOval(const Rect.fromLTWH(84, 80, 12, 8), black);
    final mouth = Path()..moveTo(78, 91);
    if (mood == PandaMood.confused) {
      mouth.quadraticBezierTo(90, 86, 102, 93);
    } else if (isThinking) {
      mouth.quadraticBezierTo(90, 97, 102, 91);
    } else if (mood == PandaMood.proud || mood == PandaMood.excited) {
      mouth.quadraticBezierTo(90, 108, 103, 91);
    } else {
      mouth.quadraticBezierTo(90, 104, 102, 91);
    }
    canvas.drawPath(mouth, line);

    // Hoodie hood and zipper.
    final hood = Paint()
      ..color = const Color(0xFF88AAFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 6;
    canvas.drawArc(const Rect.fromLTWH(45, 82, 90, 82), math.pi, math.pi, false, hood);
    canvas.drawLine(const Offset(90, 128), const Offset(90, 164), Paint()
      ..color = const Color(0xFFBBD0FF)
      ..strokeWidth = 3);

    // Dynamic paws.
    final wave = math.sin(phase * math.pi * 2);
    if (mood == PandaMood.excited || mood == PandaMood.encouraging || mood == PandaMood.proud) {
      final y = 107 + wave * 8;
      canvas.drawCircle(Offset(147, y), 14, white);
      canvas.drawCircle(Offset(147, y), 14, line);
      canvas.drawCircle(Offset(32, 122 - wave * 3), 13, white);
      canvas.drawCircle(Offset(32, 122 - wave * 3), 13, line);
    } else if (isListening) {
      canvas.drawCircle(const Offset(32, 121), 13, white);
      canvas.drawCircle(const Offset(32, 121), 13, line);
      canvas.drawCircle(const Offset(148, 121), 13, white);
      canvas.drawCircle(const Offset(148, 121), 13, line);
    } else {
      canvas.drawCircle(const Offset(38, 125), 12, white);
      canvas.drawCircle(const Offset(38, 125), 12, line);
      canvas.drawCircle(const Offset(142, 125), 12, white);
      canvas.drawCircle(const Offset(142, 125), 12, line);
    }

    // Tiny blue badge: LangPan identity cue.
    canvas.drawCircle(
      const Offset(132, 151),
      9,
      Paint()..color = const Color(0xFFBFD0FF),
    );
    canvas.drawCircle(
      const Offset(132, 151),
      4,
      Paint()..color = const Color(0xFF3158E8),
    );

    canvas.restore();
  }


  @override
  bool shouldRepaint(covariant _PandaPainter oldDelegate) {
    return oldDelegate.mood != mood ||
        oldDelegate.phase != phase ||
        oldDelegate.showBackpack != showBackpack;
  }
}
