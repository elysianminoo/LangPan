import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Moods locked to official Character Sheet.
abstract final class PandaMood {
  static const happy = 'happy';
  static const thinking = 'thinking';
  static const listening = 'listening';
  static const speaking = 'speaking';
  static const proud = 'proud';
  static const excited = 'excited';
  static const encouraging = 'encouraging';
  static const confused = 'confused';
  static const calm = 'calm';

  static const all = <String>[
    happy,
    thinking,
    listening,
    speaking,
    proud,
    excited,
    encouraging,
    confused,
    calm,
  ];
}

/// Official companion widget.
/// Prefers `assets/panda/{mood}.png` when present; otherwise paints brand mascot.
class PandaCompanion extends StatefulWidget {
  const PandaCompanion({
    this.mood = PandaMood.happy,
    this.compact = false,
    this.showBackpack = false,
    this.onTap,
    super.key,
  });

  final String mood;
  final bool compact;
  final bool showBackpack;
  final VoidCallback? onTap;

  @override
  State<PandaCompanion> createState() => _PandaCompanionState();
}

class _PandaCompanionState extends State<PandaCompanion>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 4200),
  )..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = widget.compact ? 112.0 : 200.0;
    final h = widget.compact ? 128.0 : 228.0;

    return Semantics(
      label: 'LangPan Panda ${widget.mood}',
      button: widget.onTap != null,
      child: GestureDetector(
        onTap: widget.onTap,
        child: SizedBox(
          width: w,
          height: h,
          child: AnimatedBuilder(
            animation: _c,
            builder: (_, __) {
              final bob = math.sin(_c.value * math.pi * 2) * (widget.compact ? 1.5 : 2.8);
              return Transform.translate(
                offset: Offset(0, bob),
                child: Image.asset(
                  'assets/panda/${widget.mood}.png',
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => CustomPaint(
                    size: Size(w, h),
                    painter: BrandPandaPainter(
                      mood: widget.mood,
                      phase: _c.value,
                      showBackpack: widget.showBackpack,
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

/// Full brand mascot painter — soft 3D-inspired panda + blue hoodie + mark.
class BrandPandaPainter extends CustomPainter {
  const BrandPandaPainter({
    required this.mood,
    required this.phase,
    required this.showBackpack,
  });

  final String mood;
  final double phase;
  final bool showBackpack;

  // Brand palette
  static const _primary = Color(0xFF3B82F6);
  static const _primaryLight = Color(0xFF60A5FA);
  static const _primaryDark = Color(0xFF1D4ED8);
  static const _primaryMid = Color(0xFF2563EB);
  static const _fur = Color(0xFFFFFDFB);
  static const _furShade = Color(0xFFF1F5F9);
  static const _black = Color(0xFF12151C);
  static const _blackSoft = Color(0xFF1E2430);
  static const _eye = Color(0xFF5B3A1F);
  static const _blush = Color(0xFFFFB4B8);

  @override
  void paint(Canvas canvas, Size size) {
    final scale = size.width / 200;
    canvas.save();
    canvas.scale(scale, scale);

    final cx = 100.0;
    final wave = math.sin(phase * math.pi * 2);

    // —— Ground shadow ——
    canvas.drawOval(
      Rect.fromCenter(center: const Offset(100, 218), width: 96, height: 14),
      Paint()..color = const Color(0x1A1E293B),
    );

    // —— Backpack (behind) ——
    if (showBackpack) {
      _backpack(canvas);
    }

    // —— Legs (under hoodie hem) ——
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(68, 178, 22, 28), const Radius.circular(10)),
      Paint()..color = _black,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(110, 178, 22, 28), const Radius.circular(10)),
      Paint()..color = _black,
    );
    // Feet
    canvas.drawOval(const Rect.fromLTWH(64, 198, 28, 14), Paint()..color = _black);
    canvas.drawOval(const Rect.fromLTWH(108, 198, 28, 14), Paint()..color = _black);

    // —— Hoodie body ——
    final bodyRect = Rect.fromLTWH(48, 108, 104, 86);
    final bodyR = RRect.fromRectAndRadius(bodyRect, const Radius.circular(38));
    canvas.drawRRect(
      bodyR,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [_primaryLight, _primary, _primaryDark],
        ).createShader(bodyRect),
    );
    // Side shade for volume
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(120, 118, 30, 70), const Radius.circular(20)),
      Paint()..color = _primaryDark.withValues(alpha: 0.28),
    );

    // Pocket
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(70, 150, 60, 32), const Radius.circular(16)),
      Paint()..color = _primaryDark.withValues(alpha: 0.45),
    );

    // Brand leaf mark (white)
    final leaf = Path()
      ..moveTo(cx, 122)
      ..cubicTo(cx + 16, 122, cx + 20, 138, cx, 152)
      ..cubicTo(cx - 20, 138, cx - 16, 122, cx, 122);
    canvas.drawPath(leaf, Paint()..color = Colors.white.withValues(alpha: 0.96));
    // Inner leaf highlight
    final leafIn = Path()
      ..moveTo(cx, 128)
      ..cubicTo(cx + 9, 128, cx + 11, 138, cx, 146)
      ..cubicTo(cx - 11, 138, cx - 9, 128, cx, 128);
    canvas.drawPath(leafIn, Paint()..color = _primaryLight.withValues(alpha: 0.35));

    // —— Arms ——
    final lift = (mood == PandaMood.excited ||
            mood == PandaMood.encouraging ||
            mood == PandaMood.proud)
        ? 14.0 + wave * 8.0
        : 0.0;
    _arm(canvas, left: true, lift: lift);
    _arm(canvas, left: false, lift: 0);

    // —— Head ——
    // Soft shade circle under head
    canvas.drawCircle(const Offset(100, 74), 54, Paint()..color = const Color(0x14000000));
    // Head fill with slight gradient
    final headRect = const Rect.fromCircle(center: Offset(100, 70), radius: 52);
    canvas.drawCircle(
      const Offset(100, 70),
      52,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment(-0.25, -0.35),
          radius: 0.9,
          colors: [_fur, _furShade],
        ).createShader(headRect),
    );

    // Ears
    _ear(canvas, const Offset(54, 30));
    _ear(canvas, const Offset(146, 30));

    // Hood rim (soft blue arc behind upper head)
    canvas.drawArc(
      const Rect.fromLTWH(42, 18, 116, 80),
      math.pi * 1.08,
      math.pi * 0.84,
      false,
      Paint()
        ..color = _primaryLight
        ..style = PaintingStyle.stroke
        ..strokeWidth = 7
        ..strokeCap = StrokeCap.round,
    );

    // Eye patches
    canvas.drawOval(
      const Rect.fromCenter(center: Offset(74, 68), width: 34, height: 38),
      Paint()..color = _black,
    );
    canvas.drawOval(
      const Rect.fromCenter(center: Offset(126, 68), width: 34, height: 38),
      Paint()..color = _black,
    );

    // Eyes + glints (mood blink)
    final blink = (mood == PandaMood.happy || mood == PandaMood.proud)
        ? 0.55 + 0.12 * math.sin(phase * math.pi * 2)
        : (mood == PandaMood.calm ? 0.85 : 1.0);
    _eyeBall(canvas, const Offset(74, 70), blink);
    _eyeBall(canvas, const Offset(126, 70), blink);

    // Brows
    final brow = Paint()
      ..color = _blackSoft
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.4
      ..strokeCap = StrokeCap.round;
    if (mood == PandaMood.confused) {
      canvas.drawLine(const Offset(58, 48), const Offset(82, 44), brow);
      canvas.drawLine(const Offset(118, 44), const Offset(142, 50), brow);
    } else if (mood == PandaMood.thinking) {
      canvas.drawLine(const Offset(58, 46), const Offset(82, 42), brow);
      canvas.drawLine(const Offset(118, 42), const Offset(142, 48), brow);
    } else {
      canvas.drawLine(const Offset(58, 50), const Offset(82, 52), brow);
      canvas.drawLine(const Offset(118, 52), const Offset(142, 50), brow);
    }

    // Blush
    final bl = Paint()..color = _blush.withValues(alpha: 0.42);
    canvas.drawOval(const Rect.fromCenter(center: Offset(52, 88), width: 16, height: 10), bl);
    canvas.drawOval(const Rect.fromCenter(center: Offset(148, 88), width: 16, height: 10), bl);

    // Muzzle
    canvas.drawOval(const Rect.fromLTWH(80, 82, 40, 30), Paint()..color = _fur);
    canvas.drawOval(const Rect.fromLTWH(92, 86, 16, 12), Paint()..color = _black);

    // Mouth by mood
    final mouth = Path();
    if (mood == PandaMood.confused) {
      mouth.moveTo(88, 102);
      mouth.quadraticBezierTo(100, 96, 112, 103);
    } else if (mood == PandaMood.thinking) {
      mouth.moveTo(88, 102);
      mouth.quadraticBezierTo(100, 106, 112, 100);
    } else if (mood == PandaMood.excited || mood == PandaMood.encouraging) {
      mouth.moveTo(86, 100);
      mouth.quadraticBezierTo(100, 118, 114, 100);
      // open-ish smile fill
      final open = Path()
        ..moveTo(90, 102)
        ..quadraticBezierTo(100, 114, 110, 102)
        ..close();
      canvas.drawPath(open, Paint()..color = const Color(0xFF2A1A12).withValues(alpha: 0.35));
    } else {
      mouth.moveTo(88, 100);
      mouth.quadraticBezierTo(100, 112, 114, 100);
    }
    canvas.drawPath(
      mouth,
      Paint()
        ..color = _black
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.6
        ..strokeCap = StrokeCap.round,
    );

    // Thinking / confused glyphs
    if (mood == PandaMood.thinking || mood == PandaMood.confused) {
      final tp = TextPainter(
        text: TextSpan(
          text: mood == PandaMood.confused ? '?' : '…',
          style: const TextStyle(
            color: _primaryDark,
            fontSize: 22,
            fontWeight: FontWeight.w900,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, const Offset(152, 28));
    }

    // Sparkles for positive moods
    if (mood == PandaMood.excited ||
        mood == PandaMood.proud ||
        mood == PandaMood.encouraging ||
        mood == PandaMood.happy) {
      final spark = Paint()..color = const Color(0xFF93C5FD);
      for (final o in [
        Offset(22, 58 + wave * 2),
        Offset(178, 64 - wave * 2),
        Offset(28, 100),
      ]) {
        canvas.drawCircle(o, 3.2, spark);
      }
    }

    // Headphones for listening / speaking
    if (mood == PandaMood.listening || mood == PandaMood.speaking) {
      _headphones(canvas);
    }

    canvas.restore();
  }

  void _ear(Canvas canvas, Offset c) {
    canvas.drawCircle(c, 18, Paint()..color = _black);
    canvas.drawCircle(c, 9, Paint()..color = _fur);
  }

  void _eyeBall(Canvas canvas, Offset c, double blink) {
    canvas.drawOval(
      Rect.fromCenter(center: c, width: 12, height: 14 * blink),
      Paint()..color = _eye,
    );
    if (blink > 0.4) {
      canvas.drawCircle(c.translate(-2.5, -3), 3.0, Paint()..color = Colors.white);
      canvas.drawCircle(c.translate(2.0, 2.5), 1.4, Paint()..color = Colors.white70);
    }
  }

  void _arm(Canvas canvas, {required bool left, required double lift}) {
    final x = left ? 40.0 : 160.0;
    final y = 140.0 - lift;
    // Sleeve
    canvas.drawCircle(Offset(x, y - 8), 16, Paint()..color = _primaryMid);
    // Paw
    canvas.drawCircle(Offset(x, y + 6), 15, Paint()..color = _fur);
    canvas.drawCircle(
      Offset(x, y + 6),
      15,
      Paint()
        ..color = _black
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2.2,
    );
  }

  void _backpack(Canvas canvas) {
    final pack = RRect.fromRectAndRadius(
      const Rect.fromLTWH(128, 112, 44, 58),
      const Radius.circular(16),
    );
    canvas.drawRRect(pack, Paint()..color = _primaryDark);
    canvas.drawRRect(
      RRect.fromRectAndRadius(const Rect.fromLTWH(134, 122, 32, 26), const Radius.circular(10)),
      Paint()..color = _primaryMid,
    );
    // Strap
    canvas.drawLine(
      const Offset(130, 118),
      const Offset(112, 104),
      Paint()
        ..color = _primaryDark
        ..strokeWidth = 6
        ..strokeCap = StrokeCap.round,
    );
  }

  void _headphones(Canvas canvas) {
    final band = Paint()
      ..color = _primaryDark
      ..style = PaintingStyle.stroke
      ..strokeWidth = 6
      ..strokeCap = StrokeCap.round;
    canvas.drawArc(const Rect.fromLTWH(48, 22, 104, 70), math.pi * 1.05, math.pi * 0.9, false, band);
    canvas.drawCircle(const Offset(52, 72), 14, Paint()..color = _blackSoft);
    canvas.drawCircle(const Offset(148, 72), 14, Paint()..color = _blackSoft);
    canvas.drawCircle(const Offset(52, 72), 8, Paint()..color = _primary);
    canvas.drawCircle(const Offset(148, 72), 8, Paint()..color = _primary);
  }

  @override
  bool shouldRepaint(covariant BrandPandaPainter oldDelegate) =>
      oldDelegate.mood != mood ||
      oldDelegate.phase != phase ||
      oldDelegate.showBackpack != showBackpack;
}
