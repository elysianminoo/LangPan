import 'package:shared_preferences/shared_preferences.dart';

class LearnerProfile {
  const LearnerProfile({
    this.name = 'دوست من',
    this.title = '',
    this.nativeLanguage = 'فارسی',
    this.targetLanguage = 'English',
    this.accent = 'American English',
    this.dailyGoal = 15,
    this.onboardingComplete = false,
  });

  final String name;
  final String title;
  final String nativeLanguage;
  final String targetLanguage;
  final String accent;
  final int dailyGoal;
  final bool onboardingComplete;

  String get displayTitle => title.isEmpty ? '' : '$title ';

  LearnerProfile copyWith({
    String? name,
    String? title,
    String? nativeLanguage,
    String? targetLanguage,
    String? accent,
    int? dailyGoal,
    bool? onboardingComplete,
  }) {
    return LearnerProfile(
      name: name ?? this.name,
      title: title ?? this.title,
      nativeLanguage: nativeLanguage ?? this.nativeLanguage,
      targetLanguage: targetLanguage ?? this.targetLanguage,
      accent: accent ?? this.accent,
      dailyGoal: dailyGoal ?? this.dailyGoal,
      onboardingComplete: onboardingComplete ?? this.onboardingComplete,
    );
  }
}

class ProfileStore {
  ProfileStore([SharedPreferencesAsync? preferences])
      : _injected = preferences;

  final SharedPreferencesAsync? _injected;
  SharedPreferencesAsync? _created;

  // Created lazily so that merely constructing the store never touches the
  // platform plugin (unit and widget tests have no plugin registered).
  SharedPreferencesAsync get _preferences =>
      _injected ?? (_created ??= SharedPreferencesAsync());

  static const _name = 'profile.name';
  static const _title = 'profile.title';
  static const _nativeLanguage = 'profile.nativeLanguage';
  static const _targetLanguage = 'profile.targetLanguage';
  static const _accent = 'profile.accent';
  static const _dailyGoal = 'profile.dailyGoal';
  static const _onboarding = 'profile.onboardingComplete';

  Future<LearnerProfile> load() async {
    try {
      return LearnerProfile(
        name: await _preferences.getString(_name) ?? 'دوست من',
        title: await _preferences.getString(_title) ?? '',
        nativeLanguage: await _preferences.getString(_nativeLanguage) ?? 'فارسی',
        targetLanguage:
            await _preferences.getString(_targetLanguage) ?? 'English',
        accent: await _preferences.getString(_accent) ?? 'American English',
        dailyGoal: await _preferences.getInt(_dailyGoal) ?? 15,
        onboardingComplete: await _preferences.getBool(_onboarding) ?? false,
      );
    } catch (_) {
      // Tests and first-run environments may lack the preferences plugin.
      return const LearnerProfile();
    }
  }

  Future<void> save(LearnerProfile profile) async {
    try {
      final name = profile.name.trim();
      await _preferences.setString(_name, name.isEmpty ? 'دوست من' : name);
      await _preferences.setString(_title, profile.title);
      await _preferences.setString(_nativeLanguage, profile.nativeLanguage);
      await _preferences.setString(_targetLanguage, profile.targetLanguage);
      await _preferences.setString(_accent, profile.accent);
      await _preferences.setInt(_dailyGoal, profile.dailyGoal);
      await _preferences.setBool(_onboarding, profile.onboardingComplete);
    } catch (_) {
      // Ignore persistence failures in test / plugin-less environments.
    }
  }
}
