import 'package:flutter/material.dart';

import 'content_repository.dart';
import 'lesson_player.dart';
import 'panda.dart';
import 'profile_store.dart';
import 'theme.dart';
import 'widgets.dart';

class LangPanShell extends StatefulWidget {
  const LangPanShell({super.key});

  @override
  State<LangPanShell> createState() => _LangPanShellState();
}

class _LangPanShellState extends State<LangPanShell> {
  final ContentRepository _repository = const ContentRepository();
  final ProfileStore _profileStore = ProfileStore();
  LearnerProfile _profile = const LearnerProfile();
  int _index = 0;
  Map<String, dynamic>? _curriculum;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadCurriculum();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    try {
      final profile = await _profileStore.load();
      if (!mounted) return;
      setState(() => _profile = profile);
    } catch (_) {
      // Flutter widget tests do not register platform plugins. The in-memory
      // default profile keeps the learning UI testable without hiding runtime errors.
    }
  }

  Future<bool> _saveProfile(LearnerProfile profile) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      await _profileStore.save(profile);
    } catch (_) {
      messenger.showSnackBar(
        const SnackBar(content: Text('ذخیره‌سازی پروفایل انجام نشد.')),
      );
      return false;
    }
    if (!mounted) return true;
    setState(() => _profile = profile);
    return true;
  }

  Future<void> _loadCurriculum() async {
    setState(() => _error = null);
    try {
      final value = await _repository.loadCurriculum();
      if (!mounted) {
        return;
      }
      setState(() => _curriculum = value);
    } catch (e) {
      if (!mounted) {
        return;
      }
      setState(() => _error = '$e');
    }
  }

  void _openLearn() => setState(() => _index = 1);

  void _openLesson(Map<String, dynamic> lesson) {
    final personalized = asMap(personalizeContent(lesson, _profile.name));
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => LessonPlayer(lesson: personalized),
      ),
    );
  }

  /// Opens the first lesson of a chapter, loading only what is needed.
  Future<void> _openChapter(Map<String, dynamic> chapter) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      final lessons = await _repository.loadLessons(
        chapterId: asText(chapter['id']),
        lessonCount: 1,
      );
      if (!mounted || lessons.isEmpty) {
        return;
      }
      _openLesson(lessons.first);
    } catch (e) {
      messenger.showSnackBar(
        SnackBar(content: Text('بارگذاری درس ممکن نشد: $e')),
      );
    }
  }

  Future<void> _openFirstAuthoredLesson() async {
    final levels = asList(_curriculum?['levels']);
    for (final level in levels) {
      for (final chapter in asList(asMap(level)['chapters'])) {
        if (asMap(chapter)['status'] == 'authored') {
          await _openChapter(asMap(chapter));
          return;
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      HomePage(
        profile: _profile,
        onLearn: _openLearn,
        onLesson: _curriculum == null ? null : _openFirstAuthoredLesson,
      ),
      LearnPage(
        curriculum: _curriculum,
        error: _error,
        onRetry: _loadCurriculum,
        onChapter: _openChapter,
      ),
      const ReviewPage(),
      const ProgressPage(),
      ProfilePage(profile: _profile, onSave: _saveProfile),
    ];

    return Scaffold(
      body: SafeArea(child: pages[_index]),
      bottomNavigationBar: NavigationBar(
        height: 74,
        backgroundColor: Colors.white,
        indicatorColor: AppColors.softBlue,
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: 'خانه',
          ),
          NavigationDestination(
            icon: Icon(Icons.menu_book_outlined),
            selectedIcon: Icon(Icons.menu_book_rounded),
            label: 'یادگیری',
          ),
          NavigationDestination(
            icon: Icon(Icons.refresh_rounded),
            selectedIcon: Icon(Icons.refresh_rounded),
            label: 'مرور',
          ),
          NavigationDestination(
            icon: Icon(Icons.insights_outlined),
            selectedIcon: Icon(Icons.insights_rounded),
            label: 'پیشرفت',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline_rounded),
            selectedIcon: Icon(Icons.person_rounded),
            label: 'پروفایل',
          ),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({
    required this.profile,
    required this.onLearn,
    this.onLesson,
    super.key,
  });

  final LearnerProfile profile;
  final VoidCallback onLearn;
  final VoidCallback? onLesson;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
      children: [
        const BrandLogo(compact: true),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'سلام ${profile.displayTitle}${profile.name} 👋',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: AppColors.ink,
                    ),
                  ),
                  const SizedBox(height: 5),
                  const Text(
                    'امروز یک قدم کوچک، فردا یک مکالمه واقعی.',
                    style: TextStyle(color: AppColors.muted),
                  ),
                ],
              ),
            ),
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: AppColors.border),
              ),
              child: const Icon(Icons.notifications_none_rounded),
            ),
          ],
        ),
        const SizedBox(height: 20),
        GradientCard(
          onTap: onLesson,
          child: Stack(
            children: [
              const Positioned(
                right: 8,
                bottom: 0,
                child: PandaCompanion(mood: PandaMood.excited, compact: true),
              ),
              ConstrainedBox(
                constraints: const BoxConstraints(minHeight: 205),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(22, 22, 122, 18),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Pill(
                        'مسیر امروز',
                        icon: Icons.auto_awesome_rounded,
                        color: Color(0x33FFFFFF),
                        foreground: Colors.white,
                      ),
                      const SizedBox(height: 15),
                      const Text(
                        'Hello!',
                        style: TextStyle(
                          fontSize: 31,
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 7),
                      const Text(
                        'سلام کردن، معرفی خودت و یک مکالمه کوتاه با پاندا.',
                        style: TextStyle(color: Colors.white, height: 1.45),
                      ),
                      const SizedBox(height: 16),
                      FilledButton.tonal(
                        onPressed: onLesson ?? onLearn,
                        child: const Text('شروع درس'),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        const SectionTitle(
          title: 'وضعیت امروز',
          subtitle: 'کم اما پیوسته؛ همین چیزی است که زبان را می‌سازد.',
        ),
        const SizedBox(height: 12),
        const Row(
          children: [
            Expanded(
              child: _MetricCard(
                icon: Icons.local_fire_department_rounded,
                value: '4',
                label: 'روز پیوسته',
                color: AppColors.softPurple,
              ),
            ),
            SizedBox(width: 10),
            Expanded(
              child: _MetricCard(
                icon: Icons.bolt_rounded,
                value: '120',
                label: 'XP امروز',
                color: AppColors.softBlue,
              ),
            ),
            SizedBox(width: 10),
            Expanded(
              child: _MetricCard(
                icon: Icons.replay_rounded,
                value: '8',
                label: 'مرور امروز',
                color: AppColors.softMint,
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        const SectionTitle(
          title: 'یادگیری هوشمند',
          subtitle: 'LangPan بر اساس عملکردت قدم بعدی را پیشنهاد می‌کند.',
        ),
        const SizedBox(height: 12),
        FeatureTile(
          icon: Icons.psychology_alt_rounded,
          title: 'مرور هدفمند',
          subtitle: 'عبارت‌هایی که احتمال فراموشی‌شان بیشتر است',
          onTap: () => showDialog<void>(
            context: context,
            builder: (context) => const AlertDialog(
              title: Text('مرور هدفمند'),
              content: Text('هسته مرور LangPan در این نسخه بر پایه زمان مرور و ضعف‌های ثبت‌شده طراحی شده است. اتصال کامل صف مرور به Learner Model در مرحله بعدی همین موتور انجام می‌شود.'),
            ),
          ),
        ),
        const SizedBox(height: 10),
        FeatureTile(
          icon: Icons.record_voice_over_rounded,
          title: 'تمرین صحبت کردن',
          subtitle: 'با پاندا جواب بده؛ فقط حفظ کردن کافی نیست',
          color: AppColors.softMint,
          onTap: onLearn,
        ),
      ],
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.icon,
    required this.value,
    required this.label,
    required this.color,
  });

  final IconData icon;
  final String value;
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, size: 20, color: AppColors.ink),
          ),
          const SizedBox(height: 10),
          Text(
            value,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
          ),
          Text(
            label,
            style: const TextStyle(fontSize: 11, color: AppColors.muted),
          ),
        ],
      ),
    );
  }
}

class LearnPage extends StatelessWidget {
  const LearnPage({
    required this.curriculum,
    required this.error,
    required this.onRetry,
    required this.onChapter,
    super.key,
  });

  final Map<String, dynamic>? curriculum;
  final String? error;
  final VoidCallback onRetry;
  final void Function(Map<String, dynamic> chapter) onChapter;

  @override
  Widget build(BuildContext context) {
    final errorText = error;
    if (errorText != null) {
      return ErrorView(message: errorText, onRetry: onRetry);
    }
    final data = curriculum;
    if (data == null) {
      return const Center(child: CircularProgressIndicator());
    }
    final levels = asList(data['levels']);
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
      children: [
        const Text(
          'مسیر یادگیری',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.w900,
            color: AppColors.ink,
          ),
        ),
        const SizedBox(height: 6),
        const Text(
          'از Pre-A1 تا C2؛ هر سطح با هدف و مهارت مشخص.',
          style: TextStyle(color: AppColors.muted),
        ),
        const SizedBox(height: 18),
        for (final rawLevel in levels)
          _LevelCard(level: asMap(rawLevel), onChapter: onChapter),
      ],
    );
  }
}

class _LevelCard extends StatefulWidget {
  const _LevelCard({required this.level, required this.onChapter});

  final Map<String, dynamic> level;
  final void Function(Map<String, dynamic> chapter) onChapter;

  @override
  State<_LevelCard> createState() => _LevelCardState();
}

class _LevelCardState extends State<_LevelCard> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final level = widget.level;
    final cefr = asText(level['cefr']).toUpperCase().replaceAll('_', '-');
    final chapters = asList(level['chapters']);
    final authored = chapters
        .where((c) => asText(asMap(c)['status']) == 'authored')
        .length;
    final visible = _expanded ? chapters : chapters.take(3).toList();

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: AppCard(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Pill(cefr, icon: Icons.flag_rounded),
                const Spacer(),
                Text(
                  '$authored/${chapters.length} فصل آماده',
                  style: const TextStyle(fontSize: 12, color: AppColors.muted),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(
                asText(level['title']),
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            const SizedBox(height: 10),
            for (final rawChapter in visible)
              _ChapterRow(
                chapter: asMap(rawChapter),
                onChapter: widget.onChapter,
              ),
            if (chapters.length > 3)
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: TextButton(
                  onPressed: () => setState(() => _expanded = !_expanded),
                  child: Text(
                    _expanded
                        ? 'نمایش کمتر'
                        : '+ ${chapters.length - 3} فصل دیگر',
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _ChapterRow extends StatelessWidget {
  const _ChapterRow({required this.chapter, required this.onChapter});

  final Map<String, dynamic> chapter;
  final void Function(Map<String, dynamic> chapter) onChapter;

  @override
  Widget build(BuildContext context) {
    final ready = asText(chapter['status']) == 'authored';
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Material(
        color: ready ? AppColors.softBlue : const Color(0xFFF8F9FC),
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          onTap: ready ? () => onChapter(chapter) : null,
          borderRadius: BorderRadius.circular(16),
          child: Padding(
            padding: const EdgeInsets.all(13),
            child: Row(
              children: [
                Icon(
                  ready
                      ? Icons.play_circle_fill_rounded
                      : Icons.lock_outline_rounded,
                  color: ready ? AppColors.blue : AppColors.muted,
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        asText(chapter['title']),
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        ready
                            ? 'شروع درس‌ها و تمرین‌ها'
                            : 'در حال آماده‌سازی محتوای کامل',
                        style: const TextStyle(
                          fontSize: 11,
                          color: AppColors.muted,
                        ),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_left_rounded, size: 19),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ReviewPage extends StatelessWidget {
  const ReviewPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          'مرور هوشمند',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 6),
        const Text(
          'یادگیری را با بازیابی فاصله‌دار ماندگار کن.',
          style: TextStyle(color: AppColors.muted),
        ),
        const SizedBox(height: 20),
        const PandaSpeechBubble(
          text:
              'امروز ۸ مورد برای مرور داری. اول سراغ چیزهایی برویم که نزدیک فراموش شدن‌اند.',
          mood: PandaMood.thinking,
        ),
        const SizedBox(height: 10),
        FeatureTile(
          icon: Icons.schedule_rounded,
          title: 'مرورهای سررسیدشده',
          subtitle: '۸ مورد آماده‌اند',
          onTap: () => showDialog<void>(
            context: context,
            builder: (context) => const AlertDialog(
              title: Text('مرورهای سررسیدشده'),
              content: Text('این کارت برای ورود به صف مرور فاصله‌دار است. محتوای مرور از شواهد یادگیری و زمان سررسید تغذیه خواهد شد.'),
            ),
          ),
        ),
        const SizedBox(height: 10),
        FeatureTile(
          icon: Icons.healing_rounded,
          title: 'بازیابی ضعف‌ها',
          subtitle: 'تمرین‌های کوتاه برای خطاهای تکراری',
          onTap: () => showDialog<void>(
            context: context,
            builder: (context) => const AlertDialog(
              title: Text('بازیابی ضعف‌ها'),
              content: Text('Recovery بر اساس خطای تکرارشونده ساخته می‌شود: توضیح کوچک، تمرین هدایت‌شده، تولید مستقل و بررسی دوباره.'),
            ),
          ),
        ),
      ],
    );
  }
}

class ProgressPage extends StatelessWidget {
  const ProgressPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          'پیشرفت من',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 16),
        const AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'A1 • Meet & Greet',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
              ),
              SizedBox(height: 12),
              LinearProgressIndicator(value: .28, minHeight: 9),
              SizedBox(height: 9),
              Text(
                '۲۸٪ از این فصل؛ تمرکز فعلی: معرفی خود و مکالمه اولیه',
                style: TextStyle(color: AppColors.muted),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        FeatureTile(
          icon: Icons.record_voice_over_rounded,
          title: 'Speaking',
          subtitle: 'در حال تقویت تولید جمله‌های کوتاه',
          color: AppColors.softPurple,
          onTap: () => showDialog<void>(
            context: context,
            builder: (context) => const AlertDialog(
              title: Text('Speaking'),
              content: Text('Speaking Lab اکنون در درس‌ها فعال است: میکروفن، تشخیص گفتار، تطبیق پاسخ و بازخورد اولیه.'),
            ),
          ),
        ),
        const SizedBox(height: 10),
        FeatureTile(
          icon: Icons.hearing_rounded,
          title: 'Listening',
          subtitle: 'تشخیص عبارت‌های آشنا خوب است؛ سرعت را آرام بالا می‌بریم',
          color: AppColors.softMint,
          onTap: () => showDialog<void>(
            context: context,
            builder: (context) => const AlertDialog(
              title: Text('Listening'),
              content: Text('Listening Lab اکنون پخش نمونه، نمایش متن بعد از شنیدن و مقایسه شنیداری را پشتیبانی می‌کند.'),
            ),
          ),
        ),
      ],
    );
  }
}

class ProfilePage extends StatefulWidget {
  const ProfilePage({required this.profile, required this.onSave, super.key});

  final LearnerProfile profile;
  final Future<bool> Function(LearnerProfile profile) onSave;

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  late final TextEditingController _nameController =
      TextEditingController(text: widget.profile.name == 'دوست من' ? '' : widget.profile.name);
  String _title = '';
  int _goal = 15;

  @override
  void initState() {
    super.initState();
    _title = widget.profile.title;
    _goal = widget.profile.dailyGoal;
  }

  @override
  void didUpdateWidget(covariant ProfilePage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.profile.name != widget.profile.name) {
      _nameController.text =
          widget.profile.name == 'دوست من' ? '' : widget.profile.name;
    }
    if (oldWidget.profile.title != widget.profile.title) {
      _title = widget.profile.title;
    }
    if (oldWidget.profile.dailyGoal != widget.profile.dailyGoal) {
      _goal = widget.profile.dailyGoal;
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final name = _nameController.text.trim();
    final saved = await widget.onSave(
      widget.profile.copyWith(
        name: name.isEmpty ? 'دوست من' : name,
        title: _title,
        dailyGoal: _goal,
      ),
    );
    if (!mounted || !saved) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('پروفایل و ترجیحات یادگیری ذخیره شد.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final displayName = _nameController.text.trim().isEmpty
        ? 'دوست من'
        : _nameController.text.trim();
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
      children: [
        const Text(
          'پروفایل و تجربه یادگیری',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 6),
        const Text(
          'LangPan باید با خودِ زبان‌آموز تطبیق پیدا کند؛ نه اینکه یک متن ثابت برای همه نمایش دهد.',
          style: TextStyle(color: AppColors.muted, height: 1.5),
        ),
        const SizedBox(height: 18),
        GradientCard(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                const PandaCompanion(mood: PandaMood.proud, compact: true),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'سلام $displayName 👋',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 5),
                      const Text(
                        'پاندا آماده است با ریتم خودت همراهت باشد.',
                        style: TextStyle(color: Colors.white70, height: 1.45),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('اطلاعات پایه', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 14),
              TextField(
                controller: _nameController,
                textDirection: TextDirection.rtl,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                  labelText: 'نامی که می‌خواهی پاندا صدایت کند',
                  prefixIcon: Icon(Icons.badge_outlined),
                ),
              ),
              const SizedBox(height: 14),
              Wrap(
                spacing: 8,
                children: [
                  ChoiceChip(
                    label: const Text('آقا'),
                    selected: _title == 'آقا',
                    onSelected: (_) => setState(() => _title = 'آقا'),
                  ),
                  ChoiceChip(
                    label: const Text('خانم'),
                    selected: _title == 'خانم',
                    onSelected: (_) => setState(() => _title = 'خانم'),
                  ),
                  ChoiceChip(
                    label: const Text('ترجیح می‌دهم نگویم'),
                    selected: _title.isEmpty,
                    onSelected: (_) => setState(() => _title = ''),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('هدف روزانه', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text('$_goal دقیقه در روز', style: const TextStyle(color: AppColors.muted)),
              Slider(
                value: _goal.toDouble(),
                min: 5,
                max: 60,
                divisions: 11,
                label: '$_goal دقیقه',
                onChanged: (value) => setState(() => _goal = value.round()),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        FeatureTile(
          icon: Icons.volume_up_rounded,
          title: 'صدا و تلفظ',
          subtitle: 'پخش نمونه‌ها و تمرین با میکروفن در درس‌ها فعال است',
          color: AppColors.softBlue,
          onTap: () => showDialog<void>(
            context: context,
            builder: (context) => const AlertDialog(
              title: Text('صدا و تلفظ'),
              content: Text('درس‌ها از صدای سیستم برای نمونه‌های شنیداری استفاده می‌کنند و Speaking Lab صدای تو را دریافت و تحلیل اولیه می‌کند.'),
            ),
          ),
        ),
        const SizedBox(height: 10),
        FeatureTile(
          icon: Icons.record_voice_over_rounded,
          title: 'لهجه هدف',
          subtitle: widget.profile.accent,
          color: AppColors.softMint,
          onTap: () => showDialog<void>(
            context: context,
            builder: (context) => const AlertDialog(
              title: Text('لهجه هدف'),
              content: Text('American English به‌عنوان انتخاب فعلی دوره تنظیم شده است. موتور صوتی در مراحل بعدی با مجموعه صدای حرفه‌ای و چندگوینده‌ای توسعه پیدا می‌کند.'),
            ),
          ),
        ),
        const SizedBox(height: 18),
        SizedBox(
          height: 54,
          child: FilledButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save_rounded),
            label: const Text('ذخیره و شخصی‌سازی LangPan'),
          ),
        ),
      ],
    );
  }
}
