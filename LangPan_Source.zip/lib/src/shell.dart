import 'package:flutter/material.dart';

import 'content_repository.dart';
import 'lesson_player.dart';
import 'panda.dart';
import 'profile_store.dart';
import 'theme.dart';
import 'widgets.dart';

class LangPanShell extends StatefulWidget {
  const LangPanShell({super.key});
  @override
  State<LangPanShell> createState() => _LangPanShellState();
}

class _LangPanShellState extends State<LangPanShell> {
  final ContentRepository _repository = const ContentRepository();
  final ProfileStore _profileStore = ProfileStore();
  LearnerProfile _profile = const LearnerProfile();
  Map<String, dynamic>? _curriculum;
  String? _error;
  int _index = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final results = await Future.wait([_repository.loadCurriculum(), _profileStore.load()]);
      if (!mounted) return;
      setState(() {
        _curriculum = results[0] as Map<String, dynamic>;
        _profile = results[1] as LearnerProfile;
      });
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  Future<void> _saveProfile(LearnerProfile profile) async {
    await _profileStore.save(profile);
    if (mounted) setState(() => _profile = profile);
  }

  void _openLesson(Map<String, dynamic> lesson) {
    final personalized = asMap(personalizeContent(lesson, _profile.name));
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => LessonPlayer(lesson: personalized)));
  }

  Future<void> _openChapter(Map<String, dynamic> chapter) async {
    try {
      final count = (asMap(chapter)['lesson_count'] as num?)?.toInt() ?? 12;
      final lessons = await _repository.loadLessons(chapterId: asText(chapter['id']), lessonCount: count);
      if (!mounted || lessons.isEmpty) return;
      _showLessonMap(chapter, lessons);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('بارگذاری مسیر درس ممکن نشد: $e')));
    }
  }

  void _showLessonMap(Map<String, dynamic> chapter, List<Map<String, dynamic>> lessons) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => DraggableScrollableSheet(
        initialChildSize: .82,
        minChildSize: .6,
        maxChildSize: .94,
        builder: (_, controller) => Container(
          decoration: const BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.vertical(top: Radius.circular(32))),
          child: ListView(controller: controller, padding: const EdgeInsets.fromLTRB(20, 12, 20, 30), children: [
            Center(child: Container(width: 46, height: 5, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(99)))),
            const SizedBox(height: 18),
            Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(asText(chapter['title'], 'Chapter'), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text('${lessons.length} مرحله یادگیری', style: const TextStyle(color: AppColors.muted))])),
              Pill(asText(chapter['id'], 'A1.C1').toUpperCase()),
            ]),
            const SizedBox(height: 18),
            for (var i = 0; i < lessons.length; i++)
              _LessonMapCard(index: i + 1, lesson: lessons[i], onTap: () { Navigator.of(sheetContext).pop(); _openLesson(lessons[i]); }),
          ]),
        ),
      ),
    );
  }

  void _openFirstLesson() {
    final levels = asList(_curriculum?['levels']);
    for (final level in levels) {
      for (final chapter in asList(asMap(level)['chapters'])) {
        final c = asMap(chapter);
        if (c['status'] == 'authored') { _openChapter(c); return; }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(profile: _profile, onStart: _openFirstLesson, onLearn: () => setState(() => _index = 1)),
      LearnPage(curriculum: _curriculum, error: _error, onRetry: _load, onChapter: _openChapter),
      ReviewPage(onOpen: () => setState(() => _index = 2)),
      ProgressPage(),
      ProfilePage(profile: _profile, onSave: _saveProfile),
    ];
    return Scaffold(
      body: SafeArea(child: pages[_index]),
      bottomNavigationBar: _BottomNav(index: _index, onChanged: (value) => setState(() => _index = value)),
    );
  }
}

class _BottomNav extends StatelessWidget {
  const _BottomNav({required this.index, required this.onChanged});
  final int index;
  final ValueChanged<int> onChanged;
  static const labels = ['خانه', 'یادگیری', 'مرور', 'پیشرفت', 'پروفایل'];
  static const icons = [Icons.home_rounded, Icons.auto_stories_rounded, Icons.replay_rounded, Icons.insights_rounded, Icons.person_rounded];
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.fromLTRB(14, 0, 14, 12),
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(AppRadii.xl),
          border: Border.all(color: AppColors.border),
          boxShadow: AppShadows.soft,
        ),
        child: Row(children: [
          for (var i = 0; i < labels.length; i++)
            Expanded(
              child: GestureDetector(
                onTap: () => onChanged(i),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  curve: Curves.easeOutCubic,
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  decoration: BoxDecoration(
                    color: index == i ? AppColors.softBlue : Colors.transparent,
                    borderRadius: BorderRadius.circular(AppRadii.md),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(icons[i], size: 22, color: index == i ? AppColors.primary : AppColors.muted),
                      const SizedBox(height: 3),
                      Text(
                        labels[i],
                        style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -0.1,
                          color: index == i ? AppColors.primary : AppColors.muted,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ]),
      );
}

class HomePage extends StatelessWidget {
  const HomePage({required this.profile, required this.onStart, required this.onLearn, super.key});
  final LearnerProfile profile;
  final VoidCallback onStart;
  final VoidCallback onLearn;

  @override
  Widget build(BuildContext context) {
    final name = profile.name.trim().isEmpty || profile.name == 'دوست من' ? 'دوست من' : profile.name.trim();
    final title = profile.title.isEmpty ? '' : '${profile.title} ';
    return ListView(padding: const EdgeInsets.fromLTRB(18, 12, 18, 22), children: [
      Row(children: [Expanded(child: BrandLogo(compact: true)), IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded))]),
      const SizedBox(height: 4),
      Text('سلام $title$name 👋', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: AppColors.ink)),
      const SizedBox(height: 4),
      const Text('امروز قرار نیست فقط درس بخوانی؛ قرار است یک کار واقعی را به انگلیسی انجام بدهی.', style: TextStyle(color: AppColors.muted, height: 1.5)),
      const SizedBox(height: 18),
      _HeroLearningCard(name: name, onStart: onStart),
      const SizedBox(height: 18),
      Row(children: [
        _MiniStat(icon: Icons.local_fire_department_rounded, label: 'پیوستگی', value: '5 روز', color: AppColors.warning),
        const SizedBox(width: 10),
        _MiniStat(icon: Icons.bolt_rounded, label: 'XP امروز', value: '120', color: AppColors.indigo),
        const SizedBox(width: 10),
        _MiniStat(icon: Icons.schedule_rounded, label: 'هدف روزانه', value: '${profile.dailyGoal} دقیقه', color: AppColors.mint),
      ]),
      const SizedBox(height: 22),
      const SectionTitle(title: 'مسیرهای اصلی', subtitle: 'همه چیز از همین چهار در شروع می‌شود'),
      const SizedBox(height: 12),
      GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .95, children: [
        GraphicMenuCard(title: 'یادگیری', subtitle: 'درس امروز و مسیر سطح', icon: Icons.auto_stories_rounded, onTap: onLearn, colors: const [AppColors.primary, AppColors.secondary], badge: 'شروع'),
        GraphicMenuCard(title: 'مرور هوشمند', subtitle: 'چیزهایی که نزدیک فراموشی‌اند', icon: Icons.replay_rounded, onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const ReviewPage())), colors: const [AppColors.info, AppColors.success], badge: '۶ مورد'),
        GraphicMenuCard(title: 'پیشرفت من', subtitle: 'مهارت‌ها، شواهد و رشد', icon: Icons.insights_rounded, onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => ProgressPage())), colors: const [AppColors.secondary, Color(0xFFEC4899)]),
        GraphicMenuCard(title: 'کتابخانه', subtitle: 'داستان، پادکست و مکالمه', icon: Icons.local_library_rounded, onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const LibraryPage())), colors: const [AppColors.warning, AppColors.error]),
      ]),
      const SizedBox(height: 22),
      const SectionTitle(title: 'پاندا امروز', subtitle: 'همراه یادگیری، نه یک تصویر تزئینی'),
      const SizedBox(height: 10),
      AppCard(padding: const EdgeInsets.fromLTRB(16, 14, 10, 10), child: Row(children: [PandaCompanion(compact: true, mood: PandaMood.encouraging), const SizedBox(width: 8), const Expanded(child: Text('یک مکالمه کوتاه بعد از درس داریم. من به پاسخت گوش می‌دهم، نه اینکه فقط متن آماده نشان بدهم.', style: TextStyle(fontWeight: FontWeight.w700, height: 1.55)))])),
    ]);
  }
}

class _HeroLearningCard extends StatelessWidget {
  const _HeroLearningCard({required this.name, required this.onStart});
  final String name;
  final VoidCallback onStart;
  @override
  Widget build(BuildContext context) => GradientCard(onTap: onStart, padding: const EdgeInsets.all(20), child: SizedBox(height: 225, child: Stack(children: [
        Positioned(right: -6, bottom: -14, child: PandaCompanion(mood: PandaMood.excited, showBackpack: true)),
        Positioned(left: 0, top: 0, right: 116, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Pill('مسیر امروز', icon: Icons.auto_awesome_rounded, color: Color(0x33FFFFFF), foreground: Colors.white),
          const SizedBox(height: 15),
          const Text('A1 • Meet & Greet', style: TextStyle(color: Colors.white70, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          const Text('Hello!', style: TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w900)),
          const SizedBox(height: 7),
          Text('سلام $name — قدم‌های کوچک، رویاهای بزرگ.', style: const TextStyle(color: Colors.white, height: 1.45)),
          const SizedBox(height: 18),
          SizedBox(height: 48, child: FilledButton.icon(onPressed: onStart, style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: AppColors.blue), icon: const Icon(Icons.play_arrow_rounded), label: const Text('شروع درس', style: TextStyle(fontWeight: FontWeight.w900)))),
        ])),
      ])));
}

class _MiniStat extends StatelessWidget {
  const _MiniStat({required this.icon, required this.label, required this.value, required this.color});
  final IconData icon; final String label; final String value; final Color color;
  @override
  Widget build(BuildContext context) => Expanded(child: AppCard(padding: const EdgeInsets.all(12), child: Column(children: [Container(width: 38, height: 38, decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(13)), child: Icon(icon, color: color)), const SizedBox(height: 7), Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)), const SizedBox(height: 2), Text(label, style: const TextStyle(fontSize: 10, color: AppColors.muted))])));
}

class LibraryPage extends StatelessWidget {
  const LibraryPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: AppColors.background,
        appBar: AppBar(title: const Text('کتابخانه', style: TextStyle(fontWeight: FontWeight.w900))),
        body: ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 28), children: [
          const Text('یادگیری در دنیای واقعی', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          const Text('داستان، مکالمه، شنیدن و محتوای سطح‌بندی‌شده؛ محتوای تجاری یا فیلم فقط با مجوز مناسب وارد می‌شود.', style: TextStyle(color: AppColors.muted, height: 1.5)),
          const SizedBox(height: 18),
          for (final item in const [
            ('داستان‌ها', 'داستان‌های سطح‌بندی‌شده با واژه و مکالمه', Icons.auto_stories_rounded, AppColors.softPurple),
            ('پادکست‌ها', 'شنیدن کوتاه با سرعت و متن تعاملی', Icons.podcasts_rounded, AppColors.softBlue),
            ('مکالمه‌ها', 'گفت‌وگوهای روزمره و shadowing', Icons.forum_rounded, AppColors.softMint),
            ('ویدئو و فرهنگ', 'فرهنگ، تاریخ و موقعیت‌های واقعی', Icons.public_rounded, AppColors.softCyan),
          ])
            Padding(padding: const EdgeInsets.only(bottom: 12), child: AppCard( child: Row(children: [Container(width: 52, height: 52, decoration: BoxDecoration(color: item.$4, borderRadius: BorderRadius.circular(17)), child: Icon(item.$3, color: AppColors.blue)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(item.$1, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(item.$2, style: const TextStyle(color: AppColors.muted, fontSize: 12, height: 1.35))])), const Icon(Icons.chevron_left_rounded, color: AppColors.muted)]))),
        ]),
      );
}

class LearnPage extends StatelessWidget {
  const LearnPage({required this.curriculum, required this.error, required this.onRetry, required this.onChapter, super.key});
  final Map<String, dynamic>? curriculum; final String? error; final VoidCallback onRetry; final ValueChanged<Map<String, dynamic>> onChapter;
  @override
  Widget build(BuildContext context) {
    if (error != null) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.error_outline_rounded, size: 56, color: AppColors.error), const SizedBox(height: 12), Text(error!, textAlign: TextAlign.center), const SizedBox(height: 14), FilledButton(onPressed: onRetry, child: const Text('تلاش دوباره'))])));
    final levels = asList(curriculum?['levels']).map(asMap).toList();
    return ListView(padding: const EdgeInsets.fromLTRB(18, 14, 18, 28), children: [const BrandLogo(compact: true), const SizedBox(height: 12), const Text('مسیر یادگیری', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)), const SizedBox(height: 5), const Text('سطح مناسب را ببین؛ داخل هر سطح، درس‌ها بر اساس هدف واقعی چیده شده‌اند.', style: TextStyle(color: AppColors.muted, height: 1.5)), const SizedBox(height: 18), for (final level in levels) _LevelCard(level: level, onChapter: onChapter)]);
  }
}

class _LevelCard extends StatelessWidget {
  const _LevelCard({required this.level, required this.onChapter});
  final Map<String, dynamic> level; final ValueChanged<Map<String, dynamic>> onChapter;
  @override
  Widget build(BuildContext context) {
    final cefr = asText(level['cefr'], 'A1').toUpperCase();
    final chapters = asList(level['chapters']).map(asMap).toList();
    final active = chapters.where((c) => c['status'] == 'authored').toList();
    final color = switch (cefr) { 'PRE_A1' => AppColors.mint, 'A1' => AppColors.blue, 'A2' => AppColors.cyan, 'B1' => AppColors.indigo, 'B2' => const Color(0xFF7C3AED), 'C1' => const Color(0xFFDB2777), _ => AppColors.navy };
    return Container(margin: const EdgeInsets.only(bottom: 14), padding: const EdgeInsets.all(17), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28), border: Border.all(color: AppColors.border), boxShadow: const [BoxShadow(color: Color(0x11152033), blurRadius: 20, offset: Offset(0, 9))]), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [Container(width: 54, height: 54, decoration: BoxDecoration(gradient: LinearGradient(colors: [color, color.withValues(alpha: .68)]), borderRadius: BorderRadius.circular(18)), child: Center(child: Text(cefr.replaceAll('_', '-'), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 12)))), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(asText(level['title'], 'Level'), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text('${chapters.length} فصل • ${active.length} فصل آماده تست', style: const TextStyle(color: AppColors.muted, fontSize: 11))]))]),
      const SizedBox(height: 13),
      for (final chapter in chapters) _ChapterRow(chapter: chapter, color: color, onTap: chapter['status'] == 'authored' ? () => onChapter(chapter) : null),
    ]));
  }
}

class _ChapterRow extends StatelessWidget {
  const _ChapterRow({required this.chapter, required this.color, this.onTap});
  final Map<String, dynamic> chapter; final Color color; final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => InkWell(onTap: onTap, borderRadius: BorderRadius.circular(18), child: Container(margin: const EdgeInsets.only(top: 7), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: onTap == null ? AppColors.background : Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: onTap == null ? Colors.transparent : AppColors.border)), child: Row(children: [Container(width: 34, height: 34, decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(12)), child: Icon(onTap == null ? Icons.lock_outline_rounded : Icons.play_arrow_rounded, size: 18, color: color)), const SizedBox(width: 10), Expanded(child: Text(asText(chapter['title'], 'Chapter'), style: const TextStyle(fontWeight: FontWeight.w800))), Text(onTap == null ? 'ساختار' : 'شروع', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900, color: onTap == null ? AppColors.muted : color)), const SizedBox(width: 3), const Icon(Icons.chevron_left_rounded, color: AppColors.muted, size: 20)])));
}

class _LessonMapCard extends StatelessWidget {
  const _LessonMapCard({required this.index, required this.lesson, required this.onTap});
  final int index; final Map<String, dynamic> lesson; final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => AppCard(onTap: onTap, padding: const EdgeInsets.all(15), child: Row(children: [Container(width: 42, height: 42, decoration: BoxDecoration(gradient: const LinearGradient(colors: [AppColors.blue, AppColors.indigo]), borderRadius: BorderRadius.circular(14)), child: Center(child: Text('$index', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)))), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(asText(lesson['title']), style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(asText(lesson['communicative_goal']), maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5, color: AppColors.muted, height: 1.35))])), const Icon(Icons.arrow_forward_ios_rounded, size: 16, color: AppColors.muted)]));
}

class ReviewPage extends StatelessWidget {
  const ReviewPage({this.onOpen, super.key});
  final VoidCallback? onOpen;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(18, 16, 18, 28), children: [const BrandLogo(compact: true), const SizedBox(height: 14), const Text('مرور هوشمند', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)), const SizedBox(height: 5), const Text('مرور قرار نیست تکرار کورکورانه باشد؛ باید چیزی را که نزدیک فراموشی است دوباره بازیابی کنی.', style: TextStyle(color: AppColors.muted, height: 1.5)), const SizedBox(height: 18), GradientCard(padding: const EdgeInsets.all(20), child: Row(children: [const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('۶ مورد آماده مرور', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w900)), SizedBox(height: 6), Text('واژه + گرامر + شنیدن + تولید', style: TextStyle(color: Colors.white70))])), PandaCompanion(compact: true, mood: PandaMood.thinking)])), const SizedBox(height: 16), for (final item in const [('hello', 'معنی و کاربرد', Icons.translate_rounded), ('I\'m', 'ساختار معرفی خود', Icons.account_tree_rounded), ('Nice to meet you', 'عبارت تعاملی', Icons.forum_rounded), ('Where are you from?', 'مکالمه', Icons.chat_bubble_outline_rounded)]) AppCard(padding: const EdgeInsets.all(15), child: Row(children: [Container(width: 45, height: 45, decoration: BoxDecoration(color: AppColors.softBlue, borderRadius: BorderRadius.circular(15)), child: Icon(item.$3, color: AppColors.blue)), const SizedBox(width: 11), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(item.$1, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(item.$2, style: const TextStyle(fontSize: 11, color: AppColors.muted))])), const Icon(Icons.play_circle_fill_rounded, color: AppColors.blue)])), const SizedBox(height: 10), FilledButton.icon(onPressed: onOpen, icon: const Icon(Icons.play_arrow_rounded), label: const Text('شروع مرور'))]);
}

class ProgressPage extends StatelessWidget {
  ProgressPage({super.key});
  final skills = const [
    ('واژگان', .74, Icons.translate_rounded),
    ('گرامر', .58, Icons.account_tree_rounded),
    ('شنیدن', .46, Icons.headphones_rounded),
    ('گفتار', .39, Icons.mic_rounded),
    ('تلفظ', .42, Icons.record_voice_over_rounded),
  ];
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 28),
      children: [
        const BrandLogo(compact: true),
        const SizedBox(height: 14),
        const Text('پیشرفت من', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
        const SizedBox(height: 5),
        const Text('پیشرفت با شواهد یادگیری سنجیده می‌شود، نه فقط با تعداد درس‌های تمام‌شده.', style: TextStyle(color: AppColors.muted, height: 1.5)),
        const SizedBox(height: 18),
        AppCard(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              SizedBox(
                width: 92,
                height: 92,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      width: 88,
                      height: 88,
                      child: CircularProgressIndicator(value: .34, strokeWidth: 9, backgroundColor: AppColors.softBlue),
                    ),
                    const Text('34%', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
                  ],
                ),
              ),
              const SizedBox(width: 18),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('A1 • Chapter 1', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                    SizedBox(height: 6),
                    Text('۴ از ۱۲ درس اولیه را تجربه کرده‌ای.', style: TextStyle(color: AppColors.muted)),
                    SizedBox(height: 8),
                    Pill('در حال یادگیری', icon: Icons.auto_awesome_rounded),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        const SectionTitle(title: 'پروفایل مهارتی'),
        const SizedBox(height: 10),
        for (final item in skills)
          AppCard(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(color: AppColors.softBlue, borderRadius: BorderRadius.circular(14)),
                  child: Icon(item.$3, color: AppColors.blue),
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(child: Text(item.$1, style: const TextStyle(fontWeight: FontWeight.w900))),
                          Text('${(item.$2 * 100).round()}%', style: const TextStyle(fontWeight: FontWeight.w900)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(99),
                        child: LinearProgressIndicator(value: item.$2, minHeight: 8),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
}

class ProfilePage extends StatefulWidget {
  const ProfilePage({required this.profile, required this.onSave, super.key});
  final LearnerProfile profile; final Future<void> Function(LearnerProfile) onSave;
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  late final TextEditingController _name = TextEditingController(text: widget.profile.name == 'دوست من' ? '' : widget.profile.name);
  late String _title = widget.profile.title;
  late int _goal = widget.profile.dailyGoal;
  @override
  void dispose() { _name.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 30),
      children: [
        const BrandLogo(compact: true),
        const SizedBox(height: 14),
        const Text('پروفایل من', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
        const SizedBox(height: 5),
        const Text('LangPan محتوا و لحن تجربه را بر اساس مشخصات خودت شخصی می‌کند.', style: TextStyle(color: AppColors.muted, height: 1.5)),
        const SizedBox(height: 18),
        AppCard(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(child: PandaCompanion(mood: PandaMood.happy)),
              const SizedBox(height: 4),
              const Text('نامی که دوست داری در برنامه ببینی', style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              TextField(controller: _name, textDirection: TextDirection.ltr, decoration: const InputDecoration(hintText: 'مثلاً Sara یا Ali')),
              const SizedBox(height: 15),
              const Text('عنوان خطاب', style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: [('آقا', 'آقا'), ('خانم', 'خانم'), ('', 'ترجیح می‌دهم نگویم')]
                    .map((item) => ChoiceChip(label: Text(item.$2), selected: _title == item.$1, onSelected: (_) => setState(() => _title = item.$1)))
                    .toList(),
              ),
              const SizedBox(height: 15),
              const Text('هدف روزانه', style: TextStyle(fontWeight: FontWeight.w900)),
              Slider(value: _goal.toDouble(), min: 5, max: 60, divisions: 11, label: '$_goal دقیقه', onChanged: (v) => setState(() => _goal = v.round())),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: FilledButton.icon(
                  onPressed: () async {
                    await widget.onSave(widget.profile.copyWith(
                      name: _name.text.trim().isEmpty ? 'دوست من' : _name.text.trim(),
                      title: _title,
                      dailyGoal: _goal,
                    ));
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('پروفایل ذخیره شد.')));
                    }
                  },
                  icon: const Icon(Icons.check_rounded),
                  label: const Text('ذخیره تغییرات'),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
