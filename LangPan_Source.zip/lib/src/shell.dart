import 'package:flutter/material.dart';

import 'content_repository.dart';
import 'lesson_player.dart';
import 'theme.dart';
import 'widgets.dart';

class LangPanShell extends StatefulWidget {
  const LangPanShell({super.key});

  @override
  State<LangPanShell> createState() => _LangPanShellState();
}

class _LangPanShellState extends State<LangPanShell> {
  final ContentRepository _repository = const ContentRepository();
  int _index = 0;
  Map<String, dynamic>? _curriculum;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadCurriculum();
  }

  Future<void> _loadCurriculum() async {
    setState(() => _error = null);
    try {
      final value = await _repository.loadCurriculum();
      if (!mounted) {
        return;
      }
      setState(() => _curriculum = value);
    } catch (e) {
      if (!mounted) {
        return;
      }
      setState(() => _error = '$e');
    }
  }

  void _openLearn() => setState(() => _index = 1);

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      HomePage(onLearn: _openLearn),
      LearnPage(
        curriculum: _curriculum,
        error: _error,
        onRetry: _loadCurriculum,
      ),
      const ReviewPage(),
      const ProgressPage(),
      const ProfilePage(),
    ];

    return Scaffold(
      body: SafeArea(child: pages[_index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'خانه',
          ),
          NavigationDestination(
            icon: Icon(Icons.school_outlined),
            selectedIcon: Icon(Icons.school),
            label: 'یادگیری',
          ),
          NavigationDestination(
            icon: Icon(Icons.replay_outlined),
            selectedIcon: Icon(Icons.replay),
            label: 'مرور',
          ),
          NavigationDestination(
            icon: Icon(Icons.insights_outlined),
            selectedIcon: Icon(Icons.insights),
            label: 'پیشرفت',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'پروفایل',
          ),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({required this.onLearn, super.key});

  final VoidCallback onLearn;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
      children: [
        Row(
          children: [
            const LangPanMark(size: 48),
            const SizedBox(width: 12),
            const Expanded(
              child: Text(
                'LangPan',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w800,
                  color: AppColors.ink,
                ),
              ),
            ),
            IconButton(
              onPressed: () => showComingSoon(context),
              icon: const Icon(Icons.notifications_none),
            ),
          ],
        ),
        const SizedBox(height: 20),
        const _PandaHero(),
        const SizedBox(height: 18),
        SectionTitle(
          title: 'امروز با هم چه کار کنیم؟',
          action: 'یادگیری',
          onTap: onLearn,
        ),
        const SizedBox(height: 10),
        _TodayCard(onTap: onLearn),
        const SizedBox(height: 18),
        const SectionTitle(title: 'ادامه مسیر'),
        const SizedBox(height: 10),
        _GoalCard(onTap: onLearn),
        const SizedBox(height: 18),
        const SectionTitle(title: 'دسترسی سریع'),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: _QuickCard(
                icon: Icons.replay,
                label: 'مرور',
                onTap: () => showComingSoon(context),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _QuickCard(
                icon: Icons.record_voice_over,
                label: 'مکالمه',
                onTap: onLearn,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _QuickCard(
                icon: Icons.emoji_events_outlined,
                label: 'دستاوردها',
                onTap: () => showComingSoon(context),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _PandaHero extends StatelessWidget {
  const _PandaHero();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppColors.blue, AppColors.indigo],
        ),
        borderRadius: BorderRadius.circular(28),
      ),
      child: const Row(
        children: [
          PandaAvatar(size: 110),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'سلام! من پاندا هستم 🐼',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 21,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  'امروز یک قدم کوچک برداریم و انگلیسی را در موقعیت واقعی تمرین کنیم.',
                  style: TextStyle(color: Colors.white70, height: 1.4),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TodayCard extends StatelessWidget {
  const _TodayCard({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.all(18),
      onTap: onTap,
      child: const Row(
        children: [
          CircleAvatar(
            radius: 27,
            backgroundColor: Color(0xFFEAF2FF),
            child: Icon(Icons.play_arrow_rounded, color: AppColors.blue),
          ),
          SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'A1 • Hello!',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: AppColors.ink,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'سلام کردن و معرفی خودت',
                  style: TextStyle(color: AppColors.muted),
                ),
              ],
            ),
          ),
          Icon(Icons.chevron_right),
        ],
      ),
    );
  }
}

class _GoalCard extends StatelessWidget {
  const _GoalCard({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.all(18),
      onTap: onTap,
      child: const Row(
        children: [
          Icon(
            Icons.local_fire_department_rounded,
            color: Colors.orange,
            size: 32,
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('هدف امروز', style: TextStyle(fontWeight: FontWeight.w800)),
                SizedBox(height: 5),
                Text(
                  '۱۰ دقیقه • ۱ درس',
                  style: TextStyle(color: AppColors.muted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _QuickCard extends StatelessWidget {
  const _QuickCard({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.symmetric(vertical: 18),
      onTap: onTap,
      child: Column(
        children: [
          Icon(icon, color: AppColors.blue),
          const SizedBox(height: 8),
          Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class LearnPage extends StatelessWidget {
  const LearnPage({
    required this.curriculum,
    required this.error,
    required this.onRetry,
    super.key,
  });

  final Map<String, dynamic>? curriculum;
  final String? error;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    final errorText = error;
    if (errorText != null) {
      return ErrorView(message: errorText, onRetry: onRetry);
    }
    final data = curriculum;
    if (data == null) {
      return const Center(child: CircularProgressIndicator());
    }
    final levels = asList(data['levels']);
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
      children: [
        const Text(
          'مسیر یادگیری',
          style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.w800,
            color: AppColors.ink,
          ),
        ),
        const SizedBox(height: 6),
        const Text(
          'هر سطح را باز کن و مستقیم وارد فصل‌ها و درس‌ها شو.',
          style: TextStyle(color: AppColors.muted),
        ),
        const SizedBox(height: 18),
        for (final item in levels)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _LevelCard(level: asMap(item)),
          ),
      ],
    );
  }
}

class _LevelCard extends StatelessWidget {
  const _LevelCard({required this.level});

  final Map<String, dynamic> level;

  @override
  Widget build(BuildContext context) {
    final cefr = asText(level['cefr']).toUpperCase().replaceAll('_', '-');
    final title = asText(level['title'], cefr);
    final chapters = asList(level['chapters']);
    final authored = chapters
        .where((c) => asMap(c)['status'] == 'authored')
        .length;

    return AppCard(
      padding: const EdgeInsets.all(16),
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (_) => LevelPage(level: level)),
        );
      },
      child: Row(
        children: [
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.blue, AppColors.indigo],
              ),
              borderRadius: BorderRadius.circular(18),
            ),
            alignment: Alignment.center,
            child: Text(
              cefr,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w800,
                fontSize: 13,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: AppColors.ink,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${chapters.length} فصل  •  $authored فصل آماده تست',
                  style: const TextStyle(color: AppColors.muted),
                ),
              ],
            ),
          ),
          const Icon(Icons.chevron_right),
        ],
      ),
    );
  }
}

class LevelPage extends StatelessWidget {
  const LevelPage({required this.level, super.key});

  final Map<String, dynamic> level;

  @override
  Widget build(BuildContext context) {
    final chapters = asList(level['chapters']);
    final title = asText(level['title']);
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            '$title • فصل‌ها',
            style: const TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.w800,
              color: AppColors.ink,
            ),
          ),
          const SizedBox(height: 16),
          for (var i = 0; i < chapters.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: _ChapterCard(
                level: level,
                chapter: asMap(chapters[i]),
                number: i + 1,
              ),
            ),
        ],
      ),
    );
  }
}

class _ChapterCard extends StatelessWidget {
  const _ChapterCard({
    required this.level,
    required this.chapter,
    required this.number,
  });

  final Map<String, dynamic> level;
  final Map<String, dynamic> chapter;
  final int number;

  @override
  Widget build(BuildContext context) {
    final authored = chapter['status'] == 'authored';
    final lessonCount = (chapter['lesson_count'] as num?)?.toInt() ?? 0;
    final canOpen = authored && lessonCount > 0;

    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 8,
        ),
        leading: CircleAvatar(
          backgroundColor: canOpen
              ? AppColors.blue.withValues(alpha: .12)
              : Colors.black12,
          child: Text(
            '$number',
            style: TextStyle(
              color: canOpen ? AppColors.blue : AppColors.muted,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        title: Text(
          asText(chapter['title']),
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Text(
          canOpen
              ? '$lessonCount درس • آماده تست'
              : 'محتوای این فصل در حال توسعه است',
        ),
        trailing: canOpen ? const Icon(Icons.chevron_right) : null,
        onTap: canOpen
            ? () {
                Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => LessonListPage(
                      level: level,
                      chapter: chapter,
                      lessonCount: lessonCount,
                    ),
                  ),
                );
              }
            : null,
      ),
    );
  }
}

class LessonListPage extends StatefulWidget {
  const LessonListPage({
    required this.level,
    required this.chapter,
    required this.lessonCount,
    super.key,
  });

  final Map<String, dynamic> level;
  final Map<String, dynamic> chapter;
  final int lessonCount;

  @override
  State<LessonListPage> createState() => _LessonListPageState();
}

class _LessonListPageState extends State<LessonListPage> {
  final ContentRepository _repository = const ContentRepository();
  late Future<List<Map<String, dynamic>>> _lessons;

  @override
  void initState() {
    super.initState();
    _lessons = _load();
  }

  Future<List<Map<String, dynamic>>> _load() {
    return _repository.loadLessons(
      chapterId: asText(widget.chapter['id']),
      lessonCount: widget.lessonCount,
    );
  }

  void _retry() {
    setState(() => _lessons = _load());
  }

  @override
  Widget build(BuildContext context) {
    final title =
        '${asText(widget.level['title'])} • ${asText(widget.chapter['title'])}';
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _lessons,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return ErrorView(message: '${snapshot.error}', onRetry: _retry);
          }
          final lessons = snapshot.data ?? const <Map<String, dynamic>>[];
          return ListView.separated(
            padding: const EdgeInsets.all(20),
            itemCount: lessons.length,
            separatorBuilder: (_, _) => const SizedBox(height: 10),
            itemBuilder: (context, index) {
              final lesson = lessons[index];
              return Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 6,
                  ),
                  leading: CircleAvatar(
                    backgroundColor: AppColors.blue.withValues(alpha: .1),
                    child: Text(
                      '${index + 1}',
                      style: const TextStyle(
                        color: AppColors.blue,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  title: Text(
                    asText(lesson['title']),
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  subtitle: Text(asText(lesson['communicative_goal'])),
                  trailing: const Icon(Icons.play_arrow_rounded),
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => LessonPlayer(lesson: lesson),
                      ),
                    );
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class ReviewPage extends StatelessWidget {
  const ReviewPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const EmptyFeature(
      icon: Icons.replay,
      title: 'مرور هوشمند',
      text: 'مرورهای فاصله‌دار اینجا قرار می‌گیرند.',
    );
  }
}

class ProgressPage extends StatelessWidget {
  const ProgressPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const EmptyFeature(
      icon: Icons.insights,
      title: 'پیشرفت من',
      text: 'بعد از کامل کردن اولین درس، پیشرفت تو اینجا نمایش داده می‌شود.',
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text(
          'پروفایل',
          style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.w800,
            color: AppColors.ink,
          ),
        ),
        const SizedBox(height: 20),
        const AppCard(
          child: Row(
            children: [
              LangPanMark(size: 64),
              SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'یادگیرنده LangPan',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'English • American pronunciation',
                      style: TextStyle(color: AppColors.muted),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: ListTile(
            leading: const Icon(Icons.settings_outlined),
            title: const Text('تنظیمات'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => showComingSoon(context),
          ),
        ),
      ],
    );
  }
}
