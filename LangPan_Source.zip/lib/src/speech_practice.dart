import 'dart:async';

import 'package:flutter/material.dart';

import 'content_repository.dart';
import 'panda.dart';
import 'speech_service.dart';
import 'theme.dart';
import 'tts_service.dart';
import 'widgets.dart';

class SpeechPracticeCard extends StatefulWidget {
  const SpeechPracticeCard({
    required this.prompt,
    required this.expectedVariants,
    this.name = 'دوست من',
    super.key,
  });

  final String prompt;
  final List<String> expectedVariants;
  final String name;

  @override
  State<SpeechPracticeCard> createState() => _SpeechPracticeCardState();
}

class _SpeechPracticeCardState extends State<SpeechPracticeCard>
    with SingleTickerProviderStateMixin {
  late final SpeechCaptureService _speech = SpeechCaptureService();
  late final TtsService _tts = TtsService();
  late final AnimationController _pulse = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  );
  StreamSubscription<double>? _levelSubscription;
  bool _recording = false;
  bool _busy = false;
  double _level = 0;
  String _liveText = '';
  SpeechAnalysis? _analysis;
  String? _error;

  @override
  void initState() {
    super.initState();
    _levelSubscription = _speech.soundLevels.listen((value) {
      if (!mounted) return;
      setState(() => _level = value.clamp(-2.0, 10.0).toDouble());
    });
  }

  String _personalize(String text) {
    return text.replaceAll('Masoud', exampleName(widget.name));
  }

  Future<void> _speakPrompt() async {
    if (widget.expectedVariants.isEmpty) {
      return;
    }
    try {
      await _tts.speak(_personalize(widget.expectedVariants.first));
    } catch (_) {
      if (!mounted) return;
      setState(() => _error = 'پخش صدا روی این دستگاه در دسترس نیست.');
    }
  }

  Future<void> _toggleRecording() async {
    if (_busy) return;
    if (_recording) {
      await _finishRecording();
      return;
    }

    setState(() {
      _busy = true;
      _analysis = null;
      _error = null;
      _liveText = '';
    });
    final started = await _speech.start(
      onTranscript: (text, _) {
        if (!mounted) return;
        setState(() => _liveText = text);
      },
    );
    if (!mounted) return;
    if (!started) {
      setState(() {
        _busy = false;
        _error = 'میکروفن یا سرویس تشخیص گفتار در دسترس نیست. مجوز میکروفن را بررسی کن.';
      });
      return;
    }
    _pulse.repeat(reverse: true);
    setState(() {
      _busy = false;
      _recording = true;
    });
  }

  Future<void> _finishRecording() async {
    setState(() => _busy = true);
    _pulse.stop();
    final variants = widget.expectedVariants.map(_personalize).toList();
    final result = await _speech.stop(expectedVariants: variants);
    if (!mounted) return;
    setState(() {
      _busy = false;
      _recording = false;
      _analysis = result;
      _level = 0;
    });
  }

  @override
  void dispose() {
    _pulse.dispose();
    _levelSubscription?.cancel();
    _speech.dispose();
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final result = _analysis;
    return Column(
      children: [
        AppCard(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Row(
                children: [
                  const Pill(
                    'SPEAKING LAB',
                    icon: Icons.graphic_eq_rounded,
                    color: AppColors.softMint,
                  ),
                  const Spacer(),
                  IconButton(
                    tooltip: 'شنیدن نمونه',
                    onPressed: _speakPrompt,
                    icon: const Icon(Icons.volume_up_rounded),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                _personalize(widget.prompt),
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w900,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 20),
              AnimatedBuilder(
                animation: _pulse,
                builder: (context, _) {
                  final scale = _recording ? 1 + _pulse.value * .07 : 1.0;
                  return Transform.scale(
                    scale: scale,
                    child: GestureDetector(
                      onTap: _toggleRecording,
                      child: Container(
                        width: 112,
                        height: 112,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                            colors: _recording
                                ? const [Color(0xFFFF6B81), Color(0xFFE5395F)]
                                : const [AppColors.blue, AppColors.indigo],
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: (_recording
                                      ? const Color(0x44E5395F)
                                      : const Color(0x443B6FFF)),
                              blurRadius: 28,
                              spreadRadius: 4 + _level.abs() * 1.2,
                            ),
                          ],
                        ),
                        child: Icon(
                          _recording ? Icons.stop_rounded : Icons.mic_rounded,
                          color: Colors.white,
                          size: 46,
                        ),
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(height: 10),
              Text(
                _recording
                    ? 'در حال شنیدن… دوباره ضربه بزن برای پایان'
                    : 'برای پاسخ دادن لمس کن',
                style: const TextStyle(
                  color: AppColors.muted,
                  fontWeight: FontWeight.w700,
                ),
              ),
              if (_busy) ...[
                const SizedBox(height: 12),
                const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2.4),
                ),
              ],
              if (_recording || _liveText.isNotEmpty) ...[
                const SizedBox(height: 16),
                _Waveform(level: _level, active: _recording),
                const SizedBox(height: 12),
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: Text(
                    _liveText.isEmpty ? 'گوش می‌دهم…' : _liveText,
                    style: const TextStyle(
                      color: AppColors.ink,
                      fontWeight: FontWeight.w700,
                      height: 1.5,
                    ),
                  ),
                ),
              ],
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(
                  _error!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: AppColors.error, height: 1.5),
                ),
              ],
            ],
          ),
        ),
        if (result != null) ...[
          const SizedBox(height: 12),
          _SpeechResultCard(result: result),
        ],
        const SizedBox(height: 12),
        PandaSpeechBubble(
          mood: result?.isStrong == true
              ? PandaMood.proud
              : result?.isDeveloping == true
                  ? PandaMood.encouraging
                  : PandaMood.listening,
          text: result?.isStrong == true
              ? 'عالی! جمله را منتقل کردی. حالا همان جمله را یک بار طبیعی‌تر و با ریتم آرام تکرار کن.'
              : result?.isDeveloping == true
                  ? 'خوب پیش رفتی. معنی قابل تشخیص است؛ حالا یک بار دیگر روی کلمات مهم تمرکز کنیم.'
                  : 'من اینجا هستم. اول نمونه را گوش کن، بعد آرام و واضح جواب بده.',
        ),
      ],
    );
  }
}

class _Waveform extends StatelessWidget {
  const _Waveform({required this.level, required this.active});

  final double level;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 46,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(22, (index) {
          final distance = (index - 10.5).abs();
          final base = active ? 8.0 + (1 - distance / 12) * 18 : 5.0;
          final boost =
              active ? (level.abs() / 4).clamp(0.0, 2.2).toDouble() : 0.0;
          return AnimatedContainer(
            duration: const Duration(milliseconds: 90),
            width: 4,
            height: base + boost * (index.isEven ? 7 : 3),
            margin: const EdgeInsets.symmetric(horizontal: 2),
            decoration: BoxDecoration(
              color: active ? AppColors.blue : AppColors.border,
              borderRadius: BorderRadius.circular(99),
            ),
          );
        }),
      ),
    );
  }
}

class _SpeechResultCard extends StatelessWidget {
  const _SpeechResultCard({required this.result});

  final SpeechAnalysis result;

  @override
  Widget build(BuildContext context) {
    final score = (result.intelligibility * 100).round();
    return AppCard(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  result.isStrong
                      ? 'گفتارت خوب تشخیص داده شد'
                      : 'یک بار دیگر تمرین کنیم',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              CircleAvatar(
                radius: 25,
                backgroundColor:
                    result.isStrong ? AppColors.softMint : AppColors.softPurple,
                child: Text(
                  '$score',
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _ScoreLine(
            label: 'شباهت پاسخ',
            value: result.similarity,
          ),
          const SizedBox(height: 8),
          _ScoreLine(
            label: 'اطمینان تشخیص',
            value: result.confidence,
          ),
          const SizedBox(height: 12),
          Text(
            'متن تشخیص‌داده‌شده: ${result.transcript.isEmpty ? '—' : result.transcript}',
            style: const TextStyle(height: 1.5, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 12),
          for (final item in result.feedback)
            Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.tips_and_updates_rounded,
                      size: 18, color: AppColors.warning),
                  const SizedBox(width: 7),
                  Expanded(child: Text(item, style: const TextStyle(height: 1.45))),
                ],
              ),
            ),
          const SizedBox(height: 5),
          const Text(
            'این امتیاز، ارزیابی اولیهٔ قابل‌فهم‌بودن و تطبیق پاسخ با هدف درس است؛ تحلیل دقیق واج‌ها و استرس در لایهٔ Speech Engine حرفه‌ای‌تر ادامه پیدا می‌کند.',
            style: TextStyle(fontSize: 11, color: AppColors.muted, height: 1.5),
          ),
        ],
      ),
    );
  }
}

class _ScoreLine extends StatelessWidget {
  const _ScoreLine({required this.label, required this.value});

  final String label;
  final double value;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 110,
          child: Text(label, style: const TextStyle(color: AppColors.muted)),
        ),
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(99),
            child: LinearProgressIndicator(
              value: value.clamp(0.0, 1.0).toDouble(),
              minHeight: 8,
            ),
          ),
        ),
        const SizedBox(width: 8),
        Text('${(value * 100).round()}%', style: const TextStyle(fontWeight: FontWeight.w900)),
      ],
    );
  }
}
