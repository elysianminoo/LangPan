import 'dart:async';
import 'dart:math' as math;

import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

class SpeechAnalysis {
  const SpeechAnalysis({
    required this.transcript,
    required this.expected,
    required this.similarity,
    required this.confidence,
    required this.duration,
    required this.wordsPerMinute,
    required this.intelligibility,
    required this.feedback,
  });

  final String transcript;
  final String expected;
  final double similarity;
  final double confidence;
  final Duration duration;
  final double wordsPerMinute;
  final double intelligibility;
  final List<String> feedback;

  bool get isStrong => intelligibility >= .78 && similarity >= .72;
  bool get isDeveloping => intelligibility >= .55 || similarity >= .55;
}

class SpeechCaptureService {
  SpeechCaptureService()
      : _recorder = AudioRecorder(),
        _recognizer = stt.SpeechToText();

  final AudioRecorder _recorder;
  final stt.SpeechToText _recognizer;
  final StreamController<double> _soundLevels =
      StreamController<double>.broadcast();

  Stream<double> get soundLevels => _soundLevels.stream;
  String? _recordingPath;
  DateTime? _startedAt;
  String _latestTranscript = '';
  double _latestConfidence = 0;
  bool _ready = false;

  Future<bool> initialize() async {
    if (_ready) return true;
    _ready = await _recognizer.initialize(
      onStatus: (_) {},
      onError: (_) {},
      options: <stt.SpeechConfigOption>[stt.SpeechToText.androidNoBluetooth],
    );
    return _ready;
  }

  Future<bool> start({
    String localeId = 'en_US',
    void Function(String transcript, double confidence)? onTranscript,
  }) async {
    final ready = await initialize();
    if (!ready) return false;
    if (await _recorder.isRecording()) return true;

    final directory = await getTemporaryDirectory();
    final stamp = DateTime.now().millisecondsSinceEpoch;
    _recordingPath = '${directory.path}/langpan_speech_$stamp.m4a';
    _latestTranscript = '';
    _latestConfidence = 0;
    _startedAt = DateTime.now();

    final hasPermission = await _recorder.hasPermission();
    if (!hasPermission) {
      _startedAt = null;
      _recordingPath = null;
      return false;
    }

    await _recorder.start(
      const RecordConfig(
        encoder: AudioEncoder.aacLc,
        sampleRate: 44100,
        bitRate: 128000,
      ),
      path: _recordingPath!,
    );

    await _recognizer.listen(
      localeId: localeId,
      listenFor: const Duration(seconds: 15),
      pauseFor: const Duration(seconds: 2),
      partialResults: true,
      cancelOnError: false,
      onSoundLevelChange: (level) {
        _soundLevels.add(level);
      },
      onResult: (SpeechRecognitionResult result) {
        _latestTranscript = result.recognizedWords;
        if (result.hasConfidenceRating) {
          _latestConfidence = result.confidence;
        }
        onTranscript?.call(_latestTranscript, _latestConfidence);
      },
    );
    return true;
  }

  Future<SpeechAnalysis?> stop({required List<String> expectedVariants}) async {
    if (_startedAt == null) return null;
    await _recognizer.stop();
    final path = await _recorder.stop();
    final startedAt = _startedAt!;
    _startedAt = null;
    _recordingPath = path ?? _recordingPath;

    final duration = DateTime.now().difference(startedAt);
    final transcript = _latestTranscript.trim();
    final scored = expectedVariants.map((expected) => MapEntry(expected, _textSimilarity(transcript, expected))).toList();
    scored.sort((a, b) => b.value.compareTo(a.value));
    final expected = scored.isEmpty ? '' : scored.first.key;
    final similarity = scored.isEmpty ? 0.0 : scored.first.value;
    final confidence = _latestConfidence > 0 ? _latestConfidence : similarity;
    final seconds = math.max(duration.inMilliseconds / 1000, 0.5);
    final words = transcript.isEmpty ? 0 : transcript.split(RegExp(r'\s+')).length;
    final wpm = words / seconds * 60;
    final intelligibility = (confidence * .65 + similarity * .35).clamp(0.0, 1.0);

    final feedback = <String>[];
    if (transcript.isEmpty) {
      feedback.add('صدایی از جمله دریافت نشد؛ دوباره آرام و نزدیک به میکروفن بگو.');
    } else if (similarity < .55) {
      feedback.add('معنی کلی هنوز کامل منتقل نشده؛ جمله را کوتاه‌تر و واضح‌تر بگو.');
    } else if (similarity < .78) {
      feedback.add('خوب بود؛ یک بار دیگر روی کلمات کلیدی جمله تمرکز کن.');
    } else {
      feedback.add('پیام جمله به‌خوبی تشخیص داده شد. حالا روی ریتم طبیعی تمرکز کن.');
    }
    if (duration.inMilliseconds < 700) {
      feedback.add('خیلی سریع شروع کردی؛ یک مکث کوتاه قبل از جمله کمک می‌کند.');
    }
    if (wpm > 170 && words > 5) {
      feedback.add('سرعتت بالاست؛ برای A1 وضوح مهم‌تر از سرعت است.');
    }
    if (confidence > 0 && confidence < .5) {
      feedback.add('تشخیص صوتی مطمئن نبود؛ صدای محیط را کمتر کن و دوباره امتحان کن.');
    }

    return SpeechAnalysis(
      transcript: transcript,
      expected: expected,
      similarity: similarity,
      confidence: confidence,
      duration: duration,
      wordsPerMinute: wpm,
      intelligibility: intelligibility,
      feedback: feedback,
    );
  }

  Future<void> cancel() async {
    await _recognizer.cancel();
    if (await _recorder.isRecording()) {
      await _recorder.cancel();
    }
    _startedAt = null;
  }

  Future<void> dispose() async {
    await _soundLevels.close();
    _recorder.dispose();
  }

  double _textSimilarity(String actual, String expected) {
    final a = _tokens(actual);
    final b = _tokens(expected);
    if (a.isEmpty || b.isEmpty) return 0;
    final distance = _levenshtein(a, b);
    return (1 - distance / math.max(a.length, b.length)).clamp(0.0, 1.0);
  }

  List<String> _tokens(String text) {
    return text
        .toLowerCase()
        .replaceAll(RegExp(r"[^a-z0-9']+"), ' ')
        .trim()
        .split(RegExp(r'\s+'))
        .where((e) => e.isNotEmpty)
        .map((e) => _normalize(e))
        .toList();
  }

  String _normalize(String token) {
    return token
        .replaceAll("i'm", 'i am')
        .replaceAll('im', 'i am')
        .replaceAll("what's", 'what is')
        .replaceAll('whats', 'what is');
  }

  int _levenshtein(List<String> a, List<String> b) {
    final previous = List<int>.generate(b.length + 1, (i) => i);
    for (var i = 1; i <= a.length; i++) {
      var current = List<int>.filled(b.length + 1, 0);
      current[0] = i;
      for (var j = 1; j <= b.length; j++) {
        final cost = a[i - 1] == b[j - 1] ? 0 : 1;
        current[j] = math.min(
          math.min(current[j - 1] + 1, previous[j] + 1),
          previous[j - 1] + cost,
        );
      }
      for (var j = 0; j < current.length; j++) {
        previous[j] = current[j];
      }
    }
    return previous[b.length];
  }
}
