import 'dart:async';
import 'dart:math' as math;

import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

class SpeechAnalysis {
  const SpeechAnalysis({
    required this.transcript,
    required this.expected,
    required this.similarity,
    required this.confidence,
    required this.duration,
    required this.wordsPerMinute,
    required this.intelligibility,
    required this.feedback,
  });

  final String transcript;
  final String expected;
  final double similarity;
  final double confidence;
  final Duration duration;
  final double wordsPerMinute;
  final double intelligibility;
  final List<String> feedback;

  bool get isStrong => intelligibility >= .78 && similarity >= .72;
  bool get isDeveloping => intelligibility >= .55 || similarity >= .55;
}

const Map<String, String> _contractions = <String, String>{
  "i'm": 'i am',
  "you're": 'you are',
  "we're": 'we are',
  "they're": 'they are',
  "he's": 'he is',
  "she's": 'she is',
  "it's": 'it is',
  "that's": 'that is',
  "there's": 'there is',
  "what's": 'what is',
  "where's": 'where is',
  "who's": 'who is',
  "don't": 'do not',
  "doesn't": 'does not',
  "can't": 'can not',
  "isn't": 'is not',
  "aren't": 'are not',
};

/// Lower-cases, expands common contractions and splits [text] into words.
List<String> speechTokens(String text) {
  var value = text.toLowerCase().replaceAll('\u2019', "'");
  _contractions.forEach((short, full) {
    value = value.replaceAll(
      RegExp('\\b${RegExp.escape(short)}'),
      full,
    );
  });
  return value
      .replaceAll(RegExp(r"[^a-z0-9\s]+"), ' ')
      .trim()
      .split(RegExp(r'\s+'))
      .where((token) => token.isNotEmpty)
      .toList();
}

/// Word-level similarity between 0 and 1 (1 = identical after normalisation).
double textSimilarity(String actual, String expected) {
  final a = speechTokens(actual);
  final b = speechTokens(expected);
  if (a.isEmpty || b.isEmpty) {
    return 0;
  }
  final distance = _levenshtein(a, b);
  final longest = math.max(a.length, b.length);
  return (1 - distance / longest).clamp(0.0, 1.0).toDouble();
}

int _levenshtein(List<String> a, List<String> b) {
  var previous = List<int>.generate(b.length + 1, (i) => i);
  for (var i = 1; i <= a.length; i++) {
    final current = List<int>.filled(b.length + 1, 0);
    current[0] = i;
    for (var j = 1; j <= b.length; j++) {
      final cost = a[i - 1] == b[j - 1] ? 0 : 1;
      current[j] = math.min(
        math.min(current[j - 1] + 1, previous[j] + 1),
        previous[j - 1] + cost,
      );
    }
    previous = current;
  }
  return previous[b.length];
}

/// Live speech recognition with a soft scoring layer on top.
///
/// Only the device speech recogniser touches the microphone. A second,
/// simultaneous audio recorder is deliberately not used: on Android two
/// capture clients at once make recognition fail on many devices.
class SpeechCaptureService {
  SpeechCaptureService();

  final stt.SpeechToText _recognizer = stt.SpeechToText();
  final StreamController<double> _soundLevels =
      StreamController<double>.broadcast();

  Stream<double> get soundLevels => _soundLevels.stream;

  Stopwatch? _stopwatch;
  String _latestTranscript = '';
  double _latestConfidence = 0;
  bool _ready = false;

  Future<bool> initialize() async {
    if (_ready) {
      return true;
    }
    try {
      _ready = await _recognizer.initialize(
        onStatus: (_) {},
        onError: (_) {},
      );
    } catch (_) {
      _ready = false;
    }
    return _ready;
  }

  Future<bool> start({
    String localeId = 'en_US',
    void Function(String transcript, double confidence)? onTranscript,
  }) async {
    final ready = await initialize();
    if (!ready) {
      return false;
    }
    _latestTranscript = '';
    _latestConfidence = 0;
    _stopwatch = Stopwatch()..start();

    try {
      await _recognizer.listen(
        // ignore: deprecated_member_use
        localeId: localeId,
        // ignore: deprecated_member_use
        listenFor: const Duration(seconds: 15),
        // ignore: deprecated_member_use
        pauseFor: const Duration(seconds: 3),
        onSoundLevelChange: (level) {
          if (!_soundLevels.isClosed) {
            _soundLevels.add(level);
          }
        },
        onResult: (SpeechRecognitionResult result) {
          _latestTranscript = result.recognizedWords;
          if (result.hasConfidenceRating) {
            _latestConfidence = result.confidence;
          }
          onTranscript?.call(_latestTranscript, _latestConfidence);
        },
        listenOptions: stt.SpeechListenOptions(
          partialResults: true,
          cancelOnError: false,
        ),
      );
    } catch (_) {
      _stopwatch = null;
      return false;
    }
    return true;
  }

  Future<SpeechAnalysis?> stop({required List<String> expectedVariants}) async {
    final stopwatch = _stopwatch;
    if (stopwatch == null) {
      return null;
    }
    await _recognizer.stop();
    // The final recognition result is delivered shortly after stop().
    await Future<void>.delayed(const Duration(milliseconds: 450));
    stopwatch.stop();
    _stopwatch = null;

    final duration = stopwatch.elapsed;
    final transcript = _latestTranscript.trim();

    var bestExpected = '';
    var similarity = 0.0;
    for (final variant in expectedVariants) {
      final score = textSimilarity(transcript, variant);
      if (bestExpected.isEmpty || score > similarity) {
        bestExpected = variant;
        similarity = score;
      }
    }

    final confidence = _latestConfidence > 0 ? _latestConfidence : similarity;
    final seconds = math.max(duration.inMilliseconds / 1000, 0.5);
    final words = speechTokens(transcript).length;
    final wpm = words / seconds * 60;
    final intelligibility = (confidence * .65 + similarity * .35)
        .clamp(0.0, 1.0)
        .toDouble();

    final feedback = <String>[];
    if (transcript.isEmpty) {
      feedback.add('صدایی از جمله دریافت نشد؛ دوباره آرام و نزدیک به میکروفن بگو.');
    } else if (similarity < .55) {
      feedback.add('معنی کلی هنوز کامل منتقل نشده؛ جمله را کوتاه‌تر و واضح‌تر بگو.');
    } else if (similarity < .78) {
      feedback.add('خوب بود؛ یک بار دیگر روی کلمات کلیدی جمله تمرکز کن.');
    } else {
      feedback.add('پیام جمله به‌خوبی تشخیص داده شد. حالا روی ریتم طبیعی تمرکز کن.');
    }
    if (wpm > 170 && words > 5) {
      feedback.add('سرعتت بالاست؛ برای A1 وضوح مهم‌تر از سرعت است.');
    }
    if (_latestConfidence > 0 && _latestConfidence < .5) {
      feedback.add('تشخیص صوتی مطمئن نبود؛ صدای محیط را کمتر کن و دوباره امتحان کن.');
    }

    return SpeechAnalysis(
      transcript: transcript,
      expected: bestExpected,
      similarity: similarity,
      confidence: confidence,
      duration: duration,
      wordsPerMinute: wpm,
      intelligibility: intelligibility,
      feedback: feedback,
    );
  }

  Future<void> cancel() async {
    try {
      await _recognizer.cancel();
    } catch (_) {
      // Nothing to cancel.
    }
    _stopwatch = null;
  }

  Future<void> dispose() async {
    await cancel();
    await _soundLevels.close();
  }
}
