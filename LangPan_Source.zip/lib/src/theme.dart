import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// LangPan Design System — aligned with Brand Guidelines v1
/// Primary blues, soft surfaces, premium educational UI.
abstract final class AppColors {
  // Brand primary scale
  static const primary = Color(0xFF3B82F6);
  static const primaryLight = Color(0xFF60A5FA);
  static const primaryDark = Color(0xFF1D4ED8);
  static const secondary = Color(0xFF8B5CF6);
  static const accent = Color(0xFF06B6D4);

  // Semantic
  static const success = Color(0xFF10B981);
  static const warning = Color(0xFFF59E0B);
  static const error = Color(0xFFEF4444);
  static const info = Color(0xFF0EA5E9);

  // Neutrals & surfaces
  static const ink = Color(0xFF0F172A);
  static const muted = Color(0xFF64748B);
  static const neutral = Color(0xFF64748B);
  static const background = Color(0xFFF5F8FF);
  static const surface = Color(0xFFFFFFFF);
  static const border = Color(0xFFE2E8F0);
  static const softBlue = Color(0xFFEFF6FF);
  static const softPurple = Color(0xFFF5F3FF);
  static const softMint = Color(0xFFECFDF5);
  static const softCyan = Color(0xFFECFEFF);
  static const softPink = Color(0xFFFDF2F8);
  static const navy = Color(0xFF15244B);
  static const navyDeep = Color(0xFF0B1224);

  // Legacy aliases used across the app
  static const blue = primary;
  static const indigo = secondary;
  static const cyan = accent;
  static const mint = success;
}

abstract final class AppRadii {
  static const sm = 12.0;
  static const md = 16.0;
  static const lg = 22.0;
  static const xl = 28.0;
  static const pill = 99.0;
}

abstract final class AppShadows {
  static const soft = [
    BoxShadow(color: Color(0x1415283A), blurRadius: 24, offset: Offset(0, 12)),
  ];
  static const card = [
    BoxShadow(color: Color(0x1215283A), blurRadius: 20, offset: Offset(0, 10)),
    BoxShadow(color: Color(0x08FFFFFF), blurRadius: 1, offset: Offset(0, -1)),
  ];
  static const floating = [
    BoxShadow(color: Color(0x283B82F6), blurRadius: 28, offset: Offset(0, 14)),
  ];
}

ThemeData buildAppTheme() {
  final base = ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    fontFamily: null, // system + IRANSans when bundled later
  );

  final scheme = ColorScheme.fromSeed(
    seedColor: AppColors.primary,
    brightness: Brightness.light,
    primary: AppColors.primary,
    secondary: AppColors.secondary,
    tertiary: AppColors.accent,
    error: AppColors.error,
    surface: AppColors.surface,
  );

  return base.copyWith(
    colorScheme: scheme,
    scaffoldBackgroundColor: AppColors.background,
    splashFactory: InkSparkle.splashFactory,
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.background,
      foregroundColor: AppColors.ink,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      systemOverlayStyle: SystemUiOverlayStyle.dark,
      titleTextStyle: TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w800,
        color: AppColors.ink,
        letterSpacing: -0.2,
      ),
    ),
    textTheme: base.textTheme.copyWith(
      displayLarge: const TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: AppColors.ink, height: 1.15, letterSpacing: -0.6),
      displayMedium: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: AppColors.ink, height: 1.2, letterSpacing: -0.4),
      headlineMedium: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.ink, height: 1.25),
      titleLarge: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.ink),
      titleMedium: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.ink),
      bodyLarge: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500, color: AppColors.ink, height: 1.55),
      bodyMedium: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: AppColors.muted, height: 1.5),
      labelLarge: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.ink),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      hintStyle: const TextStyle(color: AppColors.muted, fontWeight: FontWeight.w500),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppRadii.lg),
        borderSide: const BorderSide(color: AppColors.border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppRadii.lg),
        borderSide: const BorderSide(color: AppColors.border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(AppRadii.lg),
        borderSide: const BorderSide(color: AppColors.primary, width: 1.6),
      ),
    ),
    cardTheme: CardThemeData(
      elevation: 0,
      margin: EdgeInsets.zero,
      color: AppColors.surface,
      surfaceTintColor: Colors.transparent,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppRadii.xl),
        side: const BorderSide(color: AppColors.border),
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        minimumSize: const Size.fromHeight(52),
        elevation: 0,
        shadowColor: AppColors.primary.withValues(alpha: 0.35),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadii.lg)),
        textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, letterSpacing: -0.1),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: AppColors.primary,
        minimumSize: const Size.fromHeight(52),
        side: const BorderSide(color: AppColors.border, width: 1.4),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadii.lg)),
        textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: AppColors.primary,
        textStyle: const TextStyle(fontWeight: FontWeight.w800),
      ),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: AppColors.softBlue,
      selectedColor: AppColors.primary,
      labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
      secondaryLabelStyle: const TextStyle(fontWeight: FontWeight.w700, color: Colors.white),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadii.pill)),
      side: BorderSide.none,
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: Colors.white,
      selectedItemColor: AppColors.primary,
      unselectedItemColor: AppColors.muted,
      type: BottomNavigationBarType.fixed,
      elevation: 0,
      selectedLabelStyle: TextStyle(fontWeight: FontWeight.w800, fontSize: 11),
      unselectedLabelStyle: TextStyle(fontWeight: FontWeight.w600, fontSize: 11),
    ),
    sliderTheme: SliderThemeData(
      activeTrackColor: AppColors.primary,
      inactiveTrackColor: AppColors.softBlue,
      thumbColor: AppColors.primary,
      overlayColor: AppColors.primary.withValues(alpha: 0.12),
      trackHeight: 6,
    ),
    progressIndicatorTheme: const ProgressIndicatorThemeData(
      color: AppColors.primary,
      linearTrackColor: Color(0xFFDBEAFE),
      circularTrackColor: Color(0xFFDBEAFE),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: AppColors.navy,
      contentTextStyle: const TextStyle(fontWeight: FontWeight.w600),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    dividerTheme: const DividerThemeData(color: AppColors.border, thickness: 1, space: 1),
  );
}
