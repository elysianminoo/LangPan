import 'package:flutter/material.dart';

abstract final class AppColors {
  static const blue = Color(0xFF4B7BFF);
  static const indigo = Color(0xFF6C63FF);
  static const cyan = Color(0xFF38C8E8);
  static const mint = Color(0xFF28C7A5);
  static const ink = Color(0xFF172033);
  static const muted = Color(0xFF667085);
  static const surface = Color(0xFFFFFFFF);
  static const background = Color(0xFFF5F7FB);
  static const border = Color(0xFFE6EAF2);
  static const softBlue = Color(0xFFEAF0FF);
  static const softPurple = Color(0xFFF0EDFF);
  static const softMint = Color(0xFFE7FBF6);
  static const warning = Color(0xFFF5A524);
  static const error = Color(0xFFE85D75);
}

ThemeData buildAppTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: AppColors.blue,
    brightness: Brightness.light,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme.copyWith(
      primary: AppColors.blue,
      secondary: AppColors.indigo,
      surface: AppColors.surface,
    ),
    scaffoldBackgroundColor: AppColors.background,
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.background,
      foregroundColor: AppColors.ink,
      elevation: 0,
      centerTitle: false,
    ),
    cardTheme: const CardThemeData(
      elevation: 0,
      margin: EdgeInsets.zero,
      color: AppColors.surface,
      surfaceTintColor: Colors.transparent,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(24)),
        side: BorderSide(color: AppColors.border),
      ),
    ),
  );
}
