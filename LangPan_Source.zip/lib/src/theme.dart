import 'package:flutter/material.dart';

abstract final class AppColors {
  static const blue = Color(0xFF3B82F6);
  static const indigo = Color(0xFF635BFF);
  static const cyan = Color(0xFF22D3EE);
  static const mint = Color(0xFF10B981);
  static const ink = Color(0xFF172033);
  static const muted = Color(0xFF667085);
  static const background = Color(0xFFF4F7FC);
  static const surface = Color(0xFFFFFFFF);
  static const border = Color(0xFFE4EAF4);
  static const softBlue = Color(0xFFEAF1FF);
  static const softPurple = Color(0xFFF0EDFF);
  static const softMint = Color(0xFFE7FBF5);
  static const softCyan = Color(0xFFE7FAFE);
  static const warning = Color(0xFFF59E0B);
  static const error = Color(0xFFEF476F);
  static const navy = Color(0xFF15244B);
}

ThemeData buildAppTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: AppColors.blue,
    brightness: Brightness.light,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme.copyWith(
      primary: AppColors.blue,
      secondary: AppColors.indigo,
      surface: AppColors.surface,
    ),
    scaffoldBackgroundColor: AppColors.background,
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.background,
      foregroundColor: AppColors.ink,
      elevation: 0,
      centerTitle: false,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: const BorderSide(color: AppColors.border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: const BorderSide(color: AppColors.border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(18),
        borderSide: const BorderSide(color: AppColors.blue, width: 1.5),
      ),
    ),
    cardTheme: const CardThemeData(
      elevation: 0,
      margin: EdgeInsets.zero,
      color: AppColors.surface,
      surfaceTintColor: Colors.transparent,
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(26)),
      ),
    ),
  );
}
