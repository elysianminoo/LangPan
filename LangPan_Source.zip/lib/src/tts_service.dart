import 'package:flutter_tts/flutter_tts.dart';

class TtsService {
  TtsService();

  FlutterTts? _engine;
  bool _configured = false;

  // Created lazily so that constructing the service never touches the plugin.
  FlutterTts get _tts => _engine ??= FlutterTts();

  Future<void> _configure() async {
    if (_configured) {
      return;
    }
    await _tts.setLanguage('en-US');
    await _tts.setSpeechRate(.42);
    await _tts.setPitch(1.02);
    await _tts.setVolume(1.0);
    // speak() completes when playback ends, so the UI can show a playing state.
    await _tts.awaitSpeakCompletion(true);
    _configured = true;
  }

  Future<void> speak(String text, {double? rate}) async {
    await _configure();
    if (rate != null) {
      await _tts.setSpeechRate(rate);
    }
    await _tts.stop();
    await _tts.speak(text);
  }

  Future<void> stop() async {
    final engine = _engine;
    if (engine != null) {
      await engine.stop();
    }
  }
}
