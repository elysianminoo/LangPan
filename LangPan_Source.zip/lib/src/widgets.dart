import 'package:flutter/material.dart';

import 'panda.dart';
import 'theme.dart';
import 'tts_service.dart';

class AppCard extends StatelessWidget {
  const AppCard({
    required this.child,
    this.padding = const EdgeInsets.all(20),
    this.onTap,
    this.depth = true,
    this.highlight = true,
    super.key,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final bool depth;
  final bool highlight;

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(AppRadii.xl);
    final content = Padding(padding: padding, child: child);
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: highlight
            ? const LinearGradient(
                colors: [Color(0xFFFFFFFF), Color(0xFFF7FAFF)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              )
            : null,
        color: highlight ? null : Colors.white,
        borderRadius: radius,
        border: Border.all(color: AppColors.border.withValues(alpha: 0.9)),
        boxShadow: depth ? AppShadows.card : null,
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: radius,
        clipBehavior: Clip.antiAlias,
        child: onTap == null ? content : InkWell(onTap: onTap, child: content),
      ),
    );
  }
}

class BrandLogo extends StatelessWidget {
  const BrandLogo({this.compact = false, super.key});

  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      'assets/brand/langpan_logo.png',
      width: compact ? 150 : 270,
      height: compact ? 50 : 88,
      fit: BoxFit.contain,
      alignment: Alignment.centerLeft,
    );
  }
}

class GradientCard extends StatelessWidget {
  const GradientCard({required this.child, this.onTap, this.padding = EdgeInsets.zero, super.key});

  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(30);
    final content = Padding(padding: padding, child: child);
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppColors.primary, AppColors.secondary],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: radius,
        border: Border.all(color: Colors.white.withValues(alpha: .22)),
        boxShadow: AppShadows.floating,
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: radius,
        clipBehavior: Clip.antiAlias,
        child: onTap == null ? content : InkWell(onTap: onTap, child: content),
      ),
    );
  }
}

class GraphicMenuCard extends StatelessWidget {
  const GraphicMenuCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.onTap,
    required this.colors,
    this.badge,
    super.key,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;
  final List<Color> colors;
  final String? badge;

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(28);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: radius,
        child: Ink(
          height: 154,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: colors, begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: radius,
            boxShadow: const [BoxShadow(color: Color(0x17152033), blurRadius: 20, offset: Offset(0, 10))],
          ),
          child: Stack(
            children: [
              Positioned(right: -22, top: -30, child: _Orb(color: Colors.white.withValues(alpha: .16), size: 100)),
              Positioned(left: -18, bottom: -35, child: _Orb(color: Colors.white.withValues(alpha: .11), size: 90)),
              Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: .19),
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(color: Colors.white.withValues(alpha: .24)),
                          ),
                          child: Icon(icon, color: Colors.white, size: 27),
                        ),
                        const Spacer(),
                        if (badge != null)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                            decoration: BoxDecoration(color: Colors.white.withValues(alpha: .18), borderRadius: BorderRadius.circular(99)),
                            child: Text(badge!, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w800)),
                          ),
                      ],
                    ),
                    const Spacer(),
                    Text(title, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 3),
                    Text(subtitle, style: const TextStyle(color: Colors.white70, fontSize: 11.5, height: 1.25)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Orb extends StatelessWidget {
  const _Orb({required this.color, required this.size});
  final Color color;
  final double size;
  @override
  Widget build(BuildContext context) => Container(width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle, color: color));
}

class SectionTitle extends StatelessWidget {
  const SectionTitle({required this.title, this.subtitle, this.action, this.onTap, super.key});
  final String title;
  final String? subtitle;
  final String? action;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => Row(
        children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: AppColors.ink, letterSpacing: -0.3)),
            if (subtitle != null) ...[const SizedBox(height: 4), Text(subtitle!, style: const TextStyle(color: AppColors.muted, fontSize: 12.5, height: 1.35))],
          ])),
          if (action != null) TextButton(onPressed: onTap, child: Text(action!)),
        ],
      );
}

class Pill extends StatelessWidget {
  const Pill(this.text, {this.icon, this.color = AppColors.softBlue, this.foreground = AppColors.ink, super.key});
  final String text;
  final IconData? icon;
  final Color color;
  final Color foreground;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(AppRadii.pill),
          border: Border.all(color: foreground.withValues(alpha: 0.06)),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (icon != null) ...[Icon(icon, size: 14, color: foreground), const SizedBox(width: 5)],
          Text(text, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: foreground, letterSpacing: -0.1)),
        ]),
      );
}

class PandaSpeechBubble extends StatelessWidget {
  const PandaSpeechBubble({required this.text, this.mood = PandaMood.happy, super.key});
  final String text;
  final String mood;

  @override
  Widget build(BuildContext context) => Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        PandaCompanion(compact: true, mood: mood),
        Expanded(
          child: Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(17),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.only(topLeft: Radius.circular(24), topRight: Radius.circular(24), bottomLeft: Radius.circular(24)),
              border: Border.all(color: AppColors.border),
              boxShadow: const [BoxShadow(color: Color(0x0D172033), blurRadius: 18, offset: Offset(0, 8))],
            ),
            child: Text(text, style: const TextStyle(fontSize: 13.5, height: 1.65, fontWeight: FontWeight.w600)),
          ),
        ),
      ]);
}

class FeatureTile extends StatelessWidget {
  const FeatureTile({required this.icon, required this.title, required this.subtitle, required this.onTap, this.color = AppColors.softBlue, super.key});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final Color color;

  @override
  Widget build(BuildContext context) => AppCard(
        onTap: onTap,
        padding: const EdgeInsets.all(16),
        child: Row(children: [
          Container(width: 50, height: 50, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(17)), child: Icon(icon, color: AppColors.blue)),
          const SizedBox(width: 13),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.ink)), const SizedBox(height: 3), Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.muted))])),
          const Icon(Icons.chevron_left_rounded, color: AppColors.muted),
        ]),
      );
}

class AudioPlayButton extends StatefulWidget {
  const AudioPlayButton({required this.text, this.tooltip = 'پخش صدا', super.key});
  final String text;
  final String tooltip;
  @override
  State<AudioPlayButton> createState() => _AudioPlayButtonState();
}

class _AudioPlayButtonState extends State<AudioPlayButton> {
  final TtsService _tts = TtsService();
  bool _playing = false;

  Future<void> _toggle() async {
    if (_playing) {
      await _tts.stop();
      if (mounted) setState(() => _playing = false);
      return;
    }
    setState(() => _playing = true);
    try {
      await _tts.speak(widget.text);
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('پخش صدا روی این دستگاه در دسترس نیست.')));
    }
    if (mounted) setState(() => _playing = false);
  }

  @override
  void dispose() { _tts.stop(); super.dispose(); }

  @override
  Widget build(BuildContext context) => IconButton(
        tooltip: widget.tooltip,
        onPressed: _toggle,
        style: IconButton.styleFrom(backgroundColor: AppColors.softBlue),
        icon: Icon(_playing ? Icons.stop_rounded : Icons.volume_up_rounded, color: AppColors.blue),
      );
}
