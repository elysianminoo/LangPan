import 'package:flutter/material.dart';

import 'panda.dart';
import 'theme.dart';
import 'tts_service.dart';

void showComingSoon(BuildContext context) {
  final messenger = ScaffoldMessenger.of(context);
  messenger.hideCurrentSnackBar();
  messenger.showSnackBar(
    const SnackBar(content: Text('این بخش در نسخه‌های بعدی فعال می‌شود.')),
  );
}

class AppCard extends StatelessWidget {
  const AppCard({
    required this.child,
    this.padding = const EdgeInsets.all(20),
    this.onTap,
    this.depth = true,
    this.highlight = true,
    super.key,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final bool depth;
  final bool highlight;

  @override
  Widget build(BuildContext context) {
    final content = Padding(padding: padding, child: child);
    final radius = BorderRadius.circular(24);
    // The decoration (and its shadow) lives on an outer box; the Material
    // inside only clips the tap ripple, so the shadow is never cut off.
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: highlight
            ? const LinearGradient(
                colors: [Colors.white, Color(0xFFFAFBFF)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              )
            : null,
        color: highlight ? null : Colors.white,
        borderRadius: radius,
        border: Border.all(color: AppColors.border),
        boxShadow: depth
            ? const [
                BoxShadow(
                  color: Color(0x12172033),
                  blurRadius: 18,
                  offset: Offset(0, 9),
                ),
              ]
            : null,
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: radius,
        clipBehavior: Clip.antiAlias,
        child: onTap == null
            ? content
            : InkWell(onTap: onTap, child: content),
      ),
    );
  }
}

class BrandLogo extends StatelessWidget {
  const BrandLogo({this.compact = false, super.key});

  final bool compact;

  @override
  Widget build(BuildContext context) {
    final pandaSize = compact ? 42.0 : 56.0;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: pandaSize,
          height: pandaSize,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(compact ? 14 : 18),
            gradient: const LinearGradient(
              colors: [AppColors.blue, AppColors.indigo],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: const [
              BoxShadow(
                color: Color(0x263B6FFF),
                blurRadius: 16,
                offset: Offset(0, 7),
              ),
            ],
          ),
          child: FittedBox(
            fit: BoxFit.contain,
            child: SizedBox(
              width: 108,
              height: 126,
              child: PandaCompanion(
                compact: true,
                showBackpack: false,
                mood: PandaMood.happy,
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Text(
          'LangPan',
          style: TextStyle(
            fontSize: compact ? 20 : 27,
            fontWeight: FontWeight.w900,
            letterSpacing: -.8,
            color: AppColors.ink,
          ),
        ),
      ],
    );
  }
}

class GradientCard extends StatelessWidget {
  const GradientCard({required this.child, this.onTap, super.key});

  final Widget child;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(28),
        child: Ink(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [AppColors.blue, AppColors.indigo],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(28),
            boxShadow: const [
              BoxShadow(
                color: Color(0x263B63E8),
                blurRadius: 26,
                offset: Offset(0, 12),
              ),
            ],
          ),
          child: child,
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle({
    required this.title,
    this.subtitle,
    this.action,
    this.onTap,
    super.key,
  });

  final String title;
  final String? subtitle;
  final String? action;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final subtitleText = subtitle;
    final actionText = action;
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w900,
                  color: AppColors.ink,
                ),
              ),
              if (subtitleText != null) ...[
                const SizedBox(height: 4),
                Text(
                  subtitleText,
                  style: const TextStyle(color: AppColors.muted, fontSize: 12),
                ),
              ],
            ],
          ),
        ),
        if (actionText != null)
          TextButton(onPressed: onTap, child: Text(actionText)),
      ],
    );
  }
}

class Pill extends StatelessWidget {
  const Pill(
    this.text, {
    this.icon,
    this.color = AppColors.softBlue,
    this.foreground = AppColors.ink,
    super.key,
  });

  final String text;
  final IconData? icon;
  final Color color;
  final Color foreground;

  @override
  Widget build(BuildContext context) {
    final iconData = icon;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(99),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (iconData != null) ...[
            Icon(iconData, size: 15, color: foreground),
            const SizedBox(width: 5),
          ],
          Text(
            text,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: foreground,
            ),
          ),
        ],
      ),
    );
  }
}

class PandaSpeechBubble extends StatelessWidget {
  const PandaSpeechBubble({
    required this.text,
    this.mood = PandaMood.happy,
    super.key,
  });

  final String text;
  final String mood;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        PandaCompanion(compact: true, mood: mood),
        Expanded(
          child: Container(
            margin: const EdgeInsets.only(bottom: 18),
            padding: const EdgeInsets.all(17),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: AppColors.border),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x0D172033),
                  blurRadius: 20,
                  offset: Offset(0, 8),
                ),
              ],
            ),
            child: Text(
              text,
              style: const TextStyle(
                fontSize: 14,
                height: 1.65,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class FeatureTile extends StatelessWidget {
  const FeatureTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.color = AppColors.softBlue,
    super.key,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      onTap: onTap,
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(icon, color: AppColors.blue),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.w900,
                    color: AppColors.ink,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  subtitle,
                  style: const TextStyle(fontSize: 12, color: AppColors.muted),
                ),
              ],
            ),
          ),
          const Icon(Icons.chevron_left_rounded, color: AppColors.muted),
        ],
      ),
    );
  }
}

class ErrorView extends StatelessWidget {
  const ErrorView({required this.message, required this.onRetry, super.key});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline_rounded, size: 52, color: AppColors.error),
            const SizedBox(height: 12),
            const Text(
              'خطا در بارگذاری دوره',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 8),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 14),
            FilledButton(onPressed: onRetry, child: const Text('تلاش دوباره')),
          ],
        ),
      ),
    );
  }
}

class AudioPlayButton extends StatefulWidget {
  const AudioPlayButton({required this.text, this.tooltip = 'پخش صدا', super.key});

  final String text;
  final String tooltip;

  @override
  State<AudioPlayButton> createState() => _AudioPlayButtonState();
}

class _AudioPlayButtonState extends State<AudioPlayButton> {
  final TtsService _tts = TtsService();
  bool _playing = false;

  Future<void> _toggle() async {
    if (_playing) {
      await _tts.stop();
      if (mounted) {
        setState(() => _playing = false);
      }
      return;
    }
    final messenger = ScaffoldMessenger.of(context);
    setState(() => _playing = true);
    try {
      await _tts.speak(widget.text);
    } catch (_) {
      messenger.showSnackBar(
        const SnackBar(content: Text('پخش صدا روی این دستگاه در دسترس نیست.')),
      );
    }
    if (mounted) {
      setState(() => _playing = false);
    }
  }

  @override
  void dispose() {
    _tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return IconButton(
      tooltip: widget.tooltip,
      onPressed: _toggle,
      icon: AnimatedSwitcher(
        duration: const Duration(milliseconds: 180),
        child: Icon(
          _playing ? Icons.stop_circle_rounded : Icons.volume_up_rounded,
          key: ValueKey(_playing),
          color: AppColors.blue,
        ),
      ),
    );
  }
}
