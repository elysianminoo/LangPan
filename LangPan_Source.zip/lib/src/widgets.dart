import 'package:flutter/material.dart';

import 'theme.dart';

void showComingSoon(BuildContext context) {
  final messenger = ScaffoldMessenger.of(context);
  messenger.hideCurrentSnackBar();
  messenger.showSnackBar(
    const SnackBar(content: Text('این بخش در نسخه‌های بعدی فعال می‌شود.')),
  );
}

class AppCard extends StatelessWidget {
  const AppCard({
    required this.child,
    this.padding = const EdgeInsets.all(20),
    this.onTap,
    super.key,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final content = Padding(padding: padding, child: child);
    return Card(
      child: onTap == null ? content : InkWell(onTap: onTap, child: content),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle({
    required this.title,
    this.action,
    this.onTap,
    super.key,
  });

  final String title;
  final String? action;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final actionLabel = action;
    return Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: AppColors.ink,
            ),
          ),
        ),
        if (actionLabel != null)
          TextButton(onPressed: onTap, child: Text(actionLabel)),
      ],
    );
  }
}

class ErrorView extends StatelessWidget {
  const ErrorView({required this.message, required this.onRetry, super.key});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 56, color: Colors.red),
            const SizedBox(height: 12),
            const Text(
              'خطا در بارگذاری محتوا',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 8),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton(onPressed: onRetry, child: const Text('تلاش دوباره')),
          ],
        ),
      ),
    );
  }
}

class EmptyFeature extends StatelessWidget {
  const EmptyFeature({
    required this.icon,
    required this.title,
    required this.text,
    super.key,
  });

  final IconData icon;
  final String title;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 64, color: AppColors.blue),
            const SizedBox(height: 16),
            Text(
              title,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 8),
            Text(
              text,
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.muted),
            ),
          ],
        ),
      ),
    );
  }
}

class LangPanMark extends StatelessWidget {
  const LangPanMark({required this.size, super.key});

  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: AppColors.blue,
        borderRadius: BorderRadius.circular(size * .28),
      ),
      alignment: Alignment.center,
      child: Text(
        'LP',
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w900,
          fontSize: size * .32,
        ),
      ),
    );
  }
}

class PandaAvatar extends StatelessWidget {
  const PandaAvatar({required this.size, super.key});

  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: const CustomPaint(painter: _PandaPainter()),
    );
  }
}

class _PandaPainter extends CustomPainter {
  const _PandaPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final c = Offset(w / 2, h / 2);
    final paint = Paint()..isAntiAlias = true;

    // Ears.
    paint.color = Colors.black;
    canvas.drawCircle(c.translate(-w * .28, -h * .28), w * .18, paint);
    canvas.drawCircle(c.translate(w * .28, -h * .28), w * .18, paint);

    // Face.
    paint.color = Colors.white;
    canvas.drawCircle(c, w * .42, paint);

    // Eye patches.
    paint.color = Colors.black;
    canvas.drawOval(
      Rect.fromCenter(
        center: c.translate(-w * .15, -h * .06),
        width: w * .16,
        height: h * .25,
      ),
      paint,
    );
    canvas.drawOval(
      Rect.fromCenter(
        center: c.translate(w * .15, -h * .06),
        width: w * .16,
        height: h * .25,
      ),
      paint,
    );

    // Eye highlights.
    paint.color = Colors.white;
    canvas.drawCircle(c.translate(-w * .13, -h * .08), w * .045, paint);
    canvas.drawCircle(c.translate(w * .17, -h * .08), w * .045, paint);

    // Nose.
    paint.color = Colors.black;
    canvas.drawOval(
      Rect.fromCenter(
        center: c.translate(0, h * .12),
        width: w * .16,
        height: h * .1,
      ),
      paint,
    );

    // Scarf.
    paint.color = AppColors.blue;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(
          center: Offset(c.dx, c.dy + h * .38),
          width: w * .62,
          height: h * .22,
        ),
        Radius.circular(w * .12),
      ),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
