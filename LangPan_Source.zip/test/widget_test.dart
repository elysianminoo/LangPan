import 'package:flutter_test/flutter_test.dart';
import 'package:langpan/main.dart';

void main() {
  testWidgets('LangPan test mode renders', (tester) async {
    await tester.pumpWidget(const LangPanApp());
    expect(find.text('LangPan • Test Mode'), findsOneWidget);
  });
}
