import 'package:flutter_test/flutter_test.dart';
import 'package:langpan/main.dart';

void main() {
  testWidgets('LangPan opens the real learning home', (tester) async {
    await tester.pumpWidget(const LangPanApp());
    await tester.pumpAndSettle();
    expect(find.text('LangPan'), findsWidgets);
    expect(find.text('ادامه مسیر'), findsOneWidget);
    expect(find.text('A1 • Hello!'), findsOneWidget);
  });
}
