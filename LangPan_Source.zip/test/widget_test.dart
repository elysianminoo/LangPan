import 'dart:io';
import 'dart:ui' show Size;

import 'package:flutter_test/flutter_test.dart';
import 'package:langpan/main.dart';
import 'package:langpan/src/content_repository.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('LangPan opens the redesigned learning home', (tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 2.0;
    addTearDown(tester.view.reset);

    await tester.pumpWidget(const LangPanApp());
    // The Panda animation repeats forever, so pumpAndSettle would never finish.
    await tester.pump(const Duration(milliseconds: 100));

    expect(find.text('سلام دوست من 👋'), findsOneWidget);
    expect(find.text('Hello!'), findsOneWidget);
    expect(find.text('شروع درس'), findsOneWidget);
  });

  test('curriculum and authored A1 lessons parse from content files', () async {
    // Reads files directly from disk (tests run from the project root), so the
    // test does not depend on the asset bundle.
    final repository = ContentRepository(
      loadString: (path) => File(path).readAsString(),
    );

    final curriculum = await repository.loadCurriculum();
    expect(asList(curriculum['levels']), hasLength(7));

    final lessons = await repository.loadLessons(
      chapterId: 'a1.c1',
      lessonCount: 12,
    );
    expect(lessons, hasLength(12));
    expect(lessons.first['id'], 'a1.c1.l1');
  });

  test('lesson asset path is derived from chapter id', () {
    const repository = ContentRepository();
    expect(
      repository.lessonAssetPath('a1.c1', 3),
      'content/en/a1/chapter_01/lesson_l3.json',
    );
    expect(
      () => repository.lessonAssetPath('broken', 1),
      throwsFormatException,
    );
  });
}
