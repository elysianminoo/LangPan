import 'package:flutter_test/flutter_test.dart';
import 'package:langpan/main.dart';
import 'package:langpan/src/content_repository.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('LangPan opens the home screen', (tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.reset);

    await tester.pumpWidget(const LangPanApp());
    await tester.pump();

    expect(find.text('LangPan'), findsWidgets);
    expect(find.text('ادامه مسیر'), findsOneWidget);
    expect(find.text('A1 • Hello!'), findsOneWidget);
  });

  test('curriculum and authored A1 lessons load from assets', () async {
    const repository = ContentRepository();

    final curriculum = await repository.loadCurriculum();
    expect(asList(curriculum['levels']), hasLength(7));

    final lessons = await repository.loadLessons(
      chapterId: 'a1.c1',
      lessonCount: 12,
    );
    expect(lessons, hasLength(12));
    expect(lessons.first['id'], 'a1.c1.l1');
  });

  test('lesson asset path is derived from chapter id', () {
    const repository = ContentRepository();
    expect(
      repository.lessonAssetPath('a1.c1', 3),
      'content/en/a1/chapter_01/lesson_l3.json',
    );
    expect(
      () => repository.lessonAssetPath('broken', 1),
      throwsFormatException,
    );
  });
}
