import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:langpan/src/content_repository.dart';
import 'package:langpan/src/onboarding.dart';
import 'package:langpan/src/profile_store.dart';
import 'package:langpan/src/speech_service.dart';
import 'package:langpan/src/theme.dart';

void main() {
  testWidgets('Onboarding shows first page and advances', (tester) async {
    var finished = false;

    await tester.pumpWidget(
      MaterialApp(
        theme: buildAppTheme(),
        home: Directionality(
          textDirection: TextDirection.rtl,
          child: OnboardingFlow(
            onFinished: (profile) async {
              finished = true;
              expect(profile.onboardingComplete, isTrue);
            },
          ),
        ),
      ),
    );

    // Panda animation is continuous — never use pumpAndSettle.
    await tester.pump(const Duration(milliseconds: 50));

    expect(find.text('سلام به LangPan'), findsOneWidget);
    expect(find.text('بعدی'), findsOneWidget);

    await tester.tap(find.text('بعدی'));
    await tester.pump(const Duration(milliseconds: 400));
    await tester.pump(const Duration(milliseconds: 50));

    expect(find.text('یادگیری مرحله‌به‌مرحله'), findsOneWidget);
    expect(finished, isFalse);
  });

  test('curriculum and authored A1 lessons parse from content files', () async {
    final repository = ContentRepository(
      loadString: (path) => File(path).readAsString(),
    );

    final curriculum = await repository.loadCurriculum();
    expect(asList(curriculum['levels']), hasLength(7));

    final lessons = await repository.loadLessons(
      chapterId: 'a1.c1',
      lessonCount: 12,
    );
    expect(lessons, hasLength(12));
    expect(lessons.first['id'], 'a1.c1.l1');
  });

  test('lesson asset path is derived from chapter id', () {
    const repository = ContentRepository();
    expect(
      repository.lessonAssetPath('a1.c1', 3),
      'content/en/a1/chapter_01/lesson_l3.json',
    );
    expect(
      () => repository.lessonAssetPath('broken', 1),
      throwsFormatException,
    );
  });

  test('personalised content keeps String-keyed maps readable by asMap', () {
    final lesson = <String, dynamic>{
      'speaking': <String, dynamic>{
        'prompt': 'Say: My name is Alex.',
        'accepted_variants': <String>['I am Alex.'],
      },
    };

    final personalized = asMap(personalizeContent(lesson, 'Sara'));
    final speaking = asMap(personalized['speaking']);

    expect(speaking['prompt'], 'Say: My name is Sara.');
    expect(asList(speaking['accepted_variants']), ['I am Sara.']);
    expect(asMap(lesson['speaking'])['prompt'], 'Say: My name is Alex.');
  });

  test('non-Latin learner names keep the authored English example name', () {
    expect(exampleName('علی'), isIn(['Alex', 'Sara', 'Amir', 'Mina', 'David', 'Anna']));
    expect(exampleName('دوست من'), 'Alex');
    expect(exampleName('Sara'), 'Sara');
  });

  test('speech scoring expands contractions and keeps normal words intact', () {
    expect(speechTokens("What's the time?"), ['what', 'is', 'the', 'time']);
    expect(textSimilarity("I'm Alex", 'I am Alex.'), 1.0);
    expect(textSimilarity('hello', 'My name is Alex'), lessThan(.5));
    expect(textSimilarity('', 'My name is Alex'), 0.0);
  });

  test('default learner profile starts with onboarding incomplete', () {
    const profile = LearnerProfile();
    expect(profile.onboardingComplete, isFalse);
    expect(profile.name, 'دوست من');
    expect(profile.copyWith(onboardingComplete: true).onboardingComplete, isTrue);
  });
}
