import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LESSONS = ROOT / 'content' / 'en' / 'a1' / 'chapter_01'
REQUIRED = [
    'id','version','cefr','title','can_do','scenario','communicative_goal',
    'vocabulary','grammar','listening','pronunciation','speaking','reading',
    'writing','panda_conversation','retrieval','assessment','mastery','recovery','review'
]
import re
files = sorted(LESSONS.glob('lesson_*.json'), key=lambda p: int(re.search(r'(\d+)$', p.stem).group(1)))
assert len(files) == 12, f'Expected 12 A1 Chapter 1 lessons, found {len(files)}'
ids = set()
for path in files:
    data = json.loads(path.read_text(encoding='utf-8'))
    missing = [key for key in REQUIRED if key not in data or data[key] in (None, '', [], {})]
    assert not missing, f'{path}: missing {missing}'
    assert data['cefr'] == 'A1', f'{path}: CEFR must be A1'
    assert data['id'] not in ids, f'Duplicate lesson id: {data["id"]}'
    ids.add(data['id'])
print(f'Content validation passed: {len(files)} authored lessons.')
