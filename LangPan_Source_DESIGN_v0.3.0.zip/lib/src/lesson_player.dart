import 'package:flutter/material.dart';
import 'content_repository.dart';
import 'panda.dart';
import 'theme.dart';
import 'widgets.dart';

class LessonPlayer extends StatefulWidget {
  const LessonPlayer({required this.lesson, super.key});
  final Map<String, dynamic> lesson;
  @override State<LessonPlayer> createState() => _LessonPlayerState();
}

class _LessonPlayerState extends State<LessonPlayer> {
  int _step = 0;
  final PageController _controller = PageController();
  bool _revealed = false;
  String? _choice;

  List<_LessonStep> get _steps {
    final l = widget.lesson;
    return [
      _LessonStep('شروع از یک موقعیت واقعی', Icons.explore_rounded, _ContextStep(lesson: l)),
      _LessonStep('کلمات را در جمله یاد بگیر', Icons.auto_stories_rounded, _VocabularyStep(words: asList(l['vocabulary']))),
      _LessonStep('گرامر را بفهم، نه حفظ کن', Icons.psychology_alt_rounded, _GrammarStep(grammar: asMap(l['grammar']))),
      _LessonStep('شنیدن قبل از حدس زدن', Icons.headphones_rounded, _ListeningStep(data: asMap(l['listening']), revealed: _revealed, onReveal: () => setState(() => _revealed = true))),
      _LessonStep('حالا خودت تولید کن', Icons.record_voice_over_rounded, _SpeakingStep(data: asMap(l['speaking']))),
      _LessonStep('مکالمه با پاندا', Icons.forum_rounded, _ConversationStep(data: asMap(l['panda_conversation']))),
      _LessonStep('بازیابی بدون کمک', Icons.bolt_rounded, _RetrievalStep(items: asList(l['retrieval']), choice: _choice, onChoice: (v) => setState(() => _choice = v))),
      _LessonStep('بررسی یادگیری', Icons.verified_rounded, _AssessmentStep(data: asMap(l['assessment']))),
    ];
  }

  void _next() {
    if (_step < _steps.length - 1) { setState(() { _step++; _revealed = false; _choice = null; }); _controller.animateToPage(_step, duration: const Duration(milliseconds: 300), curve: Curves.easeOutCubic); return; }
    showDialog<void>(context: context, builder: (ctx) => AlertDialog(title: const Text('درس کامل شد 🎉'), content: const Text('این فقط پایان یک صفحه نیست؛ شواهد یادگیری تو حالا وارد چرخه مرور می‌شود.'), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('باشه'))])).then((_) { if (mounted) Navigator.pop(context); });
  }

  @override
  void dispose() { _controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final steps = _steps;
    final current = steps[_step];
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(leading: IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded)), title: Text('درس ${_step + 1} از ${steps.length}', style: const TextStyle(fontWeight: FontWeight.w800)), actions: [Pill(asText(widget.lesson['cefr'], 'A1')), const SizedBox(width: 12)]),
      body: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(20, 4, 20, 14), child: Row(children: [Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: (_step + 1) / steps.length, minHeight: 8))), const SizedBox(width: 12), Text('${((_step + 1) / steps.length * 100).round()}%', style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.muted))])),
        Expanded(child: PageView.builder(controller: _controller, physics: const NeverScrollableScrollPhysics(), itemCount: steps.length, itemBuilder: (_, i) { final s = steps[i]; return ListView(padding: const EdgeInsets.fromLTRB(20, 0, 20, 24), children: [Text(s.title, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900, color: AppColors.ink)), const SizedBox(height: 5), Text(_stepHint(i), style: const TextStyle(color: AppColors.muted, height: 1.45)), const SizedBox(height: 18), s.body]); })),
        Container(padding: const EdgeInsets.fromLTRB(20, 10, 20, 18), decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: AppColors.border))), child: Row(children: [if (_step > 0) OutlinedButton(onPressed: () { setState(() => _step--); _controller.animateToPage(_step, duration: const Duration(milliseconds: 280), curve: Curves.easeOut); }, child: const Text('قبلی')), if (_step > 0) const SizedBox(width: 10), Expanded(child: SizedBox(height: 52, child: FilledButton(onPressed: _next, child: Text(_step == steps.length - 1 ? 'ثبت یادگیری' : 'ادامه'))))]))
      ]),
    );
  }

  String _stepHint(int i) => const ['اول معنی را در موقعیت ببین.', 'کلمه را با مثال و کاربردش نگه دار.', 'اول مفهوم؛ بعد شکل جمله.', 'گوش بده و از صدا معنی را استخراج کن.', 'دانسته را به تولید واقعی تبدیل کن.', 'پاندا نقش شریک مکالمه را دارد.', 'بدون نگاه کردن اطلاعات را از حافظه بیرون بکش.', 'حالا ببینیم واقعاً چه چیزی یاد گرفته‌ای.'][i];
}

class _LessonStep { const _LessonStep(this.title, this.icon, this.body); final String title; final IconData icon; final Widget body; }

class _ContextStep extends StatelessWidget {
  const _ContextStep({required this.lesson}); final Map<String, dynamic> lesson;
  @override Widget build(BuildContext context) => Column(children: [
    GradientCard(child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Pill('REAL-LIFE SCENE', icon: Icons.place_rounded, color: Color(0x33FFFFFF)), const SizedBox(height: 15), Text(asText(lesson['scenario'], 'Meeting someone new'), style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900)), const SizedBox(height: 8), Text(asText(lesson['communicative_goal']), style: const TextStyle(color: Colors.white70, height: 1.5)), const SizedBox(height: 12), const Text('هدف: بعد از این درس باید بتوانی همین کار را در یک موقعیت واقعی انجام بدهی.', style: TextStyle(color: Colors.white, height: 1.5))])),
    const SizedBox(height: 14), const PandaSpeechBubble(text: 'اول فقط گوش کن و موقعیت را تصور کن. لازم نیست هنوز چیزی را حفظ کنی؛ قرار است معنی را از دل موقعیت بفهمیم.'),
    const SizedBox(height: 10),
    AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Can-Do', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
      const SizedBox(height: 10),
      for (final item in asList(lesson['can_do']))
        Padding(padding: const EdgeInsets.only(bottom: 8), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [const Icon(Icons.check_circle_rounded, color: AppColors.mint, size: 20), const SizedBox(width: 8), Expanded(child: Text('$item', style: const TextStyle(height: 1.4))) ])),
    ])),
  ]);
}

class _VocabularyStep extends StatefulWidget { const _VocabularyStep({required this.words}); final List<dynamic> words; @override State<_VocabularyStep> createState() => _VocabularyStepState(); }
class _VocabularyStepState extends State<_VocabularyStep> {
  int index = 0; bool show = false;
  @override Widget build(BuildContext context) { final words = widget.words; if (words.isEmpty) return const Text('واژگان این درس هنوز ثبت نشده است.'); final w = asMap(words[index % words.length]); return Column(children: [
    AppCard(padding: const EdgeInsets.all(22), child: Column(children: [Row(children: [Pill('واژه ${index + 1}/${words.length}', icon: Icons.translate_rounded), const Spacer(), IconButton(onPressed: () {}, icon: const Icon(Icons.volume_up_rounded))]), const SizedBox(height: 25), Text(asText(w['word']), style: const TextStyle(fontSize: 35, fontWeight: FontWeight.w900, color: AppColors.ink)), const SizedBox(height: 12), AnimatedCrossFade(firstChild: const Text('اول خودت حدس بزن…', style: TextStyle(color: AppColors.muted)), secondChild: Column(children: [Text(asText(w['meaning']), style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800)), const SizedBox(height: 10), Text(asText(w['example']), textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, height: 1.5))]), crossFadeState: show ? CrossFadeState.showSecond : CrossFadeState.showFirst, duration: const Duration(milliseconds: 220)), const SizedBox(height: 22), FilledButton.tonal(onPressed: () => setState(() => show = !show), child: Text(show ? 'پنهان کن' : 'معنی و مثال را ببین'))])),
    const SizedBox(height: 12), Row(children: [Expanded(child: OutlinedButton(onPressed: index == 0 ? null : () => setState(() { index--; show = false; }), child: const Text('قبلی'))), const SizedBox(width: 10), Expanded(child: FilledButton(onPressed: () => setState(() { index = (index + 1) % words.length; show = false; }), child: const Text('واژه بعدی')))]),
    const SizedBox(height: 16), const PandaSpeechBubble(text: 'واژه را تنها حفظ نکن. جمله‌ای که کنارش دیدی همان چیزی است که بعداً در مکالمه می‌خواهیم از حافظه‌ات بیرون بکشیم.'),
  ]); }
}

class _GrammarStep extends StatelessWidget {
  const _GrammarStep({required this.grammar}); final Map<String, dynamic> grammar;
  @override Widget build(BuildContext context) { final examples = asList(grammar['examples']); final errors = asList(grammar['common_errors']); return Column(children: [
    const PandaSpeechBubble(mood: PandaMood.thinking, text: 'این قسمت را مثل کلاس واقعی می‌بینیم: معنی → شکل → کاربرد. اگر فقط فرمول را حفظ کنی، در مکالمه گیر می‌کنی.'),
    AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Pill(asText(grammar['focus'], 'Grammar')), const SizedBox(height: 16), Text(asText(grammar['explanation']), style: const TextStyle(fontSize: 16, height: 1.7)), const SizedBox(height: 18), const Text('الگوی ساده', style: TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 8), _FormulaRow(label: 'I am', value: 'I’m'), _FormulaRow(label: 'My name is', value: 'My name is + name'), if (examples.isNotEmpty) ...[const SizedBox(height: 16), const Text('مثال در موقعیت', style: TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 8), for (final e in examples) _ExampleLine('$e')], if (errors.isNotEmpty) ...[const SizedBox(height: 16), const Text('حواست به این اشتباه باشد', style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.error)), const SizedBox(height: 7), for (final e in errors) Text('• $e')]])),
    const SizedBox(height: 12), AppCard(child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('چرا؟', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)), SizedBox(height: 7), Text('در انگلیسی «I am» یک واحد دستوری برای معرفی حالت/هویت است. در گفتار روزمره، شکل کوتاه I’m بسیار رایج است؛ اما My name is یک ساختار معرفی نام است.', style: TextStyle(height: 1.65, color: AppColors.muted))])),
  ]); }
}
class _FormulaRow extends StatelessWidget { const _FormulaRow({required this.label, required this.value}); final String label,value; @override Widget build(BuildContext c)=>Padding(padding: const EdgeInsets.only(bottom: 9), child: Row(children:[Expanded(child:Text(label,style:const TextStyle(fontWeight:FontWeight.w700))),const Icon(Icons.arrow_back_rounded,size:17,color:AppColors.muted),const SizedBox(width:8),Text(value,style:const TextStyle(fontWeight:FontWeight.w900,color:AppColors.blue))])); }
class _ExampleLine extends StatelessWidget { const _ExampleLine(this.text); final String text; @override Widget build(BuildContext c)=>Container(width:double.infinity,margin:const EdgeInsets.only(bottom:7),padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:AppColors.softBlue,borderRadius:BorderRadius.circular(14)),child:Text(text,style:const TextStyle(fontWeight:FontWeight.w700))); }

class _ListeningStep extends StatelessWidget { const _ListeningStep({required this.data, required this.revealed, required this.onReveal}); final Map<String,dynamic> data; final bool revealed; final VoidCallback onReveal; @override Widget build(BuildContext c)=>Column(children:[AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Pill('LISTENING LAB',icon:Icons.headphones_rounded,color:AppColors.softPurple),const SizedBox(height:15),const Text('اول گوش بده؛ متن را هنوز نبین.',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:14),Container(width:double.infinity,padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:AppColors.ink,borderRadius:BorderRadius.circular(20)),child:Row(children:[Container(width:50,height:50,decoration:BoxDecoration(color:AppColors.blue,borderRadius:BorderRadius.circular(16)),child:const Icon(Icons.play_arrow_rounded,color:Colors.white,size:28)),const SizedBox(width:12),const Expanded(child:Text('پخش نمونه مکالمه',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w800))),const Icon(Icons.graphic_eq_rounded,color:Colors.white54)])),const SizedBox(height:15),if(revealed)Text(asText(data['script']),style:const TextStyle(height:1.7,fontWeight:FontWeight.w600))else const Text('بعد از یک بار شنیدن، متن را باز کن و دوباره مقایسه کن.',style:TextStyle(color:AppColors.muted)),const SizedBox(height:13),OutlinedButton.icon(onPressed:onReveal,icon:const Icon(Icons.visibility_outlined),label:Text(revealed?'متن باز شد':'نمایش متن'))])),const SizedBox(height:12),const PandaSpeechBubble(mood:PandaMood.listening,text:'اگر یک کلمه را نگرفتی، نگران نباش. اول معنی کلی را بگیر؛ بعد سراغ جزئیات برو.'))); }

class _SpeakingStep extends StatelessWidget { const _SpeakingStep({required this.data}); final Map<String,dynamic> data; @override Widget build(BuildContext c)=>Column(children:[const PandaSpeechBubble(mood:PandaMood.encouraging,text:'حالا نوبت توست. پاسخ را با صدای بلند بگو. در نسخه کامل، موتور گفتار روی معنی، دقت و قابل‌فهم بودن بررسی می‌کند؛ نه فقط شباهت کلمه‌به‌کلمه.'),AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Pill('SPEAKING',icon:Icons.mic_rounded,color:AppColors.softMint),const SizedBox(height:15),Text(asText(data['prompt'],'Introduce yourself to Panda.'),style:const TextStyle(fontSize:19,fontWeight:FontWeight.w900,height:1.45)),const SizedBox(height:16),Container(width:double.infinity,height:150,decoration:BoxDecoration(color:AppColors.background,borderRadius:BorderRadius.circular(20),border:Border.all(color:AppColors.border)),child:const Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(Icons.mic_none_rounded,size:40,color:AppColors.blue),SizedBox(height:8),Text('برای پاسخ دادن نگه دار',style:TextStyle(color:AppColors.muted))])),const SizedBox(height:12),Text('پاسخ‌های طبیعی هم پذیرفته می‌شوند؛ هدف، ارتباط واقعی است.',style:const TextStyle(color:AppColors.muted,height:1.5))]))]); }

class _ConversationStep extends StatelessWidget { const _ConversationStep({required this.data}); final Map<String,dynamic> data; @override Widget build(BuildContext c)=>Column(children:[const PandaSpeechBubble(mood:PandaMood.happy,text:'اینجا تمرین از حالت «سؤال و جواب» خارج می‌شود. من نقش یک آدم واقعی را بازی می‌کنم و پاسخ تو را بر اساس همین درس دنبال می‌کنم.'),AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('شروع مکالمه',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:14),for(final t in asList(data['turns']))Padding(padding:const EdgeInsets.only(bottom:9),child:Text('$t',style:const TextStyle(height:1.5)))])),const SizedBox(height:12),FeatureTile(icon:Icons.forum_rounded,title:'شروع گفت‌وگو',subtitle:'پاندا سؤال اول را می‌پرسد',color:AppColors.softPurple,onTap:(){} )]); }

class _RetrievalStep extends StatelessWidget { const _RetrievalStep({required this.items, required this.choice, required this.onChoice}); final List<dynamic> items; final String? choice; final ValueChanged<String> onChoice; @override Widget build(BuildContext c)=>Column(children:[const PandaSpeechBubble(mood:PandaMood.thinking,text:'حالا کتاب را ببند. اگر بتوانی بدون دیدن پاسخ را تولید کنی، یادگیری از «آشنایی» به «بازیابی» نزدیک شده است.'),AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('چالش بازیابی',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:10),Text(items.isEmpty?'خودت یک جمله با عبارت هدف بساز.':'${items.first}',style:const TextStyle(height:1.6)),const SizedBox(height:16),_Choice(text:'I am Masoud.',value:'correct',selected:choice,onTap:onChoice),_Choice(text:'I Masoud am.',value:'wrong',selected:choice,onTap:onChoice)])),if(choice!=null)Padding(padding:const EdgeInsets.only(top:10),child:AppCard(child:Text(choice=='correct'?'آفرین. ترتیب جمله طبیعی است و معنی روشن می‌ماند.':'تقریباً؛ در این ساختار فعل am باید بعد از فاعل بیاید.',style:const TextStyle(height:1.6,fontWeight:FontWeight.w700))))]); }
class _Choice extends StatelessWidget { const _Choice({required this.text,required this.value,required this.selected,required this.onTap}); final String text,value; final String? selected; final ValueChanged<String> onTap; @override Widget build(BuildContext c){final active=selected==value;return Padding(padding:const EdgeInsets.only(bottom:9),child:InkWell(onTap:()=>onTap(value),borderRadius:BorderRadius.circular(15),child:Container(width:double.infinity,padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:active?AppColors.softBlue:Colors.white,borderRadius:BorderRadius.circular(15),border:Border.all(color:active?AppColors.blue:AppColors.border,width:active?2:1)),child:Row(children:[Icon(active?Icons.check_circle_rounded:Icons.radio_button_unchecked_rounded,color:active?AppColors.blue:AppColors.muted),const SizedBox(width:10),Text(text,style:const TextStyle(fontWeight:FontWeight.w700))])));}}

class _AssessmentStep extends StatelessWidget { const _AssessmentStep({required this.data}); final Map<String,dynamic> data; @override Widget build(BuildContext c)=>Column(children:[GradientCard(child:Padding(padding:const EdgeInsets.all(22),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Icon(Icons.verified_rounded,color:Colors.white,size:34),const SizedBox(height:12),const Text('یادگیری را با شواهد می‌سنجیم',style:TextStyle(color:Colors.white,fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:8),const Text('تمام شدن صفحه به معنی Mastered شدن نیست. عملکرد تو در بازیابی، تولید و مرورهای بعدی معیار اصلی است.',style:TextStyle(color:Colors.white,height:1.55))])),const SizedBox(height:14),AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('معیارهای این درس',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:12),for(final item in asList(data['items']))ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.check_circle_outline_rounded,color:AppColors.green),title:Text(asText(asMap(item)['type'])),subtitle:Text(asText(asMap(item)['pass_rule'])))])),const SizedBox(height:10),const PandaSpeechBubble(mood:PandaMood.proud,text:'اگر هنوز یک بخش ضعیف باشد، به‌جای جلو رفتن کورکورانه، یک Recovery کوتاه برای همان ضعف می‌سازیم.'))]); }
