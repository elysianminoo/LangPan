import 'dart:math' as math;
import 'package:flutter/material.dart';

class PandaMood {
  static const happy = 'happy';
  static const thinking = 'thinking';
  static const listening = 'listening';
  static const proud = 'proud';
  static const excited = 'excited';
  static const encouraging = 'encouraging';
}

class PandaCompanion extends StatefulWidget {
  const PandaCompanion({this.mood = PandaMood.happy, this.compact = false, super.key});
  final String mood;
  final bool compact;

  @override
  State<PandaCompanion> createState() => _PandaCompanionState();
}

class _PandaCompanionState extends State<PandaCompanion> with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 2600),
  )..repeat();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = widget.compact ? 92.0 : 154.0;
    return SizedBox(
      width: size,
      height: size + 18,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) {
          final wave = math.sin(_controller.value * math.pi * 2);
          final bob = wave * (widget.compact ? 1.5 : 3.0);
          return Transform.translate(
            offset: Offset(0, bob),
            child: CustomPaint(
              painter: _PandaPainter(mood: widget.mood, phase: _controller.value),
            ),
          );
        },
      ),
    );
  }
}

class _PandaPainter extends CustomPainter {
  _PandaPainter({required this.mood, required this.phase});
  final String mood;
  final double phase;

  @override
  void paint(Canvas canvas, Size size) {
    final s = size.width / 160;
    canvas.scale(s, s);
    final shadow = Paint()..color = const Color(0x22000000);
    canvas.drawOval(const Rect.fromLTWH(30, 142, 100, 13), shadow);

    final body = Paint()..color = const Color(0xFFFDFDFE);
    final black = Paint()..color = const Color(0xFF1E2430);
    final blue = Paint()..color = const Color(0xFF4B7BFF);
    final blush = Paint()..color = const Color(0xFFFFA7B8).withOpacity(.38);

    canvas.drawCircle(const Offset(80, 96), 47, body);
    canvas.drawOval(const Rect.fromLTWH(47, 76, 66, 73), blue);
    canvas.drawOval(const Rect.fromLTWH(56, 77, 48, 62), body);

    canvas.drawCircle(const Offset(50, 54), 22, black);
    canvas.drawCircle(const Offset(110, 54), 22, black);
    canvas.drawCircle(const Offset(80, 58), 47, body);

    canvas.drawOval(const Rect.fromLTWH(49, 43, 23, 31), black);
    canvas.drawOval(const Rect.fromLTWH(88, 43, 23, 31), black);

    final eyeY = mood == PandaMood.thinking ? 55.0 : 58.0;
    canvas.drawCircle(Offset(63, eyeY), 6, body);
    canvas.drawCircle(Offset(97, eyeY), 6, body);
    canvas.drawCircle(Offset(63 + (mood == PandaMood.thinking ? -1 : 0), eyeY), 2.7, black);
    canvas.drawCircle(Offset(97 + (mood == PandaMood.thinking ? -3 : 0), eyeY), 2.7, black);

    canvas.drawCircle(const Offset(57, 83), 7, blush);
    canvas.drawCircle(const Offset(103, 83), 7, blush);

    final mouth = Paint()
      ..color = black.color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.6
      ..strokeCap = StrokeCap.round;
    final path = Path()..moveTo(72, 76);
    if (mood == PandaMood.thinking) {
      path.quadraticBezierTo(80, 80, 88, 76);
    } else if (mood == PandaMood.encouraging) {
      path.quadraticBezierTo(80, 88, 90, 76);
    } else {
      path.quadraticBezierTo(80, 87, 90, 76);
    }
    canvas.drawPath(path, mouth);

    // Hoodie / scarf details.
    final hood = Paint()..color = const Color(0xFF355EEA);
    canvas.drawArc(const Rect.fromLTWH(39, 89, 82, 68), math.pi, math.pi, false, hood..style = PaintingStyle.stroke..strokeWidth = 7);
    canvas.drawCircle(const Offset(80, 126), 5, Paint()..color = const Color(0xFFBFD0FF));

    // Animated listening ears / waving paw.
    if (mood == PandaMood.excited || mood == PandaMood.encouraging) {
      final handY = 108 + math.sin(phase * math.pi * 2) * 5;
      canvas.drawCircle(Offset(125, handY), 12, body);
      canvas.drawCircle(Offset(125, handY), 12, black..style = PaintingStyle.stroke..strokeWidth = 3);
    } else {
      canvas.drawCircle(const Offset(35, 111), 11, body);
      canvas.drawCircle(const Offset(35, 111), 11, black..style = PaintingStyle.stroke..strokeWidth = 3);
    }
  }

  @override
  bool shouldRepaint(covariant _PandaPainter oldDelegate) => oldDelegate.mood != mood || oldDelegate.phase != phase;
}
