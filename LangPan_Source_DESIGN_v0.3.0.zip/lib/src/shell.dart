import 'package:flutter/material.dart';
import 'content_repository.dart';
import 'lesson_player.dart';
import 'panda.dart';
import 'theme.dart';
import 'widgets.dart';

class LangPanShell extends StatefulWidget {
  const LangPanShell({super.key});
  @override State<LangPanShell> createState() => _LangPanShellState();
}

class _LangPanShellState extends State<LangPanShell> {
  final ContentRepository _repository = const ContentRepository();
  int _index = 0;
  Map<String, dynamic>? _curriculum;
  String? _error;
  @override
  void initState() { super.initState(); _loadCurriculum(); }
  Future<void> _loadCurriculum() async {
    try {
      final value = await _repository.loadCurriculum();
      if (mounted) setState(() { _curriculum = value; _error = null; });
    } catch (e) { if (mounted) setState(() => _error = '$e'); }
  }
  void _openLearn() => setState(() => _index = 1);
  void _openLesson(Map<String, dynamic> lesson) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => LessonPlayer(lesson: lesson)));

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onLearn: _openLearn, onLesson: _curriculum == null ? null : () => _openFirstLesson()),
      LearnPage(curriculum: _curriculum, error: _error, onRetry: _loadCurriculum, onLesson: _openLesson),
      const ReviewPage(),
      const ProgressPage(),
      const ProfilePage(),
    ];
    return Scaffold(
      body: SafeArea(child: pages[_index]),
      bottomNavigationBar: NavigationBar(
        height: 74,
        backgroundColor: Colors.white,
        indicatorColor: AppColors.softBlue,
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book_rounded), label: 'یادگیری'),
          NavigationDestination(icon: Icon(Icons.refresh_rounded), selectedIcon: Icon(Icons.refresh_rounded), label: 'مرور'),
          NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights_rounded), label: 'پیشرفت'),
          NavigationDestination(icon: Icon(Icons.person_outline_rounded), selectedIcon: Icon(Icons.person_rounded), label: 'پروفایل'),
        ],
      ),
    );
  }

  Future<void> _openFirstLesson() async {
    final lessons = await _repository.loadLessons(chapterId: 'a1.c1', lessonCount: 12);
    if (!mounted) return;
    _openLesson(lessons.first);
  }
}

class HomePage extends StatelessWidget {
  const HomePage({required this.onLearn, this.onLesson, super.key});
  final VoidCallback onLearn;
  final VoidCallback? onLesson;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(20, 18, 20, 28), children: [
    Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [Text('سلام مسعود 👋', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: AppColors.ink)), SizedBox(height: 5), Text('امروز یک قدم کوچک، فردا یک مکالمه واقعی.', style: TextStyle(color: AppColors.muted))])),
      Container(width: 44, height: 44, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(15), border: Border.all(color: AppColors.border)), child: const Icon(Icons.notifications_none_rounded)),
    ]),
    const SizedBox(height: 20),
    GradientCard(onTap: onLesson, child: SizedBox(height: 205, child: Stack(children: [
      const Positioned(right: 12, bottom: 0, child: PandaCompanion(mood: PandaMood.excited)),
      Padding(padding: const EdgeInsets.fromLTRB(22, 22, 155, 18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Pill('مسیر امروز', icon: Icons.auto_awesome_rounded, color: Color(0x33FFFFFF)),
        const SizedBox(height: 15),
        const Text('Hello!', style: TextStyle(fontSize: 31, color: Colors.white, fontWeight: FontWeight.w900)),
        const SizedBox(height: 7),
        const Text('سلام کردن، معرفی خودت و یک مکالمه کوتاه با پاندا.', style: TextStyle(color: Colors.white, height: 1.45)),
        const Spacer(),
        FilledButton.tonal(onPressed: onLesson ?? onLearn, child: const Text('شروع درس')),
      ])),
    ])),
    const SizedBox(height: 24),
    const SectionTitle(title: 'وضعیت امروز', subtitle: 'کم اما پیوسته؛ همین چیزی است که زبان را می‌سازد.'),
    const SizedBox(height: 12),
    Row(children: const [
      Expanded(child: _MetricCard(icon: Icons.local_fire_department_rounded, value: '4', label: 'روز پیوسته', color: AppColors.softPurple)),
      SizedBox(width: 10),
      Expanded(child: _MetricCard(icon: Icons.bolt_rounded, value: '120', label: 'XP امروز', color: AppColors.softBlue)),
      SizedBox(width: 10),
      Expanded(child: _MetricCard(icon: Icons.replay_rounded, value: '8', label: 'مرور امروز', color: AppColors.softMint)),
    ]),
    const SizedBox(height: 24),
    const SectionTitle(title: 'یادگیری هوشمند', subtitle: 'LangPan بر اساس عملکردت قدم بعدی را پیشنهاد می‌کند.'),
    const SizedBox(height: 12),
    FeatureTile(icon: Icons.psychology_alt_rounded, title: 'مرور هدفمند', subtitle: 'عبارت‌هایی که احتمال فراموشی‌شان بیشتر است', onTap: () {}),
    const SizedBox(height: 10),
    FeatureTile(icon: Icons.record_voice_over_rounded, title: 'تمرین صحبت کردن', subtitle: 'با پاندا جواب بده؛ فقط حفظ کردن کافی نیست', color: AppColors.softMint, onTap: onLearn),
  ]);
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({required this.icon, required this.value, required this.label, required this.color});
  final IconData icon; final String value; final String label; final Color color;
  @override Widget build(BuildContext context) => AppCard(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Container(width: 36, height: 36, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(12)), child: Icon(icon, size: 20, color: AppColors.ink)), const SizedBox(height: 10), Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)), Text(label, style: const TextStyle(fontSize: 11, color: AppColors.muted))]);
}

class LearnPage extends StatelessWidget {
  const LearnPage({required this.curriculum, required this.error, required this.onRetry, required this.onLesson, super.key});
  final Map<String, dynamic>? curriculum; final String? error; final VoidCallback onRetry; final void Function(Map<String, dynamic>) onLesson;
  @override
  Widget build(BuildContext context) {
    if (error != null) return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Text('خطا در بارگذاری دوره'), const SizedBox(height: 10), Text(error!, textAlign: TextAlign.center), const SizedBox(height: 14), FilledButton(onPressed: onRetry, child: const Text('تلاش دوباره'))]));
    final levels = asList(curriculum?['levels']);
    return ListView(padding: const EdgeInsets.fromLTRB(20, 18, 20, 28), children: [
      const Text('مسیر یادگیری', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: AppColors.ink)),
      const SizedBox(height: 6), const Text('از Pre-A1 تا C2؛ هر سطح با هدف و مهارت مشخص.', style: TextStyle(color: AppColors.muted)),
      const SizedBox(height: 18),
      for (final rawLevel in levels) _LevelCard(level: asMap(rawLevel), onLesson: onLesson),
    ]);
  }
}

class _LevelCard extends StatelessWidget {
  const _LevelCard({required this.level, required this.onLesson});
  final Map<String, dynamic> level; final void Function(Map<String, dynamic>) onLesson;
  @override
  Widget build(BuildContext context) {
    final cefr = asText(level['cefr']).toUpperCase().replaceAll('_', '-');
    final chapters = asList(level['chapters']);
    final authored = chapters.where((c) => asText(asMap(c)['status']) == 'authored').length;
    return Padding(padding: const EdgeInsets.only(bottom: 12), child: AppCard(padding: const EdgeInsets.all(16), child: Column(children: [
      Row(children: [Pill(cefr, icon: Icons.flag_rounded), const Spacer(), Text('$authored/${chapters.length} فصل آماده', style: const TextStyle(fontSize: 12, color: AppColors.muted))]),
      const SizedBox(height: 12),
      Align(alignment: AlignmentDirectional.centerStart, child: Text(asText(level['title']), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900))),
      const SizedBox(height: 10),
      for (final rawChapter in chapters.take(3)) _ChapterRow(chapter: asMap(rawChapter), onLesson: onLesson),
      if (chapters.length > 3) Align(alignment: AlignmentDirectional.centerStart, child: TextButton(onPressed: () {}, child: Text('+ ${chapters.length - 3} فصل دیگر'))),
    ])));
  }
}

class _ChapterRow extends StatelessWidget {
  const _ChapterRow({required this.chapter, required this.onLesson});
  final Map<String, dynamic> chapter; final void Function(Map<String, dynamic>) onLesson;
  @override
  Widget build(BuildContext context) {
    final ready = asText(chapter['status']) == 'authored';
    return Padding(padding: const EdgeInsets.only(top: 8), child: Material(color: ready ? AppColors.softBlue : const Color(0xFFF8F9FC), borderRadius: BorderRadius.circular(16), child: InkWell(onTap: ready ? () async {
      final repo = const ContentRepository();
      final count = (chapter['lesson_count'] as num?)?.toInt() ?? 12;
      final lessons = await repo.loadLessons(chapterId: asText(chapter['id']), lessonCount: count);
      if (lessons.isNotEmpty && context.mounted) onLesson(lessons.first);
    } : null, borderRadius: BorderRadius.circular(16), child: Padding(padding: const EdgeInsets.all(13), child: Row(children: [
      Icon(ready ? Icons.play_circle_fill_rounded : Icons.lock_outline_rounded, color: ready ? AppColors.blue : AppColors.muted), const SizedBox(width: 11), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(asText(chapter['title']), style: const TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 2), Text(ready ? 'شروع درس‌ها و تمرین‌ها' : 'در حال آماده‌سازی محتوای کامل', style: const TextStyle(fontSize: 11, color: AppColors.muted))])), const Icon(Icons.chevron_left_rounded, size: 19)]))));
  }
}

class ReviewPage extends StatelessWidget { const ReviewPage({super.key}); @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: const [Text('مرور هوشمند', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)), SizedBox(height: 6), Text('یادگیری را با بازیابی فاصله‌دار ماندگار کن.', style: TextStyle(color: AppColors.muted)), SizedBox(height: 20), PandaSpeechBubble(text: 'امروز ۸ مورد برای مرور داری. اول سراغ چیزهایی برویم که نزدیک فراموش شدن‌اند.', mood: PandaMood.thinking), SizedBox(height: 10), FeatureTile(icon: Icons.schedule_rounded, title: 'مرورهای سررسیدشده', subtitle: '۸ مورد آماده‌اند', onTap: _noop), FeatureTile(icon: Icons.healing_rounded, title: 'بازیابی ضعف‌ها', subtitle: 'تمرین‌های کوتاه برای خطاهای تکراری', onTap: _noop)]); }
void _noop() {}

class ProgressPage extends StatelessWidget { const ProgressPage({super.key}); @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: const [Text('پیشرفت من', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)), SizedBox(height: 16), AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('A1 • Meet & Greet', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)), SizedBox(height: 12), LinearProgressIndicator(value: .28, minHeight: 9), SizedBox(height: 9), Text('۲۸٪ از این فصل؛ تمرکز فعلی: معرفی خود و مکالمه اولیه', style: TextStyle(color: AppColors.muted))])), SizedBox(height: 12), FeatureTile(icon: Icons.record_voice_over_rounded, title: 'Speaking', subtitle: 'در حال تقویت تولید جمله‌های کوتاه', onTap: _noop, color: AppColors.softPurple), FeatureTile(icon: Icons.hearing_rounded, title: 'Listening', subtitle: 'تشخیص عبارت‌های آشنا خوب است؛ سرعت را آرام بالا می‌بریم', onTap: _noop, color: AppColors.softMint)]); }

class ProfilePage extends StatelessWidget { const ProfilePage({super.key}); @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: const [Text('پروفایل', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)), SizedBox(height: 18), AppCard(child: Row(children: [CircleAvatar(radius: 30, backgroundColor: AppColors.softBlue, child: Icon(Icons.person_rounded, color: AppColors.blue, size: 30)), SizedBox(width: 14), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('مسعود', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)), SizedBox(height: 4), Text('English • American English', style: TextStyle(color: AppColors.muted))])])), SizedBox(height: 12), FeatureTile(icon: Icons.volume_up_rounded, title: 'صدا و تلفظ', subtitle: 'انتخاب صدای راوی و تنظیم سرعت پخش', onTap: _noop), FeatureTile(icon: Icons.notifications_active_outlined, title: 'یادآورها', subtitle: 'زمان مطالعه و مرور هوشمند', onTap: _noop), FeatureTile(icon: Icons.privacy_tip_outlined, title: 'حریم خصوصی', subtitle: 'کنترل داده‌های یادگیری و گزارش‌ها', onTap: _noop)]); }
