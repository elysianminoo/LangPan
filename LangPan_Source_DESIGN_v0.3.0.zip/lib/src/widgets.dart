import 'package:flutter/material.dart';
import 'theme.dart';
import 'panda.dart';

class AppCard extends StatelessWidget {
  const AppCard({required this.child, this.padding = const EdgeInsets.all(20), this.onTap, super.key});
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) {
    final content = Padding(padding: padding, child: child);
    return Card(child: onTap == null ? content : InkWell(onTap: onTap, child: content));
  }
}

class GradientCard extends StatelessWidget {
  const GradientCard({required this.child, this.onTap, super.key});
  final Widget child;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(28),
        child: Ink(
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [AppColors.blue, AppColors.indigo], begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.circular(28),
            boxShadow: const [BoxShadow(color: Color(0x263B63E8), blurRadius: 26, offset: Offset(0, 12))],
          ),
          child: child,
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle({required this.title, this.subtitle, this.action, this.onTap, super.key});
  final String title;
  final String? subtitle;
  final String? action;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => Row(children: [
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: AppColors.ink)),
      if (subtitle != null) ...[const SizedBox(height: 4), Text(subtitle!, style: const TextStyle(color: AppColors.muted, fontSize: 12))],
    ])),
    if (action != null) TextButton(onPressed: onTap, child: Text(action!)),
  ]);
}

class Pill extends StatelessWidget {
  const Pill(this.text, {this.icon, this.color = AppColors.softBlue, super.key});
  final String text;
  final IconData? icon;
  final Color color;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
    decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(99)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [if (icon != null) ...[Icon(icon, size: 15), const SizedBox(width: 5)], Text(text, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800))),
  );
}

class PandaSpeechBubble extends StatelessWidget {
  const PandaSpeechBubble({required this.text, this.mood = PandaMood.happy, super.key});
  final String text;
  final String mood;
  @override
  Widget build(BuildContext context) => Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
    const PandaCompanion(compact: true),
    Expanded(child: Container(
      margin: const EdgeInsets.only(bottom: 18),
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), border: Border.all(color: AppColors.border), boxShadow: const [BoxShadow(color: Color(0x0D172033), blurRadius: 20, offset: Offset(0, 8))]),
      child: Text(text, textDirection: TextDirection.rtl, style: const TextStyle(fontSize: 14, height: 1.65, fontWeight: FontWeight.w600)),
    )),
  ]);
}

class FeatureTile extends StatelessWidget {
  const FeatureTile({required this.icon, required this.title, required this.subtitle, required this.onTap, this.color = AppColors.softBlue, super.key});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final Color color;
  @override
  Widget build(BuildContext context) => AppCard(onTap: onTap, padding: const EdgeInsets.all(16), child: Row(children: [
    Container(width: 48, height: 48, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(16)), child: Icon(icon, color: AppColors.blue)),
    const SizedBox(width: 13),
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.ink)), const SizedBox(height: 3), Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.muted))])),
    const Icon(Icons.chevron_left_rounded, color: AppColors.muted),
  ]));
}
