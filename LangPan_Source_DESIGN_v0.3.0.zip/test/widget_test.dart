import 'package:flutter_test/flutter_test.dart';
import 'package:langpan/main.dart';

void main() {
  testWidgets('LangPan opens the redesigned learning home', (tester) async {
    await tester.pumpWidget(const LangPanApp());
    await tester.pumpAndSettle();
    expect(find.text('LangPan'), findsOneWidget);
    expect(find.text('سلام مسعود 👋'), findsOneWidget);
    expect(find.text('Hello!'), findsOneWidget);
    expect(find.text('شروع درس'), findsOneWidget);
  });
}
