import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const LangPanApp());
}

class LangPanApp extends StatelessWidget {
  const LangPanApp({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(seedColor: const Color(0xFF3B82F6));
    return MaterialApp(
      title: 'LangPan',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorScheme: scheme),
      home: const TestModeHome(),
    );
  }
}

class TestModeHome extends StatefulWidget {
  const TestModeHome({super.key});

  @override
  State<TestModeHome> createState() => _TestModeHomeState();
}

class _TestModeHomeState extends State<TestModeHome> {
  Map<String, dynamic>? curriculum;
  String? error;

  @override
  void initState() {
    super.initState();
    _loadCurriculum();
  }

  Future<void> _loadCurriculum() async {
    try {
      final raw = await rootBundle.loadString('content/en/curriculum_map.json');
      final parsed = jsonDecode(raw) as Map<String, dynamic>;
      if (mounted) {
        setState(() => curriculum = parsed);
      }
    } catch (e) {
      if (mounted) {
        setState(() => error = '$e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final levels =
        (curriculum?['levels'] as List<dynamic>?) ?? const <dynamic>[];
    return Scaffold(
      appBar: AppBar(title: const Text('LangPan • Test Mode')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: error != null
            ? Text('Content load error: $error')
            : levels.isEmpty
            ? const Center(child: CircularProgressIndicator())
            : ListView.separated(
                itemCount: levels.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, index) {
                  final level = levels[index] as Map<String, dynamic>;
                  final title =
                      level['title'] ?? level['cefrLevel'] ?? 'Level';
                  final status = level['status'] ?? 'planned';
                  return Card(
                    child: ListTile(
                      title: Text('$title'),
                      subtitle: Text('Status: $status'),
                      trailing: const Icon(Icons.chevron_right),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
